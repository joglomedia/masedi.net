=== WP-IP2Nation-Installer  ===
Donate link: http://www.daveligthart.com
Tags: ip2nation,ip,2,nation,iptocountry,ip2country,country,countryip,geo-ip,database
Stable tag: trunk
Requires at least: 2.0
Tested up to: 2.7

== Description ==

Get country by ip. Installs the ip2nation database.

Use this plugins functions to get the country / country code
by ip address from your template file.

See <a href="http://www.ip2nation.com/">ip2nation.com</a>.

== Installation ==

1. Unzip & upload to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Call the plugins functions in your template file

