<?php
/*
Plugin Name: WP-Ads-Filter
Plugin URI: http://masedi.net/plugins/wp-ads-filter.html
Description: Display selected ads for visitor based on country's ip (IP2Nation). Installs the IP2Nation database from <a href="http://www.ip2nation.com/">ip2nation.com</a> based on <a href="http://www.daveligthart.com/plugins/wp-ip2nation-installer/">WP-IP2Nation-Installer</a> Plugin by Dave Ligthart. 
Version: 1.1
Author: Edi Septr
Author URI: http://masedi.net
*/

$wp_ads_filter = '1.0';

/**
 * Install IP 2 Nation database.
 * @see http://www.ip2nation.com
 * @access public
 * @version 0.1_11-11-08
 * @author dligthart <info@daveligthart.com>
 */
function wp_ip2nation_install() {
	global $wpdb;
	global $wp_version;
	global $wp_ads_filter;

	$table_name = 'ip2nation';

	$installed = ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name);

	// Table already created?
	if(!$installed){
		// Not, create table.
		ob_start();
	    include('resources/ip2nation/ip2nation.sql'); //11-11-08 database version.
	    $sql = ob_get_contents();
	    ob_end_clean();

		if($wp_version >= 2.3) {
			require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		} else{
			require_once(ABSPATH . 'wp-admin/upgrade-functions.php');
		}

      	dbDelta($sql);
		
		/* additional */
		$banned_countries = 'bd,cn,id,in,my,ph,pk,lk';
		//update_option('wp_ip2nation_main_ads', 'Here are your main ads code for allowed country', 'Main ads code for allowed country', 'no');
		//update_option('wp_ip2nation_alternate_ads', 'Here are your alternative ads code for banned country', 'Alternaive ads code for banned country', 'no');
		update_option('wpaf_banned_country', $banned_countries);
	}
	return $installed;
}

/**
 * Get country by ip.
 * @param String $ip optional
 * @access public
 * @author dligthart <info@daveligthart.com>
 * @return object
 * @version 0.1
 */
function wp_ip2nation_getcountry($ip = null) {
	global $wpdb;

	if(null == $ip) {
		$ip  = $_SERVER['REMOTE_ADDR'];
	}

	$sql = sprintf("" .
	 "SELECT
		 c.country,
		 c.code
	  FROM
		 ip2nationCountries c,
		 ip2nation i
	  WHERE
		 i.ip < INET_ATON('%s')
	  AND
		 c.code = i.country
	  ORDER BY
		 i.ip DESC
	  LIMIT 0,1", $ip);

	 $row = $wpdb->get_row($sql);

	 return $row;
}

/**
 * Assert that countrycode equals parameter code.
 * @param String $countrycode Country code
 * @access public
 * @version 0.1
 * @return equals boolean
 */
function wp_ip2nation_equals($countrycode = '') {
	$n = wp_ip2nation_getcountry();
	return ($n->code == $countrycode);
}

/**
 * Get Image Flag html.
 * @param string $ip optional
 * @return html flag
 * @access public
 * @version 0.1
 */
function wp_ip2nation_flag($ip = null){
	$n = wp_ip2nation_getcountry($ip);
	$code = $n->code;
	$country = $n->country;
	return '<img src="../wp-content/plugins/wp-ads-filter/resources/images/flags/png/'. $code .'.png" alt="'.$country.'" />';
}


/**
 * Ban country from showing main ads,
 * rotate ads/show ads for selected country
 * Usage:
 * if (!wpaf_is_banned_country()) {
 * 	<!-- Your Main Ads Code Here -->
 * }else{
 * 	<!-- Your Alternative Ads Code Here -->
 * }
 */
function wpaf_is_banned_country ($ip = null) {
	$n = wp_ip2nation_getcountry($ip);
	$country_code = $n->code;
	$country_name = $n->country;
	$banned_country = get_option('wpaf_banned_country');
	$banned_countries = @explode(',',$banned_country);
	sort($banned_countries);
	
	if (@in_array($country_code, $banned_countries)) {
		return true;
	}else{
		return false;
	}
}

/**
 * Render dashboard.
 * @access private
 */
function wpaf_admin_menu() {
	if (function_exists('add_options_page')) {
			add_options_page(__('WP Ads Filter', 'wpfilterads'),
			 	__('WP Ads Filter', 'wpfilterads'),
				 10,
			 	basename(dirname(__FILE__)),
			 	'wpaf_admin_settings'
			 );
	}
}

function wpaf_filter_options($wpafoptions = '') {
	//filtered characters
	$wpaffilterchars = array(' ','!','@','#','%','^','&','*','-','+','.');

	$wpafoptions = trim($wpafoptions, " \t.");
	$wpafoptions = str_replace($wpaffilterchars, '', $wpafoptions);
	return $wpafoptions;
}

/**
 * Render admin menu page.
 * @access private
 */
function wpaf_admin_settings() {
	$n = wp_ip2nation_getcountry();
	
	if (isset($_POST['wpaf_submit'])) {
		$banned_countries = $_POST['banned_countries'];
		update_option('wpaf_banned_country',wpaf_filter_options($banned_countries));
	}
	
	$banned_countries = get_option('wpaf_banned_country');
?>
<div class="wrap"><div id="icon-themes" class="icon32"><br /></div>
<h2>WP Ads Filter</h2>
<div id="message" class="updated fade"><p>
WP-IP2Nation message: IP2Nation database succesfully installed!
<br />
WP-Ads-Filter message: You are from
<?php echo wp_ip2nation_flag(). '&nbsp;&nbsp;' .$n->country. '.&nbsp;&nbsp;';

	if (wpaf_is_banned_country()) {
		_e('Your IP is banned from showing main ads.');
	}else{
		_e('Your IP is allowed to showing main ads.');
	}
?>
</p>
</div>

<div class="postbox-container" style="width: 74%;">
	<div class="metabox-holder">
		<div class="meta-box-sortables ui-sortable">    
			<div id="wpaf_settings" class="postbox">
				<div class="handlediv" title="Click to toggle">
					<br/>
				</div>
				<h3 class="hndle">
					<span>General Settings</span></h3>
				<div class="inside" style="padding:0 10px;">

					<form name="wpaf_update" id="wpaf_update" method="post" action="" enctype="multipart/form-data">
					<table class="wpaf-table">
					<tr>
					<td valign="top" style="padding-top:10px;">
						<label>Banned Country:</label>
					</td>
					<td>
						<textarea name="banned_countries" cols="55" rows="2"><?php echo $banned_countries; ?></textarea>
						<br/><label>Use only country code, Separate each country code with comma.</label>
					</td>
					</tr>
					<tr>
					<td>
					<p class="submit">
					<input class="button-primary" type="submit" name="wpaf_submit" class="button" value="<?php _e('Save Changes'); ?>" />
					</p>
					</td>
					</tr>
					</table>
					</form>
				
				</div>
	
			</div>
			
			<div id="wpaf_info" class="postbox">
				<div class="handlediv" title="Click to toggle">
					<br/>
				</div>

				<h3 class="handle">Usage</h3>
				<div class="inside" style="padding:0 10px;">
				<p>
				<code>if (!wpaf_is_banned_country()) {<br />
					&lt;!-- Your Main Ads Code Here --&gt;<br />
				}else{<br />
					&lt;!-- Your Alternative Ads Code Here --&gt;<br />
				}</code>
				</p>
				</div>
			</div>

		</div>
	</div>

	<p>
		WP Ads Filter by <a href="http://www.masedi.net" target="_blank"/>MasEDI Networked Blogs</a>. Inspired by: <small>WP-IP2-Nation from <a href="http://www.daveligthart.com" target="_blank"/>daveligthart.com</a></small>
		</p>
		
</div>
<?php
}

// Install ip2nation database.
register_activation_hook(__FILE__,'wp_ip2nation_install');

// Add dashboard info.
add_action('admin_menu','wpaf_admin_menu');

// Do not uninstall because the database might be shared between other plugins.
//register_deactivation_hook(__FILE__,'wp_ip2nation_deinstall');
?>
