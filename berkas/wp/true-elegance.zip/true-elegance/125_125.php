<li><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/125_125.gif" alt="" title="Advertisement" /></a></li>
<li><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/125_125.gif" alt="" title="Advertisement" /></a></li>
<li><a href="#"><img src="<?php bloginfo('template_directory'); ?>/images/125_125.gif" alt="" title="Advertisement" /></a></li>