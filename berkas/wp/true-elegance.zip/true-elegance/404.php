<?php get_header(); ?>

<div id="content">

	<div id="column">
	
	<div class="post">
	<h1>No posts were found.</h1>
	<p>Sorry! the page you are looking for does not exist.</p>
	<h3>Blog Search</h3>
	<?php include(TEMPLATEPATH."/searchform.php"); ?>
	</div>
	
	</div>

<?php get_sidebar(); ?>

<div class="clear"></div>
</div>

<?php get_footer(); ?>