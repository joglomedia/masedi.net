<!-- footer -->
<div id="footer">

<div class="copyright">Copyright &copy; 2008 <a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>" class="sitename"><?php bloginfo('name'); ?></a>. All rights reserved. <a href="<?php bloginfo('rss2_url'); ?>" class="footrss">Posts Feed</a><a href="<?php bloginfo('comments_rss2_url'); ?>" class="footrss">Comments Feed</a></div>
<div class="credit">By <a href="http://customthemedesign.com/" title="Custom Theme Design">Custom Theme Design</a><br />

Brought to you by <a href="http://www.comfi.com/">phone card</a> &amp; <a href="http://www.phonce.com">calling card</a> &amp; <a href="http://www.paytone.com/">telecom company</a>.</div>

<div class="clear"></div>
</div>
<!-- end -->

</div>

<?php wp_footer(); ?>

</body>
</html>