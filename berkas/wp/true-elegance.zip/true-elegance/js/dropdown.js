﻿window.onload=function()
{
	activateMenu('pagemenu');
	if(document.getElementsByTagName)
	matchHeight();

	activateMenu('catmenu');
	if(document.getElementsByTagName)
	matchHeight();
}