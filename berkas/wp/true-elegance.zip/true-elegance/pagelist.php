<?php

/*

Template Name: Page List

*/

?>

<?php get_header(); ?>

<div id="content">



	<div id="column">


<!-- Loop -->
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

	

	<div class="post_header" id="post-<?php the_ID(); ?>">

		<h1><?php the_title(); ?></h1>

<div class="clear"></div>		<div class="post">

<?php the_content("Continue reading " . the_title('', '', false)); ?><div class="clear"></div>


		<?php edit_post_link('Edit this page', '<p class="edit">', '</p>'); ?></div>

</div>	

	

	



	<?php endwhile; ?>

	<?php endif; ?>

	

	 
	 
<?php
/* 
 * Let's start the 2nd loop, may u use it for listing post or related post or etc based on page/post custom fields value
 * modified by me [at] masedi [dot] net
 * under GNU/GPLv3
 *
*/
	// save the original wp query first!
	$temp_query = $wp_query;

	// edit here
	$custom_field_name = "related_post_cf"; // change! this must be = with post/page custom_fields value
	$max_showposts = 5;
	
	/* Do not touch this line till you know the sky will fall to your head :D */
	/* extract custom value from page/post custom_fields related to the current post ID */
		$postid = get_the_ID();
		$custom_fields = get_post_custom($postid);
		$custom_settings = $custom_fields[$custom_field_name];
		$custom_category = $custom_settings[0]; // only get the 1st custom_field value :D
	/* End */

	// collect post query parameter
	$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
	$sticky = get_option('sticky_posts');

	$args=array( 'category_name' => $custom_category,
			'caller_get_posts' => 1,
			'category__not_in' => $sticky, 
			'paged'=>$paged,
			//'post_type' => 'post',
			//'post_status' => 'publish',
			'showposts' => $max_showposts);

	// make new wp query
	//query_posts($args);
	$new_query = new WP_Query($args);
	/* END of query */
?>
<!-- Title -->

<?Php
// start the 2nd loop for page listing post
while ($new_query->have_posts()) : $new_query->the_post();
?>	 

	 <div class="post">
		<h2><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
		<div class="postinfo">
		<div class="info">Posted by <?php the_author_posts_link(); ?> on <?php the_time('j F, Y'); ?></div>
		<div class="commentnum"><?php comments_popup_link('No comments yet', '1 comment so far', '% Comments'); ?></div>
		<div class="clear"></div>
		</div>
		
		<div class="category">This item was filled under [ <?php the_category(', '); ?> ]</div>
		
		<div class="entry">
		<?php the_excerpt(); ?><div class="clear"></div>
		<p><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="more-link">Continue reading...</a></p>
		
		</div>
		
		<?php the_tags('<div class="tags">Tagged with: [ ', ', ', ' ]</div><div class="clear"></div>'); ?>
	</div>
	
	
<!-- Plugin Navigation -->

	<?php if(function_exists('wp_pagenavi')) { wp_pagenavi(); } ?>
	<!-- End -->
	
<?php endwhile; ?>

<?Php
	// don't forget return the original query
	$wp_query = $temp_query;
	wp_reset_query();
	// end of all page listing post
?>

        <?php if (function_exists('wp_list_comments')) { comments_template('', true); } else { comments_template(); } ?>
	</div>


<?php get_sidebar(); ?>


<div class="clear"></div>

</div>

<?php get_footer(); ?>