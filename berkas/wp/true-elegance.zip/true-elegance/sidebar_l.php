<div class="sidebar2" style="margin-right:8px">
<ul>

	<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(2) ) : else : ?>

	<li><h2>Pages</h2>
	<ul>
	<?php wp_list_pages('title_li='); ?>
	</ul>
	</li>

	<li><h2>Meta</h2>
	<ul>
	<?php wp_register(); ?>
	<li><?php wp_loginout(); ?></li>
	<li><a href="<?php bloginfo('rss2_url'); ?>">Entries RSS</a></li>
	<li><a href="<?php bloginfo('comments_rss2_url'); ?>">Comments RSS</a></li>
	<li><a href="http://wordpress.org/">WordPress.org</a></li>
	</ul>
	</li>
	
	<li><h2>Archives</h2>
	<ul>
	<?php wp_get_archives('type=monthly&limit=12'); ?>
	</ul>
	</li>

	<?php endif; ?>

</ul>
</div>