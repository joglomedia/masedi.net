<object type="application/x-shockwave-flash" data="http://vimeo.com/moogaloop.swf?clip_id=445255&amp;server=vimeo.com&amp;show_title=0&amp;show_byline=0&amp;show_portrait=0&amp;color=00ADEF&amp;fullscreen=1" width="380" height="214">
<param name="allowfullscreen" value="true"></param>
<param name="movie" value="http://vimeo.com/moogaloop.swf?clip_id=445255&amp;server=vimeo.com&amp;show_title=0&amp;show_byline=0&amp;show_portrait=0&amp;color=00ADEF&amp;fullscreen=1"></param>
</object>