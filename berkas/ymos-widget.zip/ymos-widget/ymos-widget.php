<?Php
/*
Plugin Name: Yahoo! Messenger Online Status Widget (YMOS Widget)
Plugin URI: http://masedi.net/plugins
Description: Yahoo! Messenger Online Status Widget (YMOS Widget). Easily show and placing Yahoo! Messenger online status on Wordpress sidebar widget. This plugin also allow you to check your Yahoo contact status whether they are currently online or not from your widget. Managed by <a href="http://masedi.net/">MasEDI</a>.
Author: MasEDI
Version: 0.1beta
Author URI: http://masedi.net/
*/

/*
Copyright (c) 2009 MasEDI.NET (email : echiex[at]gmail[dot]com)

This program is for private user only. You are not allowed to modified and or redistribute it without any permission of the author.

*/

define(PluginName, "YMOS Widget");
define(PluginOptionURI, "ymos-widget/ymos-widget.php");
define(PluginVersion, "0.1beta");
$ymos_version = PluginVersion;

function ymos_admin_panel(){
	add_options_page("Yahoo! Messenger Online Status Widget Settings", PluginName, 8, PluginOptionURI, 'ymos_admin_settings');
	add_submenu_page("plugins.php", "Yahoo! Messenger Online Status Widget", PluginName, 10, PluginOptionURI, 'ymos_admin_settings');
	if(current_user_can('edit_posts') && function_exists('add_submenu_page')) {
		add_filter('plugin_action_links', 'ymos_setting_link', 10, 2 );
	}
}

function ymos_setting_link($links, $file){
	static $this_plugin;
	if (!$this_plugin) $this_plugin = plugin_basename(__FILE__);
        if ($file == $this_plugin){
            $settings_link = '<a href="options-general.php?page='.PluginOptionURI.'">Settings</a>';
            array_unshift($links, $settings_link); // before other links
       }
	return $links;
}


/*
*	Yahoostatus_check() based on script writed by Setec Astronomy - setec@freemail.it
* 	GNU General Public License for more details.
*	http://www.gnu.org/licenses/gpl.txt
*/
function yahoostatus_check ($yahoo = "", &$errno, &$errstr){
	$errno = 0; $errstr = ""; $retstr = "";
	$lines = @file ("http://opi.yahoo.com/online?u=" . $yahoo . "&m=t"); 
	if ($lines !== false) {
		$response = implode ("", $lines);
		if (strpos ($response, "NOT ONLINE") !== false) {
			$retstr = "offline";
			return $retstr;
		} elseif (strpos ($response, "ONLINE") !== false) {
			$retstr = "online";
			return $retstr;
		} else {
			$retstr = "unknown";
			return $retstr;
		}
	} else {
		$errno = 1;
		$errstr = "Unable to connect to http://opi.yahoo.com";
		return false;
	}
}

function get_yahooicon($yid, $istyle) {
	$iconimage = "<img src='http://opi.yahoo.com/online?u=" .$yid. "&amp;m=g&amp;t=".$istyle."' alt='' />";
	return $iconimage;
}

/* START widget sidebar */
function widget_ymos($args){
    extract($args);
    echo $before_widget;
    echo $before_title . stripslashes(get_option('ymos_plugin_widgettitle')) . $after_title;
	
	$status = yahoostatus_check(get_option('ymos_plugin_yahooid'), $errno, $errstr);
	$yid = get_option('ymos_plugin_yahooid');
	$istyle = get_option('ymos_plugin_iconstyle');
	$onlinemsg = stripslashes(get_option('ymos_plugin_onmessage'));
	$offlinemsg = stripslashes(get_option('ymos_plugin_offmessage'));
	
	echo '<div align="center">';
	if ($status !== false){
		switch ($status) { 
			case "online": 
				if(get_option('ymos_plugin_icontype') == "yahoo"){
					$iconimage = get_yahooicon($yid, $istyle);
				}else{
					$iconimage = "<img src=\"".get_option('ymos_plugin_customonicon')."\" />";
				}
				_e("" . $onlinemsg . "<br /><a href='ymsgr:sendIM?".get_option('ymos_plugin_yahooid')."'>".$iconimage."</a>", PluginName);
				break; 
			case "offline":
				if(get_option('ymos_plugin_icontype') == "yahoo"){
					$iconimage = get_yahooicon($yid, $istyle);
				}else{
					$iconimage = "<img src=\"".get_option('ymos_plugin_customofficon')."\" />";
				}
				_e("" . $offlinemsg . "<br /><a href='ymsgr:sendIM?".get_option('ymos_plugin_yahooid')."'>".$iconimage."</a>", PluginName);
				break; 
			case "unknown": 
				_e("Yahoo! " . get_option('ymos_plugin_yahooid') . "<br /> is in an unknown status!", PluginName);
				break; 
		} 		
	}else{
		_e("An error occurred during ".PluginName." query: <br />", PluginName);
		_e("Error no. " . $errno . ": " . $errstr .".", PluginName);
	}
	echo '</div>';
	echo '<div align="center" style="font-size:10px;">'. PluginName. ' powered by <a href="http://masedi.net">MasEDI.net</a></div>';
	echo $after_widget;
}

function ymos_widgets(){
	register_sidebar_widget(PluginName, 'widget_ymos');
}
/* END widget */

function ymos_activate(){
	add_option('ymos_plugin_yahooid', 'gombile', 'Yahoo! ID', 'no'); //  for Testing only
	add_option('ymos_plugin_icontype', 'yahoo', 'Yahoo! status icon type', 'no'); // default Yahoo! status icon or custom icon
    add_option('ymos_plugin_iconstyle', '2', 'Yahoo! status icon style number', 'no'); // default Yahoo! status icon style
	add_option('ymos_plugin_allowspy', 'yes', 'Allow visitor use to check other Yahoo! ID status', 'no'); // allow checking another Yahoo! status
	add_option('ymos_plugin_customonicon', '', 'Yahoo! custom online icon image URL', 'no'); //  
	add_option('ymos_plugin_customofficon', '', 'Yahoo! custom offline icon image URL', 'no'); // 
	add_option('ymos_plugin_onmessage', 'Hi, I am Online', 'Yahoo! online message', 'no'); //  
	add_option('ymos_plugin_offmessage', 'Sorry, I am Offline now', 'Yahoo! offline message', 'no'); // 
	add_option('ymos_plugin_widgettitle', 'My Yahoo! Status', 'Yahoo! status widget title', 'no'); //
}

function ymos_deactivate(){
	// nothing todo yet
	// next try clean uninstallation moved here
}

function ymos_admin_style(){
?>
	<style type="text/css">
	#menu_hidden {display: none;}
	.rounded_corner {border:1px solid #ccc; -moz-border-radius:5px; -khtml-border-radius:5px; -webkit-border-radius:5px; border-radius:5px;}
	.clearfix {clear:both;}
	.infobox_me {padding:0px 15px; background-color:#e5e5e5; margin-bottom:10px;}
	.titlebox_me {padding:5px; text-align:center; background-color:#666; color:#ccc; font-weight:bold;}
	.settingsbox_me {width:640px; float:left;}
	</style>
<?Php
}

function ymos_admin_header(){ 
?>
	<script type="text/javascript">
	var mf_hidden=1;
	
	function menu_showHidden() {
		if (mf_hidden==1) {
			document.getElementById('menu_hidden').style.display='block';
			document.getElementById('menu_settings').style.display='none';
			document.getElementById('menu_hidden_link').innerHTML="<strong>Back to Settings</strong>";
			document.getElementById('menu_headline').innerHTML="<?Php echo PluginName; ?> Deep &amp; Clean Uninstallation";
			mf_hidden=2;
		} else {
			document.getElementById('menu_hidden').style.display='none';
			document.getElementById('menu_settings').style.display='block';
			document.getElementById('menu_hidden_link').innerHTML="<strong>Uninstallation</strong>";
			document.getElementById('menu_headline').innerHTML="<?Php echo PluginName; ?> Plugin Settings";	
			mf_hidden=1;
		}
	}
	</script>
<?Php
}

function ymos_admin_settings(){
	global  $ymos_version;
	//$versi_akhir = trim(@file_get_contents('http://project.masedi.net/ymos/versi.txt'));
	$versi_akhir = $ymos_versi;
	$plugin_update = "";
	
	/* get WP version, it's seem silly but good enough :P */
	$compat_versi = '2.7'; // compatible wp version
	$wp_versi = '';
	$wp_versi = str_ireplace("version", "", apply_filters('update_footer', ''));
	$wp_versi = str_ireplace("|", "", $wp_versi);
	$wp_versi = substr(trim($wp_versi), 0, 3);
	/* end wp version */

	if("$versi_akhir">"$ymos_version"){
		$plugin_update = "<div id='message' class='updated fade'><p><b>Update Info:</b> There is a new version of ".PluginName." ".$versi_akhir." is available! <a href='http://project.masedi.net/ymos/".PluginName."_v".$versi_akhir.".zip'>Please download the latest version here</a> or <a href='http://masedi.net/plugins.html#".PluginName."'>View version ".$versi_akhir." Details</a>.</p></div>";
	}

	if (isset($_POST['update_ymos'])){
		$yahooid = $_POST['yahooid'];
		$allowspy = $_POST['allowspy'];
		$icontype = $_POST['icontype'];
		$iconstyle = $_POST['iconstyle'];
		$customonicon = $_POST['customonicon'];
		$customofficon = $_POST['customofficon'];
		$onmessage = $_POST['customonicon'];
		$offmessage = $_POST['customofficon'];
		$widgettitle = $_POST['widgettitle'];
	
		update_option('ymos_plugin_yahooid', $yahooid);
		update_option('ymos_plugin_icontype', $icontype);
		update_option('ymos_plugin_iconstyle', $iconstyle);
		update_option('ymos_plugin_allowspy', $allowspy);
		update_option('ymos_plugin_customonicon', $customonicon); 
		update_option('ymos_plugin_customofficon', $customofficon);
		update_option('ymos_plugin_onmessage', $onmessage);
		update_option('ymos_plugin_offmessage', $offmessage);
		update_option('ymos_plugin_widgettitle', $widgettitle);
		
		echo "<div id='message' class='updated fade'><p><b>Status: ".PluginName." Options updated!</b></p></div>";
	}

	$yahooid = get_option('ymos_plugin_yahooid');
	$allowspy = get_option('ymos_plugin_allowspy');
	$icontype = get_option('ymos_plugin_icontype');
	$iconstyle = get_option('ymos_plugin_iconstyle');
	$customonicon = get_option('ymos_plugin_customonicon');
	$customofficon = get_option('ymos_plugin_customofficon');
	$onmessage = stripslashes(get_option('ymos_plugin_customonicon'));
	$offmessage = stripslashes(get_option('ymos_plugin_customofficon'));
	$widgettitle = stripslashes(get_option('ymos_plugin_widgettitle'));

	if($allowspy=='yes'){
    	$allowspy_yes = 'selected="selected"';
	}else{
		$allowspy_no = 'selected="selected"';
	}
	
	if($icontype=='yahoo'){
    	$icontype_yahoo = 'selected="selected"';
	}else{
		$icontype_custom = 'selected="selected"';
	}

	
	/* 
	 * Uninstall YMOS
	 * Modified from original source WP-PageNavi @http://lesterchan.net/portfolio/programming/php/
	 */
	$ymos_settings = array('yahooid', 'icontype', 'iconstyle', 'allowspy', 'customonicon', 'customofficon', 'onmessage', 'offmessage', 'widgettitle');
	sort($ymos_settings);
	
	if(!empty($_POST['do'])) {
		switch($_POST['do']) {
			case __('Uninstall '.PluginName, PluginName) :
				if(trim($_POST['uninstall_ymos_yes']) == 'yes') {
					echo '<div id="message" class="updated fade">';
					echo '<p><b>Status: '.PluginName.' Options Deleted!</b></p><p>';
					foreach($ymos_settings as $setting) {
						$ymos_setting = 'ymos_plugin_'.$setting.'';
						$delete_setting = delete_option($ymos_setting);
						if($delete_setting) {
							echo '<font color="green">';
							printf(__('Setting Key \'%s\' has been deleted.', PluginName), "<strong><em>{$ymos_setting}</em></strong>");
							echo '</font><br />';
						} else {
							echo '<font color="red">';
							printf(__('Error deleting Setting Key \'%s\'.', PluginName), "<strong><em>{$ymos_setting}</em></strong>");
							echo '</font><br />';
						}
					}
					echo '</p>';
					echo '</div>';
					$mode = 'end-uninstall';
				}else{
				echo "<div id='message' class='updated fade'><p><b>Status: ".PluginName." Uninstallation failed. Check Uninstallation statement first!</b></p></div>";
				}	
			break;
		}
	}
	
	/*
	 * End Uninstall Proccess, Link back to Deactivate Plugin
	 */
	switch($mode) {
		case 'end-uninstall':
				$deactivate_url = 'plugins.php?action=deactivate&plugin='.PluginOptionURI.'';
				if(function_exists('wp_nonce_url')) {
					$deactivate_url = wp_nonce_url($deactivate_url, 'deactivate-plugin_'.PluginOptionURI.'');
				}
				echo '<div class="wrap">';
				echo '<h2>'.__('Uninstall '.PluginName, PluginName).'</h2>';
				echo '<p><strong>'.sprintf(__('<a href="%s">Click Here</a> To Finish The Uninstallation And '.PluginName.' Will Be Deactivated Automatically.', PluginName), $deactivate_url).'</strong></p>';
				echo '</div>';
				break;
		default:
	?>
	
	
	<?Php
	/*
	 * General Setting Menu
	 */
	?>	
	<!-- Setting Option -->
	<div class="wrap"> <!-- Start option menu -->
		<?php if($wp_versi >= $compat_versi) screen_icon(); ?>
		<h2 id="menu_headline"><?php _e(PluginName.' Plugin Settings', PluginName); ?></h2>
		<div class="infobox_me rounded_corner">   
		<p><a href="javascript:;" onclick="menu_showHidden();" id="menu_hidden_link"><strong>Uninstallation</strong></a> | 
		<?Php if(get_option('ymos_plugin_yahooid') == 'gombile') { ?> <a href="http://www.yahoo.com/" target="_new">Don't Have Yahoo! Messenger? Register first!</a> |<?Php } ?> <a href="http://masedi.net/plugins" target="_new">Get Latest News</a></p>
		</div>
	</div>
	
	<div class="wrap"> <!-- Start option settings field -->
        <div id="menu_settings">
        
          <?Php echo $plugin_update; ?>
        
        <div class="settingsbox_me">
            <fieldset class="options">
            <h4><?php _e('Yahoo! settings', PluginName); ?></h4>
            <form name="ymos_update" id="ymos_update" method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>" enctype="multipart/form-data">
            <table cellpadding="3" cellspacing="3">
                <tr>
                <td width="240">Yahoo! Messenger ID:</td>
                <td width="340"><input type="text" name="yahooid" value="<?Php echo $yahooid; ?>" size="30" />
                <br /><small>(replace with your Yahoo! id!)</small></td>
                </tr>
                <tr>
                <td width="240">Allow public ID status check:</td>
                <td width="340"><select name="allowspy"><option value="yes"<?Php echo $allowspy_yes; ?>> Yes <option value="no"<?Php echo $allowspy_no; ?>> No </select>
                <br /><small>(Yes, allowed your visitor checking other Yahoo! ID status from your widget.)</small></td>
                </tr>
                <tr>
            </table>
            
            <h4><?php _e('Yahoo! status icon', PluginName); ?></h4>
            <table cellpadding="3" cellspacing="3">
            <tr>
            <td width="240">Yahoo! status icon image:</td>
            <td width="340"><select name="icontype"><option value="yahoo"<?Php echo $icontype_yahoo; ?>> Default icon <option value="custom"<?Php echo $icontype_custom; ?>> Custom icon </select>
            <br /><small>If you are using custom icon, please provide your full custom icon image URL. Else, select default Yahoo! status icon style!</small></td>
            </tr>
            <tr>
            <td width="240">Default Yahoo! status icon style:</td>
            <td width="340"><input type="text" name="iconstyle" maxlength="2" value="<?Php echo $iconstyle; ?>" size="3" /><br /><small>(0 - 24)</small></td>
            </tr>
            <tr>
            <td width="240">Custom image URL <br />(online icon):</td>
            <td width="340"><input type="text" name="customonicon" value="<?Php echo $customonicon; ?>" size="45" /></td>
            </tr>
            <tr>
            <td width="240">Custom image URL <br />(offline icon):</td>
            <td width="340"><input type="text" name="customofficon" value="<?Php echo $customofficon; ?>" size="45" /></td>
            </tr>
            <tr>
            <td width="240">Sidebar Widget Title:</td>
            <td width="340"><input type="text" name="widgettitle" value="<?Php echo $widgettitle; ?>" size="30" /></td>
            </tr>
            </table>
            <p style="border:0;" class="submit"><input type="submit" class="submit" name="update_ymos" value="<?php _e('Update '.PluginName, PluginName); ?>" /></p>
            </form>
            </fieldset>
        </div>
        
            <!-- Additional sidebar menu -->
            <div style="width:280px; right:15px; position: fixed;">
                <div class="rounded_corner titlebox_me">Recomended!</div>
                <div class="rounded_corner" style="padding:0 15px 15px 15px;">
                <h4><?php _e('Support Plugin make Donation!', PluginName); ?></h4>
                <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
                <input type="hidden" name="cmd" value="_s-xclick">
                <input type="hidden" name="hosted_button_id" value="7309862">
                <input style="width:240px; margin:0px auto;" type="image" src="https://www.paypal.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
                <img style="width:240px; margin:0px auto;" alt="" border="0" src="https://www.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
                </form>  
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
        
        <div id="menu_hidden">
        
        <!-- Uninstallation Menu -->
        <form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
            <div class="rounded_corner infobox_me">			
                <p style="color:green;"> <strong><?php _e('INFO:', PluginName); ?></strong><br /> <?php _e('Normally deactivating '.PluginName.' plugin does not remove any data that may have been created on your database. To completely remove this plugin, you can uninstall it here.', PluginName); ?>
                </p>
                <p style="color:red;">
                    <strong><?php _e('WARNING:', PluginName); ?></strong><br />
                    <?php _e('Once uninstalled, this cannot be undone. You should use a Database Backup plugin of WordPress to back up all the data first.', PluginName); ?>
                </p>
                <p>
                    <strong><?php _e('The following WordPress Options will be DELETED:', PluginName); ?></strong><br />
                </p>
            </div>
            
            <table class="widefat">
                <thead>
                    <tr>
                        <th><?php _e('List of WordPress Options', PluginName); ?></th>
                    </tr>
                </thead>
            </table>
            <table class="widefat"  cellpadding="3" cellspacing="3">
                <tr>
                    <td width="15"><b> No. </b></td>
                    <td width="200"><b> Option Setting </b></td>
                    <td width="300"><b> Option Value</b></td>
                </tr>
                        <?php
                            foreach($ymos_settings as $key => $setting){
                                echo "<tr><td width=\"15\">".($key+1)."</td><td width=\"200\">ymos_plugin_".$setting."</td>"
                                ."<td width=\"300\">".get_option('ymos_plugin_'.$setting.'')."</td></tr>";
                            }
                        ?>
                        
            </table>
            <br />
            <input type="checkbox" name="uninstall_ymos_yes" value="yes" />&nbsp;<?php _e('Yes, I want to Uninstall '.PluginName.' plugin!', PluginName); ?>
            <p style="border:0;" class="submit">
            <input type="submit" class="submit" name="do" value="<?php _e('Uninstall '.PluginName, PluginName); ?>" class="button" onclick="return confirm('<?php _e('Are You Sure To Perform Deep and Clean Uninstalling '.PluginName.' From WordPress.\nThis Action Is Not Reversible.\n\n Choose [Cancel] To Stop, [OK] To Uninstall.', PluginName); ?>')" />
            </p>
        </form>
    
        </div>
	</div> <!-- End option setting field-->
    
    <!-- FOOTER INFO -->
	<h3><?php _e('Resources Guide', PluginName); ?></h3>
	<p>To activate your widget, Please go to Appearance -> Widget then drag and drop <?Php echo PluginName; ?> to sidebar widget.
	<p>Managed by <a href="http://masedi.net" target="MasEDI">MasEDI.NET</a> a WordPress Newbie.</p>
	<p>
	<?Php
		$upgrade = apply_filters('update_footer', 'test');
		echo "<p>".PluginName." version $ymos_version running under Wordpress $upgrade</p>";
	?>
    </p>
	<?Php //";
  }//end switch
}// end the admin menu function


register_activation_hook(__FILE__, 'ymos_activate');
register_deactivation_hook(__FILE__, 'ymos_deactivate');
add_action('admin_print_scripts', 'ymos_admin_header'); // javascript
add_action('admin_print_styles', 'ymos_admin_style'); // stylsheet
add_action('admin_menu', 'ymos_admin_panel'); // add admin settings link
add_action('plugins_loaded', 'ymos_widgets'); // load widget
?>