#!/bin/sh
# Install Memcached & PHP PECL Memcache on cPanel CentOS
# Ref http://www.php.net/manual/en/memcache.installation.php
# Ref http://pswebsolutions.wordpress.com/2009/08/26/how-to-install-memcache-on-linux-server/
# Ref http://kb.softescu.ro/server-administration/cpanel/how-to-install-memcach-in-cpanel/
# (c) JOGLOHosting - http://www.joglohosting.com/
### Packages Version ###
LIBEVENTVER="2.0.16-stable"
MEMCACHEDVER="1.4.13"
PECLMEMCACHEVER="3.0.6"
CURDIR=`pwd`
##########
dep_check() {
	CMEMCACHE=`cat /var/cpanel/easy/apache/profile/_main.yaml | grep MemCache | awk -F:\  '{print $2}'`
	echo "Checking dependency....."
	if ["CMEMCACHE" == "1" ]; then
		echo "Please compile PHP with Memcache using EasyApache"
		exit 1;
	else
		echo "Everything fine..."
		#install nc to test memcache installation
		yum install nc
	fi
}
# Step 1: Configure Apache
clear
echo "Step 1: Configure Apache.
# Before you continue installing memcache, ensure that your Apache has been configured with memcache.
# Login to cPanel and start EasyApache.
# At the Exhaustive Option List choose Memcache. Compile Apache & Restart it."
dep_check()
#echo -n "If you have done with the EasyApache, back here and press enter to continue ..."
#read -e LANJUT
###########
# Step 2: Install Libevent (Memcache requires Libevent)
echo "Step 2: Install Libevent (Memcache requires Libevent) ..."
sleep 2
cd $CURDIR/packages/libevent-$LIBEVENTVER
./configure
make && make install
###########
# Step 3: Register LibEvent
echo "Step 3: Registering Libevent ..."
sleep 1
touch /etc/ld.so.conf.d/libevent-`uname -i`.conf
echo "/usr/local/lib/" > /etc/ld.so.conf.d/libevent-`uname -i`.conf
ldconfig
###########
# Step 4: Compile and install Memcache (deamon)
echo "Step 4: Install Memcached from tarball source ..."
sleep 1
cd $CURDIR/packages/memcached-$MEMCACHEDVER
./configure
make && make install
###########
# Step 5: Install PHP extension for Memcache
echo "Step 5: Install PHP extension for Memcache from PECL ..."
sleep 1
cd $CURDIR/packages/memcache-$PECLMEMCACHEVER
phpize
./configure
make && make install
# Add memcache extension to php.ini setting
# Edit /usr/local/lib/php.ini
#nano /usr/local/lib/php.ini
# Add new memcache.so extension
#extension="memcache.so"
# Note: Also check the extension directory where memcache.so located
#MEMCACHEEXT=`find / -name memcache.so`
# Use the advantage of sed with reference pdo_mysql extension, we assume the pdo_mysql is almost enable in cpanel server
sed -i 's/extension = "pdo_mysql.so"/extension = "pdo_mysql.so"\nextension = "memcache.so"/g' /usr/local/lib/php.ini
#use sed to rollback
#sed -i 's/extension = "memcache.so"//g' /usr/local/lib/php.ini
# Restart apache httpd service
service httpd restart
###########
# Step 6: Run Memcache as a deamon on the startup files
echo "Step 6: Run Memcache as a deamon on the startup files ..."
sleep 1
echo "Before continue, We need a short config, FYI; many memcached installs run with 4 GB (4096) memory."
echo -n "How much memory allocated for your memcache? : "
read -e MEMORYUSAGE
# nano /etc/memcached.conf
touch /etc/memcached.conf
# Add this settings
MEMCACHECONFIGS="
# Memory allocated for object storage. You should adjust the amount of storage to suit your needs; many memcached installs run with 4 GB memory.
-m $MEMORYUSAGE
# default memcached port
-p 11211
# user to run daemon nobody/apache/www-data
-u nobody
# only listen locally
-l 127.0.0.1"
echo "$MEMCACHECONFIGS" > /etc/memcached.conf
# Create memcache daemon
cp $CURDIR/conf/memcached /etc/init.d/
chmod +x /etc/init.d/memcached
# Create memcached start script
cp $CURDIR/conf/start-memcached /usr/local/bin/
chmod +x /usr/local/bin/start-memcached
# Now, let.s test the scripts
echo "# Test Memcache daemon script ..."
/etc/init.d/memcached start
# and review if the conf file is parsed ok:
echo "# Take a short review if the config file is parsed ok ..."
ps aux | grep memcached
# and last, add memcached as autostart deamon
echo "# Add memcached as autostart daemon ...
# Check the config, and it should output something like:
# memcached 0:off 1:off 2:on 3:on 4:on 5:on 6:off"
sleep 1
/sbin/chkconfig memcached on
# check
/sbin/chkconfig --list | grep memcached
# Step 7: Inspecting Running Configuration
echo "Step 7: Inspecting Running Configuration"
echo "# If you see an output something like here --> http://code.google.com/p/memcached/wiki/NewConfiguringServer
# Your memcache is successfully installed and configured."
sleep 1
echo "stats settings" | nc localhost 11211
# The output something like here --> http://code.google.com/p/memcached/wiki/NewConfiguringServer
###########
# Step 8: Test Memcache in PHP
echo "Step 8: Test Memcache in PHP"
echo "# If your Memcache daemon and PHP Memcache installed sucessfull. Now, test it in PHP.
# Create the memcache.php file and add this http://kb.softescu.ro/wp-content/uploads/2010/09/memcache.txt
# You should have in the browser, something like:
# String to store in memcached."
