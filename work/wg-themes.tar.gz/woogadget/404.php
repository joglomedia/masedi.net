<?php get_header(); ?>

	<div id="content">

			<?php include_once(TEMPLATEPATH."/page-error.php"); ?>

	</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>