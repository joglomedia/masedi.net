			</div>
		</div>
		<div id="footer">
			<div class="footernav">
				<ul>
					<?php wp_list_pages('title_li=&depth=1'); ?>
				</ul>
			</div>
			<div class="copyright">
				&copy; <?php echo date('Y'); echo '&nbsp;<strong><a href="' .get_bloginfo('home'). '">' .get_bloginfo('name'). '</a></strong>'; ?>.<br/>Theme by <a rel="nofollow" href="http://smashingmagazine.com" target="_blank">SmashingMagazine</a> and <a rel="nofollow" href="http://slimmity.com" target="_blank">Slimmity</a>
			</div>
		</div>
	</div>
	<script type="text/javascript"> Cufon.now(); </script>
	<?php wp_footer(); ?>
</body>
</html>