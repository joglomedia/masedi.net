<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-US">
<head profile="http://gmpg.org/xfn/11">
<title><?php wp_title('-', true, 'right'); ?> <?php bloginfo('name'); ?></title>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="text/xml" title="RSS .92" href="<?php bloginfo('rss_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="Atom 0.3" href="<?php bloginfo('atom_url'); ?>" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Comments Feed" href="<?php bloginfo('comments_rss2_url'); ?>" />
<link rel="shortcut icon" href="<?php echo sf_get_favicon(); ?>" title="Favicon" />
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<!--[if IE 6]>
<script src="<?php bloginfo('template_url'); ?>/js/DD_belatedPNG.js"></script>
<script>
  /* EXAMPLE */
  DD_belatedPNG.fix('*');
</script>
<link rel="stylesheet" media="screen" href="ie6.css"/>
    <![endif]-->
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/cufon-yui.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/fonts/Museo.font.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/DD_roundies.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/hoverIntent.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/superfish.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/s3Slider.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/custom.js"></script>

<?php if (is_home()){ ?>

<meta name="Keywords" content="<?php echo stripslashes(get_option('sf_seo_kw')); ?>" />
<meta name="Description" content="<?php echo stripslashes(get_option('sf_seo_desc')); ?>" />
<script type="text/javascript">
$(document).ready(function() {
$('#sliderHome').s3Slider({
timeOut: 5000
});
});
</script>

<?php } ?>

<?php if (is_page_template('template-home.php')) { ?>
<script type="text/javascript">
$(document).ready(function() {
$('#slider').s3Slider({
timeOut: 5000
});
});
</script>
<?php } ?>

<?php
	if ( is_singular() ) wp_enqueue_script( 'comment-reply' );
	wp_head();
?>
</head>

<body>
<div id="wrapper">
	<div id="header">
	
		<div id="logo">
			<a href="<?php bloginfo('home'); ?>"><img src="<?php echo sf_get_logo(); ?>" alt="<?php bloginfo('name'); ?> - <?php bloginfo('description') ?>"/></a>
		</div>
		<div id="search">
<a rel="nofollow" href="http://masedi.net/goto/voltrank/" title="VoltRank Giveaway" target="_blank"><img src="http://static.voltrank.com/gfx/b/b468_60s.gif" alt="VoltRank Giveaway" /></a>		
		</div>
	</div>
	
	<div id="access" class="accessmenu">
			<ul class="sf-menu" id="nav">
			<li class="home"><a href="<?php bloginfo('home'); ?>">Home</a></li>
			<?php wp_list_cats('title_li='); ?>
			</ul>
	</div>
		
	<div id="main">
		<div class="container">
