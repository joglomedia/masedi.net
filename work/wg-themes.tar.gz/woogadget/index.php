<?php get_header(); ?>

	<div class="content">
	
	<?php
	$slide_category = get_option('sf_portfolio_category');			
	if(($slide_category != 'Select a category:') && is_home()) :
		$slide_count = (get_option('sf_slider_slides')) ? get_option('sf_slider_slides') : 5;
		$text_count = (get_option('sf_slider_chars')) ? get_option('sf_slider_chars') : 120;
		$my_query = new WP_Query('showposts='.$slide_count.'&category_name='.$slide_category);
	?>

		<div id="sliderHome">
			<div id="sliderHomeContent">
				<?php			
				while ($my_query->have_posts()) : $my_query->the_post();
				$do_not_duplicate = $post->ID; 
				$thumb = get_post_meta($post->ID, 'thumb-large', true);
				?>
				<div class="sliderHomeImage">
					<a href="<?php the_permalink(); ?>"><img src="<?php echo $thumb; ?>" alt="<?php the_title() ?>" /></a>
					<span class="bottom"><h3><?php the_title() ?></h3> <?php the_content_limit($text_count, ''); ?></span>
				</div>
				<?php endwhile; ?>
				<div class="clear sliderHomeImage"></div>
			</div>
		</div>
	
	<?php endif;
		
		if (have_posts()) : while (have_posts()) : the_post(); ?>
			
		<div class="blogpost">
			<div class="comments"><?php comments_popup_link('0', '1', '%'); ?></div>
			<h2 class="title"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
			<div class="meta">Posted <?php the_time('F jS, Y') ?> in <?php the_category(', ') ?> by <?php the_author() ?></div>
			<div class="entry">
				<?php the_content('Continue Reading &raquo;'); ?>
			</div>
		</div>
			
		<?php endwhile;
			
			if(function_exists('wp_pagenavi')):
				wp_pagenavi();
			else:
		?>
		<div class="navigation">
			<div class="alignleft"><?php next_posts_link('&laquo; Older Entries') ?></div>
			<div class="alignright"><?php previous_posts_link('Newer Entries &raquo;') ?></div>
		</div>
		<?php endif;
			
		else :
			include_once(TEMPLATEPATH."/page-error.php");
		endif; ?>

	</div>

<?php get_sidebar();
get_footer(); ?>
