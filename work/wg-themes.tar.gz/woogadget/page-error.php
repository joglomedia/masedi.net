	<div class="blogpost">
		<div class="entry">
		<?php  if (is_category()): ?>
				<h3>The Category is empty</h3>
					<p>
						Im sorry to say that no articles have been written for this category yet. 
					</p>
		<?php elseif (is_search()): ?>
				<h3>Search Results</h3>
					<p>Your search - <strong><?PHP echo $_GET[s]; ?></strong> - did not match any documents. </p>
					Suggestions:
					<ul>
						<li>Make sure all words are spelled correctly.</li>
						<li>Try different keywords.</li>
						<li>Try more general keywords.</li>
						<li>Try fewer keywords.</li>
					</ul>
		<?php  else: ?>
			<h3><em>404</em>. The Page you requested was not found</h3>
			<p>We are sorry the page you requested was not found or no longer exists on this website.<br />
			A few things that you might want to do.</p>
			<p>&nbsp;</p>
			<ul>
				<li><a href="http://www.woogadget.com/">Return to home page</a></li>
				<li><a href="javascript:history.back();">Go back to the previous page</a></li>
				<li>Try some search<br>
				<form method="get" id="searchform" action="http://www.woogadget.com/">
				<input value="" name="s" id="s" type="text">
				<input id="searchsubmit" value="Search" type="submit">
				</form>
				</li>
				<li>Browse <a href="http://www.woogadget.com/sitemap" title="WooGadget Sitemap">Sitemap</a>.</li>
			</ul>
		<?php endif; ?>
		
		</div>
	</div>
