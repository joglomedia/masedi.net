	<form method="get" id="sidebarsearch" action="<?php bloginfo('home'); ?>" >
		<div>
			<input type="text" value="" name="s" id="keyword" />
			<input type="submit" name="submit" id="searchsubmit" value="Search" /> 
		</div>
	</form>
