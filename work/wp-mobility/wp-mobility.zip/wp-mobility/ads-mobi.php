<?
// BuzzCity publisher code
/* my partnerid=10666 */
function BuzzCity($partnerid=10666){
  if(!$partnerid) $partnerid = 10666;    // put your partnerID here
  $alternate_link = '<a href="http://click.buzzcity.com/click.php?cid=62&amp;partnerid=10666">Cool and Cute Mobile Download</a>';   // use this to set a default link if no ad returned
    
  //used for ad targeting
  $ua = urlencode($_SERVER['HTTP_USER_AGENT']);
  $ip = urlencode($_SERVER['REMOTE_ADDR']);

  $url = 'http://ads.buzzcity.com/show.php?get=1&partnerid=' . 
		$partnerid . '&a=' . $ua . '&i='.$ip;

  @$ad_serve = @fsockopen($url, 80);
  $contents = '';
  if ($ad_serve) {
      while (!@feof($ad_serve)) {
          $contents .= @fgets($ad_serve,1024);
      }
      @fclose($ad_serve);
	  
	    $link = explode("\n",$contents);
  }
  
  $text = $link[0];
  $cid = $link[1];

  if (!empty($link)) {
      //display BuzzCity Ad
      $adslink = '<a href="http://click.buzzcity.com/click.php?partnerid=' . 
			$partnerid . '&amp;cid=' . $cid . '">' . $text . '</a>';
  }
  else {
      //no BuzzCity ad, display alternate
      $adslink = $alternate_link;
  }
  
  return $adslink;
}



// AdMob Publisher Code
/*
 * admob fsockopen new
 */
/*
 * add function for ads-mobi.php wp-mobility
 */
function admob_fsock($admobkey = 'a147a7d9a104ac8'){
  $admob_params = array(
  'PUBLISHER_ID'      => $admobkey, // Required to request ads. To find your Publisher ID, log in to your AdMob account and click on the "Sites & Apps" tab.
  'ANALYTICS_ID'      => 'your_analytics_site_id', // Required to collect Analytics data. To find your Analytics ID, log in to your Analytics account and click on the "Edit" link next to the name of your site.
  'AD_REQUEST'        => true, // To request an ad, set to TRUE.
  'ANALYTICS_REQUEST' => false, // To enable the collection of analytics data, set to TRUE.
  'TEST_MODE'         => false, // While testing, set to TRUE. When you are ready to make live requests, set to FALSE.
  // Additional optional parameters are available at: http://developer.admob.com/wiki/AdCodeDocumentation
  'OPTIONAL'          => array()
    );

    return admob_request_fsock($admobkey, $admob_params);
}

// Send request to AdMob. To make additional ad requests per page, copy and paste this function call elsewhere on your page.

/////////////////////////////////
// Do not edit below this line //
/////////////////////////////////

// This section defines AdMob functions and should be used AS IS.
// We recommend placing the following code in a separate file that is included where needed.

function admob_request_fsock($admobkey, $admob_params) {
  static $pixel_sent = false;

  $ad_mode = false;
  if (!empty($admob_params['AD_REQUEST']) && !empty($admob_params['PUBLISHER_ID'])) $ad_mode = true;

  $analytics_mode = false;
  if (!empty($admob_params['ANALYTICS_REQUEST']) && !empty($admob_params['ANALYTICS_ID']) && !$pixel_sent) $analytics_mode = true;

  $protocol = 'http';
  if (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) != 'off') $protocol = 'https';

  $rt = $ad_mode ? ($analytics_mode ? 2 : 0) : ($analytics_mode ? 1 : -1);
  if ($rt == -1) return '';

  list($usec, $sec) = explode(' ', microtime());
  $params = array('rt=' . $rt,
                  'z=' . ($sec + $usec),
                  'u=' . urlencode($_SERVER['HTTP_USER_AGENT']),
                  'i=' . urlencode($_SERVER['REMOTE_ADDR']),
                  'p=' . urlencode("$protocol://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']),
                  'v=' . urlencode('20081105-PHPFSOCK-33fdd8e59a40dd9a'));

  $sid = empty($admob_params['SID']) ? session_id() : $admob_params['SID'];
  if (!empty($sid)) $params[] = 't=' . md5($sid);
  if ($ad_mode) $params[] = 's=' . $admob_params['PUBLISHER_ID'];
  if ($analytics_mode) $params[] = 'a=' . $admob_params['ANALYTICS_ID'];
  if (!empty($_COOKIE['admobuu'])) $params[] = 'o=' . $_COOKIE['admobuu'];
  if (!empty($admob_params['TEST_MODE'])) $params[] = 'm=test';

  if (!empty($admob_params['OPTIONAL'])) {
    foreach ($admob_params['OPTIONAL'] as $k => $v) {
      $params[] = urlencode($k) . '=' . urlencode($v);
    }
  }

  $ignore = array('HTTP_PRAGMA' => true, 'HTTP_CACHE_CONTROL' => true, 'HTTP_CONNECTION' => true, 'HTTP_USER_AGENT' => true, 'HTTP_COOKIE' => true);
  foreach ($_SERVER as $k => $v) {
    if (substr($k, 0, 4) == 'HTTP' && empty($ignore[$k]) && isset($v)) {
      $params[] = urlencode('h[' . $k . ']') . '=' . urlencode($v);
    }
  }

  $post = implode('&', $params);
  $request_timeout = 1; // 1 second timeout
  $contents = '';
  $errno = 0;
  $errstr = '';
  list($usec_start, $sec_start) = explode(' ', microtime());
  $request = @fsockopen('r.admob.com', 80, $errno, $errstr, $request_timeout);
  if($request) {
    stream_set_timeout($request, $request_timeout);
    $post_body = "POST /ad_source.php HTTP/1.0\r\nHost: r.admob.com\r\nContent-Type: application/x-www-form-urlencoded\r\nContent-Length: " . strlen($post) . "\r\n\r\n" . $post;
    $post_body_len = strlen($post_body);
    $bytes_written = 0;
    $body = false;

    $info = stream_get_meta_data($request);
    $timeout = $info['timed_out'];
    while($bytes_written < $post_body_len && !$timeout) {
      $current_bytes_written = fwrite($request, $post_body);
      if($current_bytes_written === false) return ''; // write failed
      $bytes_written += $current_bytes_written;
      if($bytes_written === $post_body_len) break;
      $post_body = substr($post_body, $bytes_written);
      $info = stream_get_meta_data($request);
      $timeout = $info['timed_out'];
    }

    while(!feof($request) && !$timeout) {
      $line = fgets($request);
      if(!$body && $line == "\r\n") $body = true;
      if($body && !empty($line)) $contents .= $line;
      $info = stream_get_meta_data($request);
      $timeout = $info['timed_out'];
    }
    fclose($request);
    list($usec_end, $sec_end) = explode(' ', microtime());
  }
  else {
    $contents = '';
  }

  if (!$pixel_sent) {
    $pixel_sent = true;
    $contents .= " <img src=\"$protocol://p.admob.com/e0?"
              . 'rt=' . $rt
              . '&amp;z=' . ($sec + $usec)
              . '&amp;a=' . ($analytics_mode ? $admob_params['ANALYTICS_ID'] : '')
              . '&amp;s=' . ($ad_mode ? $admob_params['PUBLISHER_ID'] : '')
              . '&amp;o=' . (empty($_COOKIE['admobuu']) ? '' : $_COOKIE['admobuu'])
              . '&amp;lt=' . ($sec_end + $usec_end - $sec_start - $usec_start)
              . '&amp;to=' . $request_timeout
              . '" alt="" width="1" height="1"/>'
              ."";
  }

  return $contents;
}


/*
 * admob cURL
 */

function admob_curl($admobkey = 'a147a7d9a104ac8'){
  $admob_params = array(
  'PUBLISHER_ID'      => $admobkey, // Required to request ads. To find your Publisher ID, log in to your AdMob account and click on the "Sites & Apps" tab.
  'ANALYTICS_ID'      => 'your_analytics_site_id', // Required to collect Analytics data. To find your Analytics ID, log in to your Analytics account and click on the "Edit" link next to the name of your site.
  'AD_REQUEST'        => true, // To request an ad, set to TRUE.
  'ANALYTICS_REQUEST' => false, // To enable the collection of analytics data, set to TRUE.
  'TEST_MODE'         => false, // While testing, set to TRUE. When you are ready to make live requests, set to FALSE.
  // Additional optional parameters are available at: http://developer.admob.com/wiki/AdCodeDocumentation
  'OPTIONAL'          => array()
    );

  return admob_request_curl($admobkey, $admob_params);
}
function admob_request_curl($admobkey, $admob_params) {
  static $pixel_sent = false;

  $ad_mode = false;
  if (!empty($admob_params['AD_REQUEST']) && !empty($admob_params['PUBLISHER_ID'])) $ad_mode = true;

  $analytics_mode = false;
  if (!empty($admob_params['ANALYTICS_REQUEST']) && !empty($admob_params['ANALYTICS_ID']) && !$pixel_sent) $analytics_mode = true;

  $protocol = 'http';
  if (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) != 'off') $protocol = 'https';

  $rt = $ad_mode ? ($analytics_mode ? 2 : 0) : ($analytics_mode ? 1 : -1);
  if ($rt == -1) return '';

  list($usec, $sec) = explode(' ', microtime());
  $params = array('rt=' . $rt,
                  'z=' . ($sec + $usec),
                  'u=' . urlencode($_SERVER['HTTP_USER_AGENT']),
                  'i=' . urlencode($_SERVER['REMOTE_ADDR']),
                  'p=' . urlencode("$protocol://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']),
                  'v=' . urlencode('20081105-PHPCURL-acda0040bcdea222'));

  $sid = empty($admob_params['SID']) ? session_id() : $admob_params['SID'];
  if (!empty($sid)) $params[] = 't=' . md5($sid);
  if ($ad_mode) $params[] = 's=' . $admob_params['PUBLISHER_ID'];
  if ($analytics_mode) $params[] = 'a=' . $admob_params['ANALYTICS_ID'];
  if (!empty($_COOKIE['admobuu'])) $params[] = 'o=' . $_COOKIE['admobuu'];
  if (!empty($admob_params['TEST_MODE'])) $params[] = 'm=test';

  if (!empty($admob_params['OPTIONAL'])) {
    foreach ($admob_params['OPTIONAL'] as $k => $v) {
      $params[] = urlencode($k) . '=' . urlencode($v);
    }
  }

  $ignore = array('HTTP_PRAGMA' => true, 'HTTP_CACHE_CONTROL' => true, 'HTTP_CONNECTION' => true, 'HTTP_USER_AGENT' => true, 'HTTP_COOKIE' => true);
  foreach ($_SERVER as $k => $v) {
    if (substr($k, 0, 4) == 'HTTP' && empty($ignore[$k]) && isset($v)) {
      $params[] = urlencode('h[' . $k . ']') . '=' . urlencode($v);
    }
  }

  $post = implode('&', $params);
  $request = curl_init();
  $request_timeout = 1; // 1 second timeout
  curl_setopt($request, CURLOPT_URL, 'http://r.admob.com/ad_source.php');
  curl_setopt($request, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($request, CURLOPT_TIMEOUT, $request_timeout);
  curl_setopt($request, CURLOPT_CONNECTTIMEOUT, $request_timeout);
  curl_setopt($request, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded', 'Connection: Close'));
  curl_setopt($request, CURLOPT_POSTFIELDS, $post);
  list($usec_start, $sec_start) = explode(' ', microtime());
  $contents = curl_exec($request);
  list($usec_end, $sec_end) = explode(' ', microtime());
  curl_close($request);

  if ($contents === true || $contents === false) $contents = '';
  //if ($contents === false) $contents = '';
  
  if (!$pixel_sent) {
    $pixel_sent = true;
    $contents .= " <img src=\"$protocol://p.admob.com/e0?"
              . 'rt=' . $rt
              . '&amp;z=' . ($sec + $usec)
              . '&amp;a=' . ($analytics_mode ? $admob_params['ANALYTICS_ID'] : '')
              . '&amp;s=' . ($ad_mode ? $admob_params['PUBLISHER_ID'] : '')
              . '&amp;o=' . (empty($_COOKIE['admobuu']) ? '' : $_COOKIE['admobuu'])
              . '&amp;lt=' . ($sec_end + $usec_end - $sec_start - $usec_start)
              . '&amp;to=' . $request_timeout
              . '" alt="" width="1" height="1"/>'
              ."";
  }

  return $contents;
}


function admob_setcookie($domain = '', $path = '/') {
  if (empty($_COOKIE['admobuu'])) {
    $value = md5(uniqid(rand(), true));
    if (!empty($domain) && $domain[0] != '.') $domain = ".$domain";
    if (setcookie('admobuu', $value, mktime(0, 0, 0, 1, 1, 2038), $path, $domain)) {
      $_COOKIE['admobuu'] = $value; // make it visible to admob_request()
    }
  }
}


/*
 * admob() file_get_contents
 */
function admob_fgetcontents($admobkey = 'a147a7d9a104ac8'){ // show admob ads - www.admob.com
  $mob_ua = urlencode(getenv("HTTP_USER_AGENT"));
  $mob_ip = urlencode($_SERVER['REMOTE_ADDR']);
  $campaign = get_option('wp_mobility_plugin_admobauthkey');
  /*
  $admobshare = get_option('wordpress_mobile_plugin_admobshare');
  if($admobshare!='amwpok'){
    $rand = rand(0,100);
    $campaign = ($rand <= $admobshare) ? 'a1473ddf68562dc' : $admobkey;
    $rand = 'Sharing '.$admobshare.'% to plugin author';
  }else{
    $rand = '100% version';
    $campaign = $admobkey;
  }
   * */

  $mob_url = "http://ads.admob.com/ad_source.php?s=$admobkey&u=$mob_ua&i=$mob_ip$mob_m";
  $mob_ad_serve = @file_get_contents($mob_url);
  if ($mob_ad_serve!=''){
    $mob_link = explode("><",$mob_ad_serve);
    $mob_ad_text = ereg_replace('--> ','',ereg_replace('&','&amp;',$mob_link[0]));
    $mob_ad_link = $mob_link[1];
    if(eregi('iphone',$mob_ua)){
      $ads = "<script>if (typeof _admob == 'undefined') { var _admob = {}; } _admob.site_id = '$admobkey'; _admob.borderColor = 'gray'; </script><script src='http://ads.admob.com/static/js/admob_ads_p.js'></script>";
    }else  if($mob_ad_link!=''){
      $ads = "<a href='$mob_ad_link' accesskey='0' rel='nofollow'>$mob_ad_text</a>";
    }
  }else{
    $ads = "<a href='http://ads.admob.com/link_list.php?s=".$campaign."'>".get_option('wordpress_mobile_plugin_admoblink')."</a>";
  }
  /*
  if(isset($_GET['adshare'])){
    $ads = "Ad info: $rand - This impression to $campaign ";
  }
   */
  return $ads;
}


/*
 * Google adsense
 */

function google(){
   if(get_option('wordpress_mobile_plugin_admobshare')!='amwpok'){
     $admobshare = get_option('wordpress_mobile_plugin_admobshare');
     $rand = rand(0,100);
     $campaign = ($rand <= $admobshare) ? 'pub-3132018019261025' : get_option('wordpress_mobile_plugin_google');
     $rand = 'Sharing '.$admobshare.'% to plugin author';
   }else{
    $rand = '100% version';
    $campaign = get_option('wordpress_mobile_plugin_google');
   }
   if(isset($_GET['adshare'])){
    $return .= "Ad info: $rand - This impression to $campaign ";
   }
  $GLOBALS['google']['client']=$campaign;
  $GLOBALS['google']['format']='mobile_'.get_option('wordpress_mobile_plugin_googleformat');
  $GLOBALS['google']['ad_type']='text';
  $GLOBALS['google']['https']=$_SERVER['HTTPS'];
  $GLOBALS['google']['host']=$_SERVER['HTTP_HOST'];
  $GLOBALS['google']['ip']=$_SERVER['REMOTE_ADDR'];
  $GLOBALS['google']['markup']='xhtml';
  $GLOBALS['google']['oe']='utf8';
  $GLOBALS['google']['output']='xhtml';
  $GLOBALS['google']['ref']=$_SERVER['HTTP_REFERER'];
  $GLOBALS['google']['url']=$_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
  $GLOBALS['google']['useragent']=$_SERVER['HTTP_USER_AGENT'];
  $colour = get_option('wordpress_mobile_plugin_colour');
  switch($colour){
    case pink;
      $color_link='FF0099';
      $color_url='FF0099';
    break;
    case blue;
      $color_link='14568A';
      $color_url='14568A';
    break;
    case green;
      $color_link='006600';
      $color_url='006600';
    break;
    case red;
      $color_link='CD7054';
      $color_url='CD7054';
    break;
  }
  $GLOBALS['google']['color_link']=$color_link;
  $GLOBALS['google']['color_url']=$color_url;
  // $GLOBALS['google']['color_link']='006600';
  // $GLOBALS['google']['color_url']='006600';
  $GLOBALS['google']['color_border']='ffffff';
  $GLOBALS['google']['color_bg']='ffffff';
  $GLOBALS['google']['color_text']='000000';
  $google_dt = time();
  google_set_screen_res();
  $google_ad_handle = @fopen(google_get_ad_url(), 'r');
  if ($google_ad_handle) {
    while (!feof($google_ad_handle)) {
      $return .= fread($google_ad_handle, 8192);
    }
    fclose($google_ad_handle);
  }else if (get_option('wp_mobility_plugin_admob')!=''){
  // basically if we're executing here we failed to get google ads so we check if there's an admob id and if there is we show admob ads as an alternative - if there's inventory we might as well fill it!
    $authorlink = trim(get_option('wp_mobility_plugin_authorlink'));
    if($authorlink=='no'){
      $adclass = 'foot';
    }else{
      $adclass = 'admob';
    }
    $return .= '<div class="'.$adclass.'">'.admob(get_option('wp_mobility_plugin_admob')).'</div>';
  }
  return $return;
} // ends google function

function google_append_url(&$url, $param, $value) {
  $url .= '&' . $param . '=' . urlencode($value);
}

function google_append_globals(&$url, $param) {
  google_append_url($url, $param, $GLOBALS['google'][$param]);
}

function google_append_color(&$url, $param) {
  global $google_dt;
  $color_array = split(',', $GLOBALS['google'][$param]);
  google_append_url($url, $param,$color_array[$google_dt % sizeof($color_array)]);
}

function google_set_screen_res() {
  $screen_res = $_SERVER['HTTP_UA_PIXELS'];
  $delimiter = 'x';
  if ($screen_res == '') {
    $screen_res = $_SERVER['HTTP_X_UP_DEVCAP_SCREENPIXELS'];
    $delimiter = ',';
  }
  $res_array = explode($delimiter, $screen_res);
  if (sizeof($res_array) == 2) {
    $GLOBALS['google']['u_w'] = $res_array[0];
    $GLOBALS['google']['u_h'] = $res_array[1];
  }
}

function google_get_ad_url() {
  $google_ad_url = 'http://pagead2.googlesyndication.com/pagead/ads?';
  $google_scheme = ($GLOBALS['google']['https'] == 'on') ? 'https://' : 'http://';
  foreach ($GLOBALS['google'] as $param => $value) {
    if ($param == 'client') {
      google_append_url($google_ad_url, $param, 'ca-mb-' . $GLOBALS['google'][$param]);
    } else if (strpos($param, 'color_') === 0) {
      google_append_color($google_ad_url, $param);
    } else if ((strpos($param, 'host') === 0) || (strpos($param, 'url') === 0)) {
      google_append_url($google_ad_url, $param, $google_scheme . $GLOBALS['google'][$param]);
    } else {
      google_append_globals($google_ad_url, $param);
    }
  }
  google_append_url($google_ad_url, 'dt',
  round(1000 * array_sum(explode(' ', microtime()))));
  return $google_ad_url;
}
?>
