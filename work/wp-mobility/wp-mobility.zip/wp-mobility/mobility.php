<?php
/* 
 * @Package: mobility.php
 * @contain functions for mobility
 * @modified by echiex@gmail.com
 */

// function to auto detect mobile phone - based on a number of methods
// this is the function that works out if it's a normal browser or a mobile browser
// more info on theory behind this: http://www.andymoore.info/php-to-detect-mobile-phones/
function mobile_plugin_auto_detect(){
	// initialise a value at zero
	$mobile_browser = '0';
	if(preg_match('/(opera mini|up.browser|up.link|mmp|symbian|smartphone|midp|wap|phone|vodafone|o2|pocket|mobile|pda|psp|treo)/i',
	strtolower($_SERVER['HTTP_USER_AGENT']))){
    	$mobile_browser++;
	}
	if(((strpos(strtolower($_SERVER['HTTP_ACCEPT']),'text/vnd.wap.wml')>0) or (strpos(strtolower($_SERVER['HTTP_ACCEPT']),
	'application/vnd.wap.xhtml+xml')>0)) or ((isset($_SERVER['HTTP_X_WAP_PROFILE']) or isset($_SERVER['HTTP_PROFILE'])))){
		$mobile_browser++;
	}
	$mobile_ua = strtolower(substr($_SERVER['HTTP_USER_AGENT'],0,4));
	$mobile_agents = array('acs-','alav','alca','amoi','audi','aste','avan','benq','bird','blac','blaz','brew','cell','cldc','cmd-','dang','doco','eric','hipt','inno','ipaq','java','jigs','kddi','keji','leno','lg-c','lg-d','lg-g','lge-','maui','maxo','midp','mits','mmef','mobi','mot-','moto','mwbp','nec-','newt','noki','opwv','palm','pana','pant','pdxg','phil','play','pluc','port','prox','qtek','qwap','sage','sams','sany','sch-','sec-','send','seri','sgh-','shar','sie-','siem','smal','smar','sony','sph-','symb','t-mo','teli','tim-','tosh','treo','tsm-','upg1','upsi','vk-v','voda','wap-','wapa','wapi','wapp','wapr','webc','winw','winw','xda','xda-');
	if(in_array($mobile_ua,$mobile_agents)){
		$mobile_browser++;
	}

	// now we check if mobile_browser is greater than zero or get mobi is set
	// we also check the browser isn't opera as it can render full markup'd sites
	// you can change 0 to 1 to ensure 2 tests above were passed or set it to 2 to match all three tests
	if((($mobile_browser > 0) or (isset($_GET['mobi']))) ){
		// now we know it's a mobile phone or we're to show the mobile version so we move on
		mobile_plugin_thematic_check();
	}
}

// this function works out if we need to just render content for a mobile or if we need to redirect the user to a different url
function mobile_plugin_thematic_check(){
	// where is this blog hosted?
	$home = get_settings('siteurl');
	// get the value of oneweb from the wordpress admin panel
	// you can edit this value on the admin panel
	$oneweb = get_option('wp_mobility_plugin_oneweb');
	// to proceed past this point we need two values mode and permalink plus an optional value oneweb
	// we only need to set oneweb if it's a mobile specific page,ie wordpress for a normal browser does not have wordpress desktop version such as the way the plugin handles listing archive pages
	// permalink is the url this should be viewed on
	if((is_home()) and (!isset($_GET['view']))){
		$mode ='';
		$permalink = "$home/";
	}
	// are we showing a page
	if($_GET['view']=='page'){
		$mode = '&view=page';
		$permalink = "$home/$mode";
		$oneweb = 'enabled';
	}
	// are we showing the archive index
	if($_GET['view']=='archives'){
		$mode = '&view=archives';
		$permalink = "$home/$mode";
		$oneweb = 'enabled';
	}
	//tambahan showing the category index
	if($_GET['view']=='categories'){
		$mode = '&view=categories';
		$permalink = "$home/$mode";
		$oneweb = 'enabled';
	}
  
	// are we shoing a month, if so do we have both m (month) and y (year) values
	if(($_GET['view']=='month') and (!isset($_GET['m'])||!isset($_GET['y']))){
		$mode = "?view=archives";
		$permalink = "$home/?view=archives";
		// we have basic values m and y missing so redirect to the basic archive index
		mobile_redirect($permalink);
	exit;
	}
	// are we showing a month if so do we have the values this time (we should have)
	if(($_GET['view']=='month') and (isset($_GET['m'])&&isset($_GET['y']))){
		$mode = "?view=month&y=".$_GET['y']."&m=".$_GET['m'];
		$permalink = "$home/?view=month&y=".$_GET['y']."&m=".$_GET['m'];
	} 
	// is it an archive with no further instructions - ie archive index
	if((is_archive()) and (!isset($_GET['view']))){
		$mode = '?view=archives';
		$permalink = "$home/$mode";
		mobile_redirect($permalink);
		exit;
	}
	// are we writing a post
	if($_GET['view']=='write'){
		$mode = '&view=write';
		$permalink = "$home/$mode";
		$oneweb = 'enabled';
	}
	// are we showing a single post
	if(is_single()){
		global $post;
		$post_id = $post->ID;
		$mode = "&p=$post_id";
		$permalink = get_permalink();
	}
	// is it a page
	if(is_page()&&!$mode){
		global $post;
		$post_id = $post->ID;
		$mode = "&page=$post_id";
		$permalink = get_permalink();
	}
	// now we need to check if we're using oneweb or not
	// oneweb will preserve the permalink struct
	// it's thematic consistency if you're a geek
	if($oneweb=='enabled'){
		// we're cool to render the mobile version
		 echo show_mobile_version();
	}else{
		// if mobi is set we've been instructed to show the mobile version
		if(isset($_GET['mobi'])){
			echo show_mobile_version();
		}else{
			// work out the right link to redirect to
			if(!$permalink){
			$request_uri = $_SERVER['HTTP_REQUEST_URI'];
			$link = "$home/$request_uri?mobi$mode";
			}else{
			$link = "$permalink";
			$mobi = check_mobi($permalink);
			$link = "$link$mobi";
		}
		// redirect and bow out
		mobile_redirect($link);
		exit;
		}
	}
}
// ends mobile_plugin_thematic_check()

// this is just a standard 301 redirect to the url passed
function mobile_redirect($link){
	header('HTTP/1.1 301 Moved Permanently');
	header('Status: 301 Moved Permanently');
	header("Location: $link");
}

/* detect mobile number */
function get_msisdn(){
	//$msisdn = '';
	/* I saw this header work for most operators */
	// AKTEL, BANGLA LINK & CITYCELL IN BANGLADESH
	if(isset($_SERVER['HTTP_X_UP_CALLING_LINE_ID'])){
		$msisdn = trim($_SERVER['HTTP_X_UP_CALLING_LINE_ID']);
	}
	// in maximum case for Nokia and SonyEricsson
	elseif (isset($_SERVER['HTTP_X_HTS_CLID'])){
		$msisdn = trim($_SERVER['HTTP_X_HTS_CLID']);
	}
	// in maximum case for Motorola and Siemens
	elseif (isset($_SERVER['HTTP_MSISDN'])){
		$msisdn = trim($_SERVER['HTTP_MSISDN']);
	}
	elseif (isset($_SERVER['HTTP_X_NETWORK_INFO'])){
		$tmpmsisdn    = trim($_SERVER['HTTP_MSISDN']);
		$msisdn = preg_replace('/(.*,)(13[d]{ 9 })(,.*)/i','2',$tmpmsisdn);
	}
	elseif (isset($_SERVER['HTTP_X_UP_SUBNO'])){
		$tmpmsisdn    = trim($_SERVER['HTTP_X_UP_SUBNO']);
		$msisdn = preg_replace('/(.*)(13[d]{ 9 })(.*)/i','2',$tmpmsisdn);
	} else {
		$msisdn = trim($_SERVER['DEVICEID']);
	}
	
	return $msisdn;
	//if($msisdn != '') $traced_mobile = true;
}

// if we need to add a mobi get value to the url it comes in handy to know if it's a directory or query stung page we're showing so we can select either ?mobi or &mobi
// used a lot more when one web is disabled as it needs to work out where to reidrect the user to
function check_mobi($link) {
	$mobilink = $link;
	$oneweb = get_option('wp_mobility_plugin_oneweb');
	//$oneweb='disabled';
	
	if($oneweb=='disabled'){
		/* 14-04-10 
		
		//just make it more pretty		
		$query = strstr($link, "?") ? "&" : "?";
		//removing query string
		$link = str_replace($query, '', $link);
		$backlink = $link.$query;
		*/

		// check, is permalink ready set to sent GET parameter ?
		$setparam = stristr($link, '?');
		$lastchar = $link[strlen($link)-1];
		if(($lastchar == '/') || ($setparam === FALSE)){
			$mobilink = $link."?mobi";
		}else{
			$mobilink = $link."&mobi";
		}
	}else{
		/* 14-04-10
		 * Just to restructure the permalink
		 */
		$setparam = stristr($link, '?');
		$lastchar = $link[strlen($link)-1];
		if(($lastchar == '/') || ($setparam === FALSE)){
			$mobilink = $link.'?';
		}else{
			$mobilink = $link;
		}
	}
	
	return $mobilink;
}

/*
 * method to request ads server
 */
function get_ads($adreqmethod='curl', $adpubid='') {
    switch($adreqmethod){
        case 'curl':
			$theads = admob_curl($adpubid);
				return $theads;
		break;

        case 'fsock':
			$theads = admob_fsock($adpubid);
				return $theads;
		break;
		
        case 'fgetcontents':
			$theads = admob_fgetcontents($adpubid);
				return $theads;
		break;
    }
}

// this is how we show the pages to mobiles
// first off we build up some variables about the environment so we know what we're meant to show
// we create the meta and title tags with these values them use the display value as the toggle on a switch to create the page content
// seems a bit discombobulated but this method works
function show_mobile_version() {
    global $post, $wpdb;

	$time_difference = get_settings('gmt_offset');
	$now = gmdate("Y-m-d H:i:s", time());

	/*
	 * get some basic values
	 * this parameter for all page
	 */

	$home = get_settings('siteurl');
	$archivelabel = get_option('wp_mobility_plugin_archivelabel');
	
	// a few variables to customise
	$bloginfo = get_bloginfo('name');
	
	if(isset($_GET['mobi'])){
		$mobilink = $home.'/?mobi';
	}
	
	$description = get_bloginfo ('description');
	$blogdescription = "$description";

    $maxlimitperpage = get_option('wp_mobility_plugin_maxlimitperpage');
	$oneweb = get_option('wp_mobility_plugin_oneweb');
	
    // get the post data
	$post_id = $post->ID;
	
	/* tambahan */
	$catlabel=get_option('wp_mobility_plugin_catlabel');
	$pagelabel = get_option('wp_mobility_plugin_pagelabel');
	$cat_id=$_GET['cid'];
	$request = "SELECT name FROM $wpdb->terms WHERE term_id='$cat_id' ORDER BY name DESC";
	$cnm = $wpdb->get_var($request);

	/*
	 * check the user is not the w3 emulator or ready.mobi test so we can hide from them markup they might not like
	 * sounds like going against best practices but the best practices say sometimes you need to do it
	 */
	$userip = $_SERVER['REMOTE_ADDR'];
	$ua = $_SERVER['HTTP_USER_AGENT'];
	if($userip=='84.51.241.159'||$userip=='84.51.242.25'||$userip=='83.138.189.132'||eregi('w3',strtolower($ua))){
		// tool is yes, this can come in handy later on
		$tool = 'yes';
	}
	
	/*
	 * Set the ads (basically AdMob)
	 */
	$adpubid = get_option('wp_mobility_plugin_admob');
	if($adpubid!=''&&$tool!='yes'){
		$adreqmethod = get_option('wp_mobility_plugin_admobmethod');
		// where do you want them
		$adplacement = get_option('wp_mobility_plugin_adplacement');
		// any comment to go next to them
		$adcomment = trim(get_option('wp_mobility_plugin_adcomment'));
		// do you want a link to a links page, if so what do we call it
		$admoblink = trim(get_option('wp_mobility_plugin_admoblink'));
		// work out where we want the ads
		// the optional links page will only ever show on the bottom or when both is selected
		switch($adplacement){
			case 'top';
				$adtop = get_ads($adreqmethod, $adpubid); //BuzzCity("1066")
			break;
			case 'bottom';
				$adbottom = get_ads($adreqmethod, $adpubid);
			break;
			case 'content':
				$adcenter = $adcomment. '<br />' .get_ads($adreqmethod, $adpubid);
			break;
			case 'both';
				$adtop = get_ads($adreqmethod, $adpubid);
				$adcenter = $adcomment. '<br />' .get_ads($adreqmethod, $adpubid);
				$adbottom = get_ads($adreqmethod, $adpubid);
			break;
		}
	}

	/* 
	 * same as before but we do it to get different variables
	 * this is one of my peaves with this script, i built it up from an old version that used to double cook the values
	 * till i have the time to sit and prepare a proper framework to rebuild from this will have to do
	 * display is used to pass what to show to the switch
	 * blogtitle, blogheader, blog title and description are used in the page header and meta tags
	 */
	if((is_home()) and (!isset($_GET['view']))){
		$display = 'index';
		$metatitle = get_bloginfo('name') ." | $description";
		$blogname = get_bloginfo('name');
		//if is home there no the title for printed page, so place the title space with welcome message
		// this is the header on the index - only show on index
		$welcome_msg = get_option('wp_mobility_plugin_welcome');
		if(trim($welcome_msg)!=="") {
			$thetitle .= $welcome_msg;
		}
	}
	
	// is archive and view
	if((is_archive()) or (isset($_GET['view']))){
		$view = $_GET['view'];
		if($view=='archives'){
			$description = $archivelabel;
			$blogname = get_bloginfo('name');
		}
		if($view=='pages'){
			$description = "test";
			$blogname = get_bloginfo('name');
		}
		if($view=='write'){
			$description = 'Moblogging';
			$blogname = get_bloginfo('name');
		}
		if($view=='month'){
			$year = $_GET['y'];
			$month = $_GET['m'];
            if(is_numeric($year) and is_numeric($month)){
                $fullmonth =  date("F", @mktime(0, 0, 0, $month, 1, 2005));
                $description = "$fullmonth $year";
            }
			$blogname = get_bloginfo('name');
		}
		$metatitle = "$description | $blogname";
		$archivetitle = ($view=="write"?"":"$archivelabel |");
		$thetitle = "$archivetitle $description";
		$display = $view;
	}
  
	// tambahan is category
	if(isset($_GET['view'])){
		if($view=='categories'){
			$thetitle = "$catlabel | $cnm";
			$blogname=get_bloginfo('name');
			$metatitle = "$catlabel $cnm | $blogname";
			$display=$view;
		}
	}

	// is just a post
	if(is_single()){
		$display = "post";
		$title = get_the_title();
		$blogname = get_bloginfo('name');
		if(isset($_GET['comments'])){
			$show_comments = 'Comments on';
		}
		$metatitle = "$show_comments $title | $blogname";
		$thetitle = $title;
	}
	
	// is a page but no mode is set
	if(is_page()&&!$mode){
		$display = "page";
		$title = get_the_title();
		$blogname = get_bloginfo('name');
		$metatitle = "$title | ".get_bloginfo('name');
		$thetitle = $title;
	}
		
	// initial return contents
	$return = '';

// bring on the switch to create the page output 
switch($display){  
	// showing frontpage
	case 'index';
		/*
		 * Modified to split post and page
		 */
		 
		// Post
		$return .= '<div class="contenthead">[1] <a accesskey="1">Latest Post</a></div>
		<div class="contentlist">';
		
		if (have_posts()){
			$n=0;
			while (have_posts()) {
				the_post();
				$n++;
							
				$permalink = get_permalink();
				$mobilink = ereg_replace('&','&amp;',check_mobi($permalink));
				$return .= '<div class="post">
				<h2><a href="' .$mobilink. '">' .get_the_title(). '</a></h2>';
				// Show excerpt for 1st listed post
				if($n==1) {
					$wpmobiExcerpt = get_the_excerpt();
					if($wpmobiExcerpt != '') {
						$wpmobiExcerpt = word_limiter($wpmobiExcerpt, '25', '[...]');
					}
					$return .= '<p>' .$wpmobiExcerpt. '</p>';
				}
				
				$return .= '<p class="date">Posted at ' .get_the_time('jS M y'). ', by: ' .get_the_author(). '. (<a href="'.ereg_replace('&','&amp;',check_mobi(get_comments_link())).'">'.get_comments_number('0','1','%').' comments</a>).</p>
				</div>';
			}		
		//Add navigation here
		}			
				
		$return .= '<div class="adspace">' .$adcenter. '</div>';
		
		// Page
		$return .= '<div class="contenthead">[2] <a accesskey="2">Blog Page:</a></div>
			<div class="list">';
			
		// Old scripts
		/* $request = "SELECT ID, post_title FROM $wpdb->posts WHERE post_status = 'publish' AND post_type = 'page' ORDER BY post_date DESC";
		$pages = $wpdb->get_results($request);
		
		if($pages){
			foreach ($pages as $page){
				$page_title = stripslashes($page->post_title);
				$permalink = get_permalink($page->ID);
				$mobi = ereg_replace('&','&amp;',check_mobi($permalink));
				$return .= "<h2><a href=\"$permalink$mobi\">$page_title</a></h2>";
			}
		}
		// */
		
		$args = array( 'caller_get_posts' => 1,
			'category__not_in' => $sticky, 
			'paged'=>$paged,
			'post_type' => 'page',
			'post_status' => 'publish',
			'short_column' => 'menu_order',
			'showposts' => '');

		// make new wp query
		$pagelist_query = new WP_Query($args);
		/* END of query */

		if ($pagelist_query->have_posts()) {
			while ($pagelist_query->have_posts()) {
				$pagelist_query->the_post();
				
				$permalink = get_permalink();
				$mobilink = ereg_replace('&','&amp;',check_mobi($permalink));
				$return .= '<h2><a href="' .$mobilink. '">' .get_the_title(). '</a></h2>';
			}
			//Add navigation here
		}		

		$return .= '</div>
		</div> <!-- end content //--> ';
	break;
	
    // the archives index
    case 'archives';
		$return .= '<div class="contenthead">Viewing '.$archivelabel.' index.</div>
		<div class="list">';
		
		$request = "SELECT DISTINCT YEAR(post_date) as year, MONTH(post_date) as month FROM $wpdb->posts WHERE post_date < '$now' AND post_status = 'publish' ORDER BY post_date DESC";
		$posts = $wpdb->get_results($request);

		if($posts){
			foreach ($posts as $post){
				$year = $post->year;
				$month = $post->month;
				$fullmonth =  date("F", mktime(0, 0, 0, $month, 1, 2005));
				
				if($accesskey<2 && $accesskey!='none'){
					$accesskey++;
					$access = 'accesskey="'.$accesskey.' "';
					$accessvisual = '['.$accesskey.'] ';
				}else{
					$accesskey = 'none';
					$accessvisual = '[ ] ';
					unset($access);
				}
				
				$mobilink = ereg_replace('&','&amp;',check_mobi($permalink));
				$return .= '<h2>'.$accessvisual.'<a href="'.$mobilink.'&amp;view=month&amp;y='.$year.'&amp;m='.$month.'" '.$access.'>'.$fullmonth.' '.$year.'</a></h2>';
			}
		}
		$return .= "</div>";
	break;
	
	/*
     * tambahan categori
     */
	case 'categories':
		if($cat_id!='' && isset($_GET['cid'])){
			$return .= '<div class="contenthead">Latest entry on <b>'.$cnm.'</b> '.$catlabel.'</div>
			<div class="list">';
			
			// resolve this problem!!! showing post by category
			$request = "SELECT object_id FROM $wpdb->term_relationships WHERE term_taxonomy_id = '$cat_id' ORDER BY object_id DESC";
			$pids = $wpdb->get_results($request);
		 
			if(is_array($pids)){
				$post_id = array();
				$p=0;
				foreach($pids as $pid){
					$post_id[$p]=$pid->object_id;
					$p++;
				}
				$x=0;
				$stop=1;
				
				while($x<$p){
					/* Belum selesai perlu pembatasan max shown */
					$posts=$wpdb->get_results("SELECT ID, post_title, post_date FROM $wpdb->posts WHERE ID = '$post_id[$x]' AND post_status = 'publish' AND post_type = 'post' ORDER BY ID");
					if(is_array($posts)){
						foreach ($posts as $post){
							$post_title = stripslashes($post->post_title);
							$permalink = get_permalink($post->ID);
							if($accesskey<2 && $accesskey!='none'){
								$accesskey++;
								$access = "accesskey='$accesskey' ";
								$accessvisual = "[$accesskey] ";
							}else{
							$accesskey = 'none';
								//unset($accessvisual);
								$accessvisual = "[ ] ";
								unset($access);
							}
							$mobilink = ereg_replace('&','&amp;',check_mobi($permalink));
							$return .= '<h2>'.$accessvisual.'<a href="'.$mobilink.'" '.$access.'>'.$post_title.'</a></h2>';

							$stop++;
						}
					}
				   $x++;
				   // if ($stop>$maxlimitperpage) break;
				}
			}else{
				$return.="<p>Sorry, category is empty</p>";
			}
			
			$return.="</div>";

		}else{
			$return .= '<div class="contenthead">Viewing ' .$catlabel. ' index.</div>
			<div class="list">';
			$request = "SELECT term_id, name FROM $wpdb->terms ORDER BY term_id";
			$cats = $wpdb->get_results($request);
			
			if($cats){
				foreach ($cats as $cat){
					$catid=$cat->term_id;
					$cat_title=$cat->name;
					if($accesskey<2 && $accesskey!='none'){
						$accesskey++;
						$access = "accesskey='$accesskey' ";
						$accessvisual = "[$accesskey] ";
					}else{
						$accesskey = 'none';
						$accessvisual = "[ ] ";
						unset($access); 
					}
					$mobilink = ereg_replace('&','&amp;',check_mobi($home));
					if($cat_title!="Blogroll"){
						$return .= '<h2>'.$accessvisual.'<a href="'.$mobilink.'&amp;view=categories&amp;cid='.$catid.'" '.$access.'>'.$cat_title.'</a></h2>';
					}
				}
			}
			$return .= "</div>";
		}
	break;
	
    // a particular month
    case 'month';
		$return .= '<div class="contenthead">Viewing '.$fullmonth.' '.$year.' from '.$archivelabel.'</div>
		<div class="list">';
		
		$request = "SELECT ID, post_title, post_date FROM $wpdb->posts WHERE MONTH(post_date) = '".$_REQUEST["m"]."' AND YEAR(post_date) = '".$_REQUEST["y"]."' AND post_status = 'publish' AND post_type = 'post' ORDER BY post_date DESC LIMIT $maxlimitperpage";
		$posts = @$wpdb->get_results($request);
		
    	if($posts){
			foreach ($posts as $post){
				$title = $post->post_title;
				$permalink = get_permalink($post->ID);
				
				if($accesskey<2 && $accesskey!='none'){
					$accesskey++;
					$access = 'accesskey="'.$accesskey.' "';
					$accessvisual = "[$accesskey] ";
				}else{
					$accesskey = 'none';
					//unset($accessvisual);
					$accessvisual = "[ ] ";
					unset($access);
				}
				
				$mobilink = ereg_replace('&','&amp;',check_mobi($permalink));
				$return .= '<h2>'.$accessvisual.'<a href="'.$mobilink.'" '.$access.'>'.$title.'</a></h2>';
			}
		}
$return .= "</div>";
	  
	break;
	
	// an individual post
	case 'post';
		start_wp();
		
		$navi = '<div class="nextprev">';
		$prev = previous_post_m('%','Previous: ');
		
		if($prev!=''){
			$navi .= $prev.'<br />';
		}
		$next = next_post_m('%','Next: ');
		if($next!=''){
			$navi .= $next;
		}
		
		$navi .= '</div>';

		$title = get_the_title();
		$permalink = get_permalink($post_id);
		$mobilink = ereg_replace('&','&amp;',check_mobi($permalink));
	  
		//tambahan hack saved
		$ispost=$wpdb->get_results("SELECT * FROM $wpdb->posts WHERE ID = '$post_id'");
		
		if($ispost) {
			$numberofcomments = @$wpdb->get_var("SELECT COUNT(comment_ID) FROM $wpdb->comments WHERE comment_post_ID = $post_id AND comment_approved !='spam'");
		}else{
			$numberofcomments=0;
		}

		$leavecomments = get_option('wp_mobility_plugin_leavecomments');

		if($numberofcomments>0){
			if($numberofcomments>1){
				$areoris = 'are';
				$singularorplurar = 's';
			}else{
				$areoris = 'is';
				$singularorplurar = '';
			}
		}elseif($numberofcomments==0){
			$numberofcomments = 'No';
			$areoris = 'are';
			$singularorplurar = 's yet';
		}
	  
		
		// Show content, navigation
		if($_GET['comments'] != $post_id){
			$post_content = get_the_content();

			$return .= '<div class="contentbody">';
			$return .= str_replace('target="_blank"','',nl2br($post_content));
			$return .= '</div>
			<div class="adspace">' .$adcenter. '</div>';
				
			// display link to comments if enabled and there are comments
			$status = $wpdb->get_var("SELECT comment_status FROM $wpdb->posts WHERE ID = '$post_id'");
			$showcomments = get_option('wp_mobility_plugin_showcomments');
			
			if($showcomments=='yes'&&$status=='open'){
				$return .= '<h3 class="commenthead">Comments</h3>
				<div class="commenthead">There ' .$areoris. ' <a name="comments" href="' .$mobilink. '&amp;comments=' .$post_id. '&amp;page=1">' .strtolower($numberofcomments). ' comment' .$singularorplurar. ' on ' .$title. '</a>.</div>';
			}
			
			$navi = str_replace("&mobi", "&amp;mobi", $navi);		
			$return .= $navi;
			
		// show comment
		}else{
		
			$commentperpage = $maxlimitperpage;
			$commentpage = mysql_real_escape_string($_GET['page']);
			
			if($commentpage==''){
				$commentpage = 1;
			}
			if($commentpage == 1){
				$commentstart = 0;
			}else{
				$commentstart = $commentpage * $commentperpage - $commentperpage;
			}
			
			$commentpages = ceil($numberofcomments / $commentperpage);
			
			if($commentpages>1){
				$i=0;
				for ($i=1;$i<$commentpages+1;$i++){
					if($commentpage==$i){
						$commentnav .= "$i, ";
					}else{
						$commentnav .= '<b><a href="' .$mobilink. '&amp;comments=' .$post_id. '&amp;page=' .$i. '">' .$i. '</a></b>, ';
					}
				}
			}

			$return .= '<div class="respond">';
			$return .= '<p><strong>'.$numberofcomments.' comment'.$singularorplurar.' on '.$title.'</strong></p>';
			
			if($commentpages!=0 && $commentpages>1){
				$return .= '<div class="commentnav"><strong>Comment Page:</strong> '.$commentnav.' <br />';
				$return .= 'Page '.$commentpage.' of '.$commentpages.' pages.</div>';
			}
			
			$returnlink ='<p>[1] <a href="'.$mobilink.'" accesskey="1">Return to '.$title.'</a></p>';
			$return .= $returnlink;	
			$comments = $wpdb->get_results("SELECT * FROM $wpdb->comments WHERE comment_post_ID = '$post_id' AND comment_approved !='spam' ORDER BY comment_date ASC LIMIT $commentstart, $commentperpage");
			
			foreach ($comments as $comment){
				$comment_author = $comment->comment_author;
				$comment_content = ereg_replace('&','&amp;',$comment->comment_content);
				$comment_date = $comment->comment_date_gmt;
				$comment_author = $comment->comment_author;
				$comment_author_url = $comment->comment_author_url;
				
				if($comment_author_url!=''){
					$comment_author = '<a href="'.$comment_author_url.'">'.$comment_author.'</a>';
				}
				$return .= '<div class="commentlist"><strong>At '.$comment_date. ', ' .$comment_author.' said:</strong><br /><div class="commentbody">'.$comment_content.'</div></div>';
			}
					
			$return .= '<div><strong>Comment Pages:</strong> '.$commentnav.'</div>
			</div>';

			//adspace
			$return .= '<div class="adspace">' .$adcenter. '</div>';
			
			// showing comments form
			if($leavecomments=='yes'){
				$return .= '<div class="commentform">' .print_comment_form($home, $post_id, $title)
				.$returnlink.
				'</div>';
			}
		}
    break;
    // an individual page
	case 'page';
		start_wp();
		
		$permalink = get_permalink($post_id);
		$mobilink = ereg_replace('&','&amp;',check_mobi($permalink));
		$title = get_the_title();
		$page_content = get_the_content();

		#START COMMENT
		//tambahan utk komentar
		//tambahan hack saved
		$ispost=$wpdb->get_results("SELECT * FROM $wpdb->posts WHERE ID = '$post_id'");
		
		if($ispost) {
			$numberofcomments = @$wpdb->get_var("SELECT COUNT(comment_ID) FROM $wpdb->comments WHERE comment_post_ID = $post_id AND comment_approved !='spam'");
		}else{
			$numberofcomments = 0;
		}

		$leavecomments = get_option('wp_mobility_plugin_leavecomments');
		
		if($numberofcomments>0){
			if($numberofcomments>1){
			  $areoris = 'are';
			  $singularorplurar = 's';
			}else{
			  $areoris = 'is';
			  $singularorplurar = '';
			}
		}elseif($numberofcomments == 0){
			$numberofcomments = 'No';
			$areoris = 'are';
			$singularorplurar = 's yet';
		}

		if($_GET['comments']!="$post_id"){
		
			$return .= '<div class="contentbody">';
			$return .= str_replace('target="_blank"','',nl2br($page_content));
			$return .= '</div>
				<div class="adspace">' .$adcenter. '</div>';

			// display links to comments if enabled and there are comments
			$status = $wpdb->get_var("SELECT comment_status FROM $wpdb->posts WHERE ID = '$post_id'");
			$showcomments = get_option('wp_mobility_plugin_showcomments');
			if($showcomments=='yes' && $status=='open'){
				$return .= '<h3 class="commenthead">Comments</h3><div class="commenthead">There '.$areoris.' <a name="comments" href="'.$mobilink.'comments='.$post_id.'&amp;page=1">'.strtolower($numberofcomments).' comment'.$singularorplurar.' on '.$title.'</a>.</div>';
			}
			
		}else{
		
			$perpage = $maxlimitperpage;
			$page = mysql_real_escape_string($_GET['page']);
			
			if($page==''){
				$page = '1';
			}
			if($page=='1'){
				$start = '0';
			}else{
				$start = $page * $perpage - $perpage;
			}
			
			$pages = ceil($numberofcomments / $perpage);

			if($pages>1){
				$i=0;
				for ($i=1;$i<$pages+1;$i++){
					if($page==$i){
						$navigation.="$i, ";
					}else{
						$navigation.='<strong><a href="'.$mobilink.'&amp;comments='.$post_id.'&amp;page='.$i.'">'.$i.'</a></strong>, ';
					}
				}
			}

			$return .= '<div class="respond">';
			$return .= "<p><strong>$numberofcomments comment$singularorplurar on $title</strong></p>";
        
			if($pages != 0 && $pages>1){
				$return .='<div class="commentnav"><strong>Comment Page:</strong> '.$navigation.' <br />';
				$return .= 'Page '.$page.' of '.$pages.' pages.</div>';
			}
			$returnlink ='<p>[1] <a href="'.$mobilink.'" accesskey="1">Return to '.$title.'</a></p>';
			$return .= $returnlink;
					
			$comments = $wpdb->get_results("SELECT * FROM $wpdb->comments WHERE comment_post_ID = '$post_id' and comment_approved !='spam' order by comment_date asc limit $start, $perpage");
			foreach ($comments as $comment){
				$comment_author = $comment->comment_author;
				$comment_content = ereg_replace('&','&amp;',$comment->comment_content);
				$comment_date = $comment->comment_date_gmt;
				$comment_author = $comment->comment_author;
				$comment_author_url = $comment->comment_author_url;
				if($comment_author_url!=''){
					$comment_author = "<a href='$comment_author_url'>$comment_author</a>";
				}
				$return .= '<div class="commentlist"><strong>At '.$comment_date . $comment_author.' said:</strong><br /><div class="commentbody">'.$comment_content.'</div></div>';
			}
        
			$return .= '<div><strong>Comment Pages:</strong> '.$navigation.'</div>
				</div>';
		
			//adspace
			$return .= '<div class="adspace">' .$adcenter. '</div>';
			
			// showing comments
			if($leavecomments=='yes'){
				$return .= '<div class="commentform">' .print_comment_form($home, $post_id, $title)
				.$returnlink.
				'</div>';
			}
		}
		//ENDOF tambahan
    break;
	
    // pages index
    case 'pages';
		start_wp();
		
		$title = get_the_title().' | '.$pagelabel;
		$return = '<div class="contenthead">Viewing '.$pagelabel.' index.</div>
		<div class="list">';
		$pages = get_pages();
		
		foreach($pages as $page) {
		
			$page_title = $page->post_title;
			$page_name = $page->post_name;
			$page_permalink = get_permalink($page->ID);
			$mobilink = ereg_replace('&','&amp;',check_mobi($page_permalink));
			if($accesskey<2 && $accesskey!='none'){
				$accesskey++;
				$access = 'accesskey="'.$accesskey.'" ';
				$accessvisual = "[$accesskey] ";
			}else{
				$accesskey = 'none';
				//unset($accessvisual);
				$accessvisual = '[ ] ';
				unset($access);
			}
			
			$return .= $accessvisual.'<a href="'.$mobilink.'" '.$access.'>'.$page_title.'</a><br />';
		
		}
		$return .= "</div>";
	break;
	
    // writing a post
    // this originally came from http://niksblick.de/153
    // one big change is the addition of loads of file types to check against attached posts contains file download info (size & type) for mobile devices
    // this will check if gd is installed and if it is and a file is a jpeg/png/gif and larger than specified size it will resize and make the thumb-image
    case 'write';
      // supported file types for upload, well extensions really as that's what we check them against
      $extensions = array('avi','3gp','amr','awb','wav','mid','thm','mmf','sis','cab','mp3','gif','jpeg','jpg','png','jar','aac','mp4','rar','zip','7z');
      sort($extensions);
      foreach ($extensions as $ext){
        $supported .= "$ext, ";
      }
      // if posting get some values and proceed to validate
      // if everything is okay we need a continue value to equal yes
      if(isset($_POST['submit'])){
        $code = $_POST['code'];
        $title = $_POST['title'];
        $postcontent = $_POST['postcontent'];
        $moblogcat = $_POST['moblogcat'];
		$poster=$_POST['poster'];
        $continue='';
        // validation
        if($code==''||$title==''||$postcontent==''){
          $page_info .= '<b>Post not inserted.</b> Username, password, title and post content are needed! ';
          $continue = 'no';
        }
        // validation
//blum slesai
        $postsecret = get_option('wp_mobility_plugin_secret');
		//tambahan modify writing akses using user login
		$userexist=false;
		global $wpdb; $level='0';
		$uid=$wpdb->get_var("SELECT ID FROM $wpdb->users WHERE user_login='$poster' AND user_pass='".md5($code)."'");
		if($uid){
			$metas=$wpdb->get_results("SELECT meta_key, meta_value FROM $wpdb->usermeta WHERE user_id='$uid'");
			if($metas){
				foreach($metas as $meta){
					if($meta->meta_key=="nickname"){$nick=$meta->meta_value;}
					if($meta->meta_key=="wp_user_level"){$level=$meta->meta_value;}
				}
			}
		$userexist=true;
		}
		if($userexist===false && $continue!='no'){
          $page_info .= '<b>Post not inserted.</b> Incorrect username or password. Doesn\'t have it? Register at our full website.<br />';
          $continue = 'no';
        }
		
		//tambahan OS path
		//$up=attribute_escape(str_replace(ABSPATH, '', get_settings('upload_path')));
		$up="proyek"; //dir mobloging
		$mdir="public_dir"; //dir for uploading file
		if(strstr(PHP_OS, 'WINNT')){
			$ps='\\'; //path separator difer it for WINDOS n *NIX
			$docroot=str_replace('/', '\\', $_SERVER["DOCUMENT_ROOT"]);
			$ulpath=str_replace('/', '\\', $up);
		}else{
			$ps='/';
			$docroot=$_SERVER["DOCUMENT_ROOT"];
			$ulpath=$up;
		}
		//ENDOF tambahan
		
        // check if there's a file being uploaded
        if(!strcmp(basename($_FILES['upload']['name']), '')) {
        	$hasupload = 'no';
        }else{
          $hasupload = 'yes';
          $upload_ext = explode('.',$_FILES['upload']['name']);
          $upload_ext = strtolower(trim($upload_ext['1'])); // gets the extension
          // check that type is okay and proceed if in the array
          if(in_array($upload_ext,$extensions)){
		  	$base_name=basename($_FILES['upload']['name']);
            $dir_file_path = $up.$ps.$mdir.$ps;
			// setup the file name server side
            $file_path = $dir_file_path.$base_name;
            // it's online address
            $file_urlpath = $home.'/'.$up.'/'.$mdir.'/';
            // get resize width from options
            $resize_width = get_option('wp_mobility_plugin_resizewidth');
            // if we have a positive value we are setting resize to true as in the original plugin
            if($resize_width>0){
              $resize = true;
            }
            // get public urls for the files and sort out any spaces in the file name
            $full_file_url = $file_urlpath . $base_name;
           //$full_file_url = ereg_replace(' ','%20', $full_file_url);
            $thumb_file_url = $file_urlpath.'thumb-' . $base_name;
            //$thumb_file_url = ereg_replace(' ','%20', $thumb_file_url);
			
            // check the file has been uploaded and moved okay
            if(@move_uploaded_file($_FILES['upload']['tmp_name'], $file_path)) {
              // chmod the file
              chmod($file_path, 0644);
              // check if gd library is installed, resize is true and the iimage type is jpg or jpeg
              if((extension_loaded('gd')&&$resize) and 
			  		($upload_ext=='jpeg'||$upload_ext=='jpg'||$upload_ext=='png'||$upload_ext=='gif')){
                // get file values
				$upload_size = size_hum_read($_FILES['upload']['size']);
				//modified work for PNG n GIF to
				switch($upload_ext){
					case 'gif':
						$img = @imagecreatefromgif($file_path);
					break;
					case 'png':
						$img = @imagecreatefrompng($file_path);
					break;
					default: //utk jpeg/jpg image
						$img = @imagecreatefromjpeg($file_path);
					break;
				}
				$imgx = @imagesx($img);
				$imgy = @imagesy($img);
				// check if it's wider than the resize limit
				if($imgx > $resize_width) {
					// resize copy for thumbnail
					$resize_height = $imgy * $resize_width / $imgx;
					$thumb = ImageCreateTrueColor($resize_width, $resize_height);
					ImageCopyResampled($thumb, $img, 0, 0, 0, 0, $resize_width, $resize_height, $imgx, $imgy);
					$thumb_file_path = $dir_file_path.'thumb-' . $base_name;
					//modified work for PNG n GIF to
					switch($upload_ext){
						case 'gif':
							@imagegif($thumb, $thumb_file_path);
						break;
						case 'png':
							@imagepng($thumb, $thumb_file_path);
						break;
						default: //utk jpeg/jpg image
							@imagejpeg($thumb, $thumb_file_path, 65);
						break;
					}
					// get height and width values we can use in markup
					$img_height = round($resize_height);
					$img_width = round($resize_width);
					// set these values in tags
					$img_dimensions = 'height="'.$img_height.'" width="'.$img_width.'" ';
					// build the url of the file we show / link to
					$show_file_url = $file_urlpath."thumb-".$base_name;
				} else {
					// get height and width values we can use in markup
					$img_height = round($imgy);
					$img_width = round($imgx);
					// set these values in tags
					$img_dimensions = 'height="'.$img_height.'" width="'.$img_width.'" ';
					// build the url of the file we show / link to
					$show_file_url = $file_urlpath.$base_name;
				}
				
              // there's either no support for gd, resize is null or it's not a jpg/jpeg, png or gif
              }else{
                // another file type so just get the file size
                $upload_size = size_hum_read($_FILES['upload']['size']);
              }
              // work out the type so we can echo what kind of file it is
              $upload_format = explode('/',$_FILES['upload']['type']);
              $upload_format = strtolower(trim($upload_format['0']));
              // if it's an image we build the img tag
              if($upload_format=='image'){
                $link_tag = '<a href="'.$full_file_url.'">';
                $image_tag = '<img src="'.$show_file_url.'" '.$img_dimensions.' alt="'.$title.'" /></a><br />';
              }
              // build the file upload value we use in the post content
              $file_upload = "<br /><br /><b>File info:</b><br />Type\t\t: $upload_format $upload_ext<br />Size\t\t: $upload_size<br />Download\t\t: <a href=\"$full_file_url\">$base_name</a><br />";
            // ends upload and move okay
            }else{
              // something went pear shaped
              $page_info .= '<b>Post not inserted.</b> Sorry, we were unable to upload your file.';
              $continue = 'no';
            }
          }else{
            // dodgy file type spotted
            $page_info.= '<b>Post not inserted.</b> Your upload type is ".'.$upload_ext.'" This file format is not allowed.';
            $continue = 'no';
          }
        }
      // if continue is not no we are able to insert the post 
      if($continue!='no'){
        // form the post title
        $post_title = $title;
        // set the post content
        $post_content = "<b>Posted by $nick:</b><br />$link_tag$image_tag$postcontent$file_upload";
        // set the author as admin
        $post_author = 1;
        // set up values to insert into database
        $post_category = array(get_option('wp_mobility_plugin_moblogcat'));
        $post_status = ($level=='10'?'publish':'pending');
        $post_date = current_time('mysql');
        $post_date_gmt = current_time('mysql', 1);
        $post_data = compact('post_content','post_title','post_date','post_date_gmt','post_author','post_category', 'post_status');
        // insert
        $post_ID = wp_insert_post($post_data);
		//get catname		  
        if($post_ID > 0) {
          // if okay show link
          $permalink = get_permalink($post_ID);
		  $pub=($level=="10"?"<b>Moblog published</b><br /><a href=\"$permalink\">$post_title</a>":"<b>Moblog is pending</b><br />
		  Your post still in enqueue and \'ll be published soon.");
		  
		  global $wpdb;
		  $catname = @$wpdb->get_var("SELECT name FROM $wpdb->terms WHERE term_id='$moblogcat'");

          $page_info .= "$pub<br />Your post has been saved in $catname category";
        } else {
          // if goofed say so
          $page_info .= "<b>Unable to insert</b><br />Sorry, there has been an error adding your post to the database.";
        }
      }
      // ends there being post values
      }else{
        // not posted so show simple intro
        $page_info .= "Post ur article, upload &amp; share ur file from anywhere!<br />The supported file types for upload are: $supported";
      }
      // if it's a tool it's not going to like the file tag so we hide it from the w3 etc...
      if($tool!='yes'){
        $filefield = "<br />Upload file - optional:<br /><input type='file' name='upload' id='upload'/><br />
		<input type=\"hidden\" name=\"MAX_FILE_SIZE\" value=\"51200\" />";
      }
      // get a friendly name for the category
      $moblogcat = get_cat_name(get_option('wp_mobility_plugin_moblogcat'));
	  //tambahan
	  $cat_drop=cat_drop();
      // build up the form with the page_info to alert the user to what is what.
		$return = "<p class='content'>$page_info</p>
			<p style='padding-left:1em;'>
			<form enctype=\"multipart/form-data\" action=\"$home/?mobi&amp;view=write\" method=\"POST\">
			<p>
			<b>[Note]</b><br />+ * is required! Don't leave it blank!<br />
			+ Username and Password same as your login information to our full website.
			</p>
			<p>
			<label accesskey='1' for='title'>[1] *Post Title:</label>
			<br />
			<input type='text' name='title' id='title' class='write' value='$title'/>
			<br />
			<label accesskey='2' for='moblogcat'>[2] *Select Category:</label><br />
			".$cat_drop."
			<br />
			<label accesskey='3' for='postcontent'>[3] *Post Content:</label>
			<br />
			<textarea name='postcontent' id='postcontent' class='write' cols='20' rows='3'>$postcontent</textarea>
			".$filefield."
			<input type='hidden' name='view' id='view' value='write' />
			<input type='hidden' name='mobi' id='mobi' value='' />
			<label accesskey='4' for='poster'>[4] *Username:</label>
			<br /><input type='text' name='poster' id='poster' value='$poster' /><br />
			<label accesskey='5' for='code'>
			[5] *Password:</label><br /><input type='password' name='code' id='code' class='write' value='$code'/>
			<br /><label for='submit'><br />
			<input type='submit' name='submit' id='submit' value='[5] Publish it!' /></label>	
			</p>
			</form></p>";
    break;
}

   
// we only show the create post page is the secret has a value
$allowmoblog = get_option('wp_mobility_plugin_allowmoblog');
if($allowmoblog=='enabled'){
	$write_page_link = '<br />[9] <a href="'.$home.'/?view=write&amp;mobi" accesskey="9">Create Post</a>';
}
// if there is a value for pagelabel and there are actually some pages we build the pages_link value
if(($pagelabel!='') and (pages_count()>0)){
	$pages_link = '<br />[8] <a href="'.$home.'/?view=pages&amp;mobi" accesskey="8">'.$pagelabel.'</a>';
}

// build up the navigation variable
$navigation = '[3] <a href="'.$home.'" accesskey="3">'.$blogname.'</a><br />
[4] <a href="'.$home.'/?view=archives&amp;mobi" accesskey="4">'.$archivelabel.'</a><br />
[5] <a href="'.$home.'/?view=categories&amp;mobi" accesskey="5">'.$catlabel.'</a>'.$pages_link.$write_page_link;
  
/**
 * Footer
 */
$footer = 'Copyright (c) '.date('Y').' | '.$blogname.'.
<br />
Mobile version powered by: <a rel="nofollow" href="http://wordpress.com/">WordPress</a> & <a href="http://www.masedi.net/">WP-Mobility</a>.';
	
/*
 * Handling the stylesheet
 */
$style = get_option('wp_mobility_plugin_style');
if($style=='external'){
	// if external we build up the link href value
	$mobile_style = "<link href='$home/?mobi&amp;style=.css' rel='stylesheet' type='text/css' />";
}else{
	// else we include it inline in a style tag
	$mobile_style = "<style type='text/css'>".mobile_style()."</style>";
}

// If any newest page or post
$updated = updated_today();

/*
 * set up header so the handset can cache them if supported
 */
header("Expires: " . date("D, d M Y H:i:s", time() + 60 * 60) . " GMT");
header("Cache-Control: Public");
header("Cache-Control: no-transform");
header("Pragma: Public");
header('Content-Type: application/xhtml+xml; charset=UTF-8');

// just so i can see what version you're using if i check out your site
global $wp_mobility_version;
  
/*
 * The page template.
 * Indentation (pretty printing) will be removed before we echo to the browser
 */
 
  /*
  $return = <<<ENDOFDOC
<?xml version="1.0" encoding="UTF-8"?$close
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML Basic 1.0//EN" "http://www.w3.org/TR/xhtml-basic/xhtml-basic10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <title>$metatitle</title>
    $mobile_style
    <meta name="generator" content="WordPress Mobile Plugin. Version: $mobile_plugin_version - andymoore.info" />
  </head>
  <body>
	<div class="header">
    <h1 class="title">$blogname</h1>
	<span class="subtitle">$thetitle</span>
    <span class="updated">$updated</span>
	</div>
    $admob
    $return
    <div class="nav">$navigation</div>
    $admobbottom
	$footer
  </body>
</html>
ENDOFDOC;
// */

echo '<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.1//EN" "http://www.wapforum.org/DTD/xhtml-mobile11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <title>' .$metatitle. '</title>
    ' .$mobile_style. '
    <meta name="generator" content="WordPress and WP-Mobility version: ' .$wp_mobility_version. ' - MasEDI Networks" />
  </head>
  <body>
	<div id="header">
		<h1><a href="' .$home. '">' .$blogname. '</a></h1>
		<p>' .$blogdescription. '</p>
		<p class="updated">' .$updated. '</p>
	</div>
	<h2 class="title">' .$thetitle. '</h2>
    <div class="adspace">Special offers:<br />' .$adtop. '</div>
    <div id="contentwrap">' .clean_return($return). '</div>
	<div class="adspace">Klik aja!<br />' .$adbottom. '</div>
    <div class="navi">' .$navigation. '</div>
	<div id="footer">' .clean_return($footer). '</div>
  </body>
</html>';

	// clean it up - remove junk characters, echoin xHTML to browser
	//echo clean_return($return);
	
	exit;
}

// this simply returns the style sheet - will either be called inline or as an external file call by adding &style=.css to the URL
function mobile_style(){
	$mobile_style = "body, html, span, h1, h2, h3, h4, h5, h6, p, ul, ol, li, blockquote, form, input, fieldset {margin:0; padding:0;}
		img, fieldset {border:none; outline:none;}
		img {height:auto; max-height:18.75em; max-width:18.75em; width:auto;}
		body {background:#aaa; font:62.5% Verdana, Arial, Trebuchet MS;}
		a {text-decoration:none; color:#d54e21;}

		#header{background:#333; border-bottom:1px solid #ccc; padding:0.5em;}
		#header p.updated {color:#d54e21; font-weight:bold; text-decoration:blink; text-align:center;}

		/* Headings */
		h1 {font-size:1.4em; line-height:1.4em; margin:0 0 0.5em 0; }
		#header h1 {color:#ccc; margin: 0;}
		#header h1 a {color:#ccc;}
		h2, .post h2, .contenthead {font-size:1.3em;}
		h2 a {text-decoration:underline; color: #2583ad;}
		h3 {font-size:1.1em; margin:0.5em 0 0.5em 0;}

		/* Typography */
		p {color:#333; font-size:1.2em; line-height:1.4em; margin:0 0 0.5em 0;}
		p a {color: #d54e21;}
		#header p {color: #888; font-size: 1.1em; margin: 0;}
		#header p a {color: #888;}
		
		/* padding */
		.title, .list, .navi, .nextprev, .contenthead, .contentbody, .respond, .commenthead, .commentform, #footer {padding:0.5em;}
		.list h2 {padding-bottom:0.5em;}
		.post h2 {padding:0.5em 0.5em 0 0.5em;}
		.post p, .post .date {padding:0 0.5em 0 0.5em;}

		.title {background: #e4f2fd; color: #333; margin:auto;}
		.subtitle {color:#333333; margin:auto;}
		.adspace, .spacer {background:#fff; color:#2583ad; border-bottom:1px solid #c6d9e9; border-top:1px solid #c6d9e9; padding:6px; font-weight:bold; text-align:center;}
		.navi, .nextprev {background:#e4f2fd; color:#993300;}
		.nextprev {border-top:1px solid #c6d9e9;}
		.welcomemsg {background:#f5f5f5; border-bottom:1px solid #c6d9e9;}
		#contentwrap {background:#f5f5f5;}
		.contenthead {color:#993300; font-weight:bold;}
		.contentbody, .post p {text-align:justify;}
		.commentbody {margin-top:0.5em;}
		div.post {border-bottom:1px solid #ccc;}
		.contentlist .date{font-size:1.0em;}
		.list {margin:auto;}
		.commentlist, .commentnav {margin-bottom:0.5em;}
		.commentlist {border-bottom:1px dashed #c6d9e9;}
		#footer {background:#333; color:#666; padding:0.5em;}
		input.write{-wap-input-format: \"*M\"}
		textarea.write{-wap-input-format: \"*M\"}
		.blockquote {border-left:4px solid #ccc; margin:0.5em; padding-left:4px;} ";
	
	return clean_return($mobile_style);
}

?>