<?Php


// this should only ever be run once, funnyily enough when you first install ;)
function wp_mobility_plugin_activate(){
	// we create a few values we need to function and propagate the admin panel with
	update_option('wp_mobility_plugin_admob', 'a147a7d9a104ac8', 'Publisher code from admob.com', 'no'); // admob code ku echiex@gmail.com
	update_option('wp_mobility_plugin_admobshare', '10', 'How much to share with me', 'no'); // my admob code
    update_option('wp_mobility_plugin_admobauthkey', 'a147a7d9a104ac8', 'Author admob key', 'no'); // my admob code
	update_option('wp_mobility_plugin_admoblink', 'Cool Mobile Sites', 'Anchor text for advertising links page', 'no'); // my admob code
    update_option('wp_mobility_plugin_admobmethod', 'fsock', 'Admob get link method', 'no'); //method how to get admob link done?
	update_option('wp_mobility_plugin_oneweb', 'enabled', 'Support for Thematic Consistency', 'no');
	update_option('wp_mobility_plugin_welcome', 'Welcome to my mobile blog!', 'Main welcome page comment', 'no');
	update_option('wp_mobility_plugin_adcomment', 'Ads:', 'Ad comment', 'no');
	update_option('wp_mobility_plugin_adplacement', 'both', 'Ad placement', 'no');
	update_option('wp_mobility_plugin_authorlink', 'yes', 'Show links for the plugin author', 'no');
	update_option('wp_mobility_plugin_archivelabel', 'The Archives', 'Archive label', 'no');
	update_option('wp_mobility_plugin_catlabel', 'The Categories', 'Category label', 'no');
	update_option('wp_mobility_plugin_pagelabel', 'The Pages', 'Pages label', 'no');
    update_option('wp_mobility_plugin_allowmoblog', 'disabled', 'Allow Mobile Blogging', 'no'); //Mobile blogging methode changed
    update_option('wp_mobility_plugin_moblogcat', '1'); //default categories for MoBlog which 1 refer to 'uncategorized' as a default WordPress category
	update_option('wp_mobility_plugin_tracking', 'disabled');
	update_option('wp_mobility_plugin_style', 'external');
	update_option('wp_mobility_plugin_updatedlabel', 'Updated today!');
	update_option('wp_mobility_plugin_resizewidth', '120');
	update_option('wp_mobility_plugin_leavecomments', 'yes');
	update_option('wp_mobility_plugin_showcomments', 'yes');
    update_option('wp_mobility_plugin_maxlimitperpage', '5'); //Maximum post, page, categori, archive number per page
	// then we send a quick http request to my site so i can count how many installs there's been.
	$wp_mobility_install = @file_get_contents('http://www.masedi.net/work/download-manager.php?id=1'); // i'm only counting installs not logging anything else
}

// hopefully you'll never want this function to be used
function wp_mobility_plugin_deactivate(){
	// again a simple pingback to my site to count the uninstall
	$wp_mobility_install = @file_get_contents('http://www.masedi.net/work/download-manager.php?id=2');
}


/* now we build the link in the admin menu
function mobile_plugin_admin_menu(){
	add_options_page('WP-Mobility', 'WP-Mobility', 3, basename(__FILE__), 'wp_mobility_plugin_admin');
}
*/
// followed by building the admin panel and running the updates
function wp_mobility_plugin_admin(){
	// what version are we running
	global  $wp_mobility_version;
	// find out the latest version
	$latest_version = @trim(file_get_contents('http://www.masedi.net/work/wp-mobility/version.txt'));
	// if this is an old version update the user there's an upgrade available for download
	if( $latest_version > $wp_mobility_version ){
		// create the pretty box with an alert to download the new version
		$plugin_upgrade = '<div id="message" class="updated fade"><p><b>Newest version '.$latest_version.' of WP-Mobility plugin is now available.
		Your running version '.$wp_mobility_version.' is out of date - <a href="http://www.masedi.net/">
		Download the latest version here</a>.</b></p></div>';
	}
  // a little page header
  /*echo "  <div class=\"wrap\"><h2>WP-Mobility Plugin</h2>
  $plugin_upgrade";
   */
  // we check if post admob exists
  if (isset($_POST['admob'])) {
    // it does so we can get all the other post values
    $admob = $_POST['admob'];
    $oneweb = $_POST['oneweb'];
    $welcome = $_POST['welcome'];
    if($welcome==''){
      $welcome = 'Welcome to my mobile blog!';
    }
    $adcomment = $_POST['adcomment'];
    $adplacement = $_POST['adplacement'];
    $admoblink = $_POST['admoblink'];
    $admobmethod = $_POST['admobmethod'];

    $archivelabel = $_POST['archivelabel'];
    if($archivelabel==''){
      $archivelabel = 'The Archives';
    }
	$catlabel=$_POST['catlabel'];
	if($catlabel==''){
      $catlabel = 'The Categories';
    }
    $pagelabel = $_POST['pagelabel'];
    //$secret = $_POST['secret'];
	$allowmoblog = $_POST['allowmoblog'];
    $tracking = $_POST['tracking'];
    $style = $_POST['style'];
    $share = $_POST['share'];
    $authorlink = $_POST['authorlink'];
    $updatedlabel = $_POST['updatedlabel'];
    $resizewidth = $_POST['resizewidth'];
    $moblogcat = $_POST['moblogcat'];
    $leavecomments = $_POST['leavecomments'];
    $showcomments = $_POST['showcomments'];
    $maxlimitperpage = $_POST['maxlimitperpage'];

    // now we update the options - you could add some validation here if you wished
    update_option('wp_mobility_plugin_admob', $admob);
    update_option('wp_mobility_plugin_admobshare', $share);
    update_option('wp_mobility_plugin_admoblink', $admoblink);
    update_option('wp_mobility_plugin_adcomment', $adcomment);
    update_option('wp_mobility_plugin_adplacement', $adplacement);
    update_option('wp_mobility_plugin_admobmethod', $admobmethod);
    update_option('wp_mobility_plugin_authorlink', $authorlink);
    update_option('wp_mobility_plugin_oneweb', $oneweb);
    update_option('wp_mobility_plugin_resizewidth', $resizewidth);
    update_option('wp_mobility_plugin_welcome', $welcome);
    update_option('wp_mobility_plugin_archivelabel', $archivelabel);
	update_option('wp_mobility_plugin_catlabel', $catlabel);
    update_option('wp_mobility_plugin_pagelabel', $pagelabel);
    //update_option('wp_mobility_plugin_secret', $secret);
    update_option('wp_mobility_plugin_allowmoblog', $allowmoblog);
    update_option('wp_mobility_plugin_moblogcat', $moblogcat);
    update_option('wp_mobility_plugin_tracking', $tracking);
    update_option('wp_mobility_plugin_style', $style);
    update_option('wp_mobility_plugin_updatedlabel', $updatedlabel);
    update_option('wp_mobility_plugin_leavecomments', $leavecomments);
    update_option('wp_mobility_plugin_showcomments', $showcomments);
    update_option('wp_mobility_plugin_maxlimitperpage', $maxlimitperpage);
    // create the pretty box with updated message
    echo "<div id='message' class='updated fade'><p><b>Options updated!</b></p></div>";
  }
  // now we get the values from wp so we can propagate the form and pre program drop down forms with selected values
  $admobkey = get_option('wp_mobility_plugin_admob');
  $admobshare = get_option('wp_mobility_plugin_admobshare');
  $admoblink = get_option('wp_mobility_plugin_admoblink');
  $admobmethod = get_option('wp_mobility_plugin_admobmethod');
  $oneweb = get_option('wp_mobility_plugin_oneweb');
  $welcome = get_option('wp_mobility_plugin_welcome');
  $adcomment = get_option('wp_mobility_plugin_adcomment');
  $adplacement = get_option('wp_mobility_plugin_adplacement');
  $archivelabel = get_option('wp_mobility_plugin_archivelabel');
  $catlabel = get_option('wp_mobility_plugin_catlabel');
  $pagelabel = get_option('wp_mobility_plugin_pagelabel');
  //$secret = get_option('wp_mobility_plugin_secret');
  $allowmoblog = get_option('wp_mobility_plugin_allowmoblog');
  $moblogcat = get_option('wp_mobility_plugin_moblogcat');
  $tracking = get_option('wp_mobility_plugin_tracking');
  $style = get_option('wp_mobility_plugin_style');
  $authorlink = get_option('wp_mobility_plugin_authorlink');
  $updatedlabel = get_option('wp_mobility_plugin_updatedlabel');
  $resizewidth = get_option('wp_mobility_plugin_resizewidth');
  $leavecomments = get_option('wp_mobility_plugin_leavecomments');
  $showcomments = get_option('wp_mobility_plugin_showcomments');
  $maxlimitperpage = get_option('wp_mobility_plugin_maxlimitperpage');


  // max limit number post perpage
switch($maxlimitperpage){
    case '1':
      $maxlimit_1 = 'selected="selected"';
      break;
    case '5':
      $maxlimit_5 = 'selected="selected"';
      break;
    case '10':
      $maxlimit_10 = 'selected="selected"';
      break;
    case '15':
      $maxlimit_15 = 'selected="selected"';
      break;
  }

  $homeurl = get_settings(siteurl);
  // if tracking is enabled show a link to the report page
  if($tracking=='enabled'){
    $homeurl = get_settings(siteurl);
    $homelink = ereg_replace('http://','',$homeurl);
    $mobile_counter = "<a href=\"http://www.waphitcounter.com/realtime.php?site=$homeurl&amp;css=$homeurl/wp-admin/wp-admin.css\" target=\"waphitcounter\">Mobile Traffic Tracking</a>";
    $tracking_enabled = 'selected="selected"';
  }else{
    $mobile_counter = 'Mobile Traffic Tracking';
    $tracking_disabled = 'selected="selected"';
  }
  // more drop down selection checking
  if($oneweb=='enabled'){
    $selected_enabled = 'selected="selected"';
  }else{
    $selected_disabled = 'selected="selected"';
  }
  // more drop down selection checking
  if($allowmoblog=='enabled'){
      $moblog_enabled = 'selected="selected"';
  }else{
      $moblog_disabled = 'selected="selected"';
  }
  // more drop down selection checking
  if($leavecomments=='yes'){
    $comments_enabled = 'selected="selected"';
  }else{
    $comments_disabled = 'selected="selected"';
  }
  // more drop down selection checking
  if($showcomments=='yes'){
    $showcomments_enabled = 'selected="selected"';
  }else{
    $showcomments_disabled = 'selected="selected"';
  }
  // more drop down selection checking
  if($style=='internal'){
    $style_internal = 'selected="selected"';
  }else{
    $style_external = 'selected="selected"';
  }
  // more drop down selection checking
  if($authorlink=='yes'){
    $authorlink_yes = 'selected="selected"';
  }else{
    $authorlink_no = 'selected="selected"';
  }
  // where does the user want the ads to appear
  // again more drop down selection checking
  switch($adplacement){
    case 'top':
      $selected_top = 'selected="selected"';
      break;
    case 'bottom':
      $selected_bottom = 'selected="selected"';
      break;
    case 'both':
      $selected_both = 'selected="selected"';
      break;
  }

  //How to get admob link doing
   switch($admobmethod){
    case 'curl':
      $selected_curl = 'selected="selected"';
      break;
    case 'fsock':
      $selected_fsock = 'selected="selected"';
      break;
    case 'fgetcontents':
      $selected_fgetcontents = 'selected="selected"';
      break;
  }

  // how much many ad exposes do you want me to get?
  // again more drop down selection checking
  switch($admobshare){
    case '10';
      $share_10 = 'selected="selected"'; // thanks!
      break;
    case '25';
      $share_25 = 'selected="selected"';
      break;
    case '50';
      $share_50 = 'selected="selected"';
      break;
    case '100';
      $share_100 = 'selected="selected"';
      break;
  }



/*
 * sort the wp-mobility plugin option settings, add here if a option added soon
 */
  $mobility_settings = array('admob', 'admobshare', 'admoblink', 'admobmethod', 'admobauthkey', 'oneweb', 'welcome', 'adcomment', 'adplacement', 'archivelabel',
    'catlabel', 'pagelabel', 'allowmoblog', 'moblogcat', 'tracking', 'style', 'authorlink', 'updatedlabel', 'resizewidth', 'leavecomments', 'showcomments', 'maxlimitperpage');
  sort($mobility_settings);

/*
 * get WP version, it's seem silly but good enough :P
 */
 $wp_versi = '';
 $compat_versi = '2.7';
 $wp_versi = str_ireplace("version", "", apply_filters('update_footer', ''));
 $wp_versi = str_ireplace("|", "", $wp_versi);
 $wp_versi = substr(trim($wp_versi), 0, 3);

$cat_drop_down = cat_drop();
/*
 * Uninstall WP-Mobility
 * Modified from original source WP-PageNavi @http://lesterchan.net/portfolio/programming/php/
 */
if(!empty($_POST['do'])) {
	switch($_POST['do']) {
		case __('UNINSTALL WP-Mobility', 'wp-mobility') :
			if(trim($_POST['uninstall_mobility_yes']) == 'yes') {
				echo '<div id="message" class="updated fade">';
				echo '<p>';
				foreach($mobility_settings as $setting) {
                    $mobility_setting = 'wp_mobility_plugin_'.$setting.'';
					$delete_setting = delete_option($mobility_setting);
					if($delete_setting) {
						echo '<font color="green">';
						printf(__('Setting Key \'%s\' has been deleted.', 'wp-mobility'), "<strong><em>{$mobility_setting}</em></strong>");
						echo '</font><br />';
					} else {
						echo '<font color="red">';
						printf(__('Error deleting Setting Key \'%s\'.', 'wp-mobility'), "<strong><em>{$mobility_setting}</em></strong>");
						echo '</font><br />';
					}
				}
				echo '</p>';
				echo '</div>';
				$mode = 'end-UNINSTALL';
			}
		break;
	}
}

/*
 * Determines Which Mode Is It
 * show the admin panel form or Uninstallation mode
 */
switch($mode) {
	//  Deactivating WP-PageNavi
	case 'end-UNINSTALL':
			$deactivate_url = 'plugins.php?action=deactivate&plugin=wp-mobility/wp-mobility.php';
			if(function_exists('wp_nonce_url')) {
				$deactivate_url = wp_nonce_url($deactivate_url, 'deactivate-plugin_wp-mobility/wp-mobility.php');
			}
			echo '<div class="wrap">';
			echo '<h2>'.__('Uninstall WP-Mobility', 'wp-mobility').'</h2>';
			echo '<p><strong>'.sprintf(__('<a href="%s">Click Here</a> To Finish The Uninstallation And WP-Mobility Will Be Deactivated Automatically.', 'wp-mobility'), $deactivate_url).'</strong></p>';
			echo '</div>';
			break;
	// Main Page
	default:
?>

<div class="wrap"><?php if($wp_versi >= $compat_versi) screen_icon(); ?>
    <h2><?php _e('WP-Mobility Plugin Options', 'wp-mobility'); ?></h2>
  <?Php echo $plugin_upgrade; ?>
  <h3 style="margin:0 auto; text-align:center;">Your WordPress site is now mobile!</h3>
  <fieldset class="options">
  <h4><?php _e('General Plugin Configuration', 'wp-mobility'); ?></h4>
  <form name="wp_mobility_update" id="wp_mobility_update" method="post" action="?page=wp-mobility.php&amp;action=wp_mobility_update" enctype="multipart/form-data">
  <table cellpadding="3" cellspacing="3">
	<tr>
	<td width="250">Index page welcome comment:</td>
	<td width="250"><input type="text" name="welcome" value="<?Php echo $welcome; ?>" size="45" /></td>
	</tr>
    <tr>
	<td width="250">Maximum post, page, comment number shown per page:</td>
	<td width="250"><select name="maxlimitperpage"><option value="1" <?Php echo $maxlimit_1; ?>>Show upto 1</option><option value="5" <?Php echo $maxlimit_5; ?>>Show upto 5</option><option value="10" <?Php echo $maxlimit_10; ?>>Show upto 10</option><option value="15" <?Php echo $maxlimit_15; ?>>Show upto 15</option></select></td>
	<td width="500"></td>
	</tr>
	<tr>
	<td width="250">Archive link anchor text:</td>
	<td width="250"><input type="text" name="archivelabel" value="<?Php echo $archivelabel; ?>" size="15" /></td>
	</tr>
	<tr>
	<td width="250">Category link anchor text:</td>
	<td width="250"><input type="text" name="catlabel" value="<?Php echo $catlabel; ?>" size="15" /></td>
	</tr>
	<tr>
	<td width="250">Pages link anchor text:</td>
	<td width="250"><input type="text" name="pagelabel" value="<?Php echo $pagelabel; ?>" size="15" /></td>
	</tr>
     <tr>
	<td width="250">Show comments:</td>
	<td width="250"><select name="showcomments"><option value="yes" <?Php echo $showcomments_enabled; ?>>Enabled&nbsp;&nbsp;<option value="no" <?Php echo $showcomments_disabled; ?>>Disabled</select></td>
	</tr>
    <tr>
	<td width="250">Leave comments:</td>
	<td width="250"><select name="leavecomments"><option value="yes" <?Php echo $comments_enabled; ?>>Enabled&nbsp;&nbsp;<option value="no" <?Php echo $comments_disabled; ?>>Disabled</select></td>
	</tr>
  <tr>
	<td width="250">Text to show if blog updated today:</td>
	<td width="250"><input type="text" name="updatedlabel" value="<?Php echo $updatedlabel; ?>" size="15" /></td>
	</tr>
  <tr>
	<td width="250">Inline or external CSS:</td>
	<td width="250"><select name="style"><option value="external"<?Php echo $style_external; ?>>External&nbsp;&nbsp;<option value="internal"<?Php echo $style_internal; ?>>Inline</select></td>
	</tr>
  <tr>
	<td width="250"><a href="http://www.w3.org/TR/mobile-bp/#OneWeb" target="oneweb">One Web</a> / Preserve Permalinks:</td>
	<td width="250"><select name="oneweb"><option value="enabled"<?Php echo $selected_enabled; ?>>Enabled<option value="disabled"<?Php echo $selected_disabled; ?>>Disabled&nbsp;&nbsp;</select></td>
	<td width="500"></td>
	</tr>
  <tr>
	<td width="250"><?Php echo $mobile_counter; ?>:</td>
	<td width="250"><select name="tracking"><option value="enabled"<?Php echo $tracking_enabled; ?>>Enabled<option value="disabled"<?Php echo $tracking_disabled; ?>>Disabled&nbsp;&nbsp;</select></td>
	</tr>
	</table>
	<br />

  <h4><?php _e('WordPress posting from phone: Mobile-Blogging (MoBlog)', 'wp-mobility'); ?></h4>
  <table cellpadding="3" cellspacing="3">
	<tr>
	<td width="250">Allow MoBlog (Mobile Blogging) disabled/enabled:</td>
    <td width="250"><select name="allowmoblog"><option value="enabled"<?Php echo $moblog_enabled; ?>>Enabled<option value="disabled"<?Php echo $moblog_disabled; ?>>Disabled&nbsp;&nbsp;</select></td>
	</tr>
	<tr>
	<td width="250">Default category for mobile posting:</td>
	<td width="250"> <?Php echo $cat_drop_down; ?> </td>
	</tr>

  <tr>
	<td width="250">Resize jpg uploads wider than:</td>
	<td width="250"><input type="text" name="resizewidth" value="<?Php echo $resizewidth; ?>" size="5" /> (pixels)</td>
	</tr>
	</table>
	<br />

  <h4><?php _e('AdMob Mobile Internet Advertising', 'wp-mobility'); ?></h4>
  <table cellpadding="3" cellspacing="3">
	<tr>
	<td width="250"><a href="http://www.admob.com/" target="admob">AdMob</a> Mobile Publisher ID:</td>
	<td width="250"><input type="text" name="admob" value="<?Php echo $admobkey; ?>" size="20" /></td>
	</tr>
	<tr>
	<td width="250">Comment next to ads:</td>
	<td width="250"><input type="text" name="adcomment" value="<?Php echo $adcomment; ?>" size="10" /></td>
	</tr>
  <tr>
	<td width="250">Ad positioning:</td>
	<td width="250"><select name="adplacement"><option value="top"<?Php echo $selected_top; ?>>Top<option value="bottom"<?Php echo $selected_bottom; ?>>Bottom<option value="both"<?Php echo $selected_both; ?>>Both</select></td>
	</tr>
  <tr>
	<td width="250">Ad links page anchor text:</td>
	<td width="250"><input type="text" name="admoblink" value="<?Php echo $admoblink; ?>" size="15" /></td>
	</tr>
  <tr>
	<td width="250">Method to perform connection to admob/ads-mobi link server:</td>
	<td width="250"><select name="admobmethod"><option value="curl"<?Php echo $selected_curl; ?>>PHP cURL<option value="fsock"<?Php echo $selected_fsock; ?>>PHP Socket<option value="fgetcontents"<?Php echo $selected_fgetcontents; ?>>file_get_contents()</select></td>
	</tr>
	</table>
	<br />

  <h4><?php _e('Sharing success and link love [Not worked yet!]', 'wp-mobility'); ?></h4>
  <table cellpadding="3" cellspacing="3">
  <tr>
	<td width="250">Plugin Author Ad Share:</td>
	<td width="250"><select name="share"><option value="10"<?Php echo $share_10; ?>>1 in 10<option value="25"<?Php echo $share_25; ?>>1 in 25<option value="50"<?Php echo $share_50; ?>>1 in 50<option value="100"<?Php echo $share_100; ?>>1 in 100</select></td>
	<td width="500"></td>
	</tr>
  <tr>
	<td width="250">Show links for Plugin Author:</td>
	<td width="250"><select name="authorlink"><option value="yes"<?Php echo $authorlink_yes; ?>>Yes&nbsp;&nbsp;<option value="no"<?Php echo $authorlink_no; ?>>No</select></td>
	<td width="500"></td>
	</tr>
	</table>
    <p style="border:0;" class="submit"><input type="submit" class="submit" name="update_wordpress_mobile" value="Update" /></p>
  </form>
  </fieldset>

  <?php if($wp_versi >= $compat_versi) screen_icon(); ?>
    <h2><?php _e('WP-Mobility Deep &amp; Clean Uninstallation', 'wp-mobility'); ?></h2>
  <form method="post" action="<?php echo $_SERVER['REQUEST_URI']; ?>">
<p>
		<?php _e('Normally deactivating WP-Mobility plugin does not remove any data that may have been created, such as the admob key option. To completely remove this plugin, you can uninstall it here.', 'wp-mobility'); ?>
	</p>
	<p style="color: red">
		<strong><?php _e('WARNING:', 'wp-mobility'); ?></strong><br />
		<?php _e('Once uninstalled, this cannot be undone. You should use a Database Backup plugin of WordPress to back up all the data first.', 'wp-mobility'); ?>
	</p>
	<p style="color: red">
		<strong><?php _e('The following WordPress Options will be DELETED:', 'wp-mobility'); ?></strong><br />
	</p>

    <table class="widefat">
    	<thead>
			<tr>
				<th><?php _e('List of WordPress Options', 'wp-mobility'); ?></th>
			</tr>
		</thead>
    </table>
	<table class="widefat"  cellpadding="3" cellspacing="3">
        <tr>
            <td width="15"><b> No. </b></td>
            <td width="200"><b> Option Setting </b></td>
            <td width="300"><b> Option Value</b></td>
        </tr>
				<?php
                    foreach($mobility_settings as $key => $setting){
                        echo "<tr><td width=\"15\">".($key+1)."</td><td width=\"200\">wp_mobility_plugin_".$setting."</td>"
                        ."<td width=\"300\">".get_option('wp_mobility_plugin_'.$setting.'')."</td></tr>";
                    }
				?>
				
	</table>
    <br />
    <input type="checkbox" name="uninstall_mobility_yes" value="yes" />&nbsp;<?php _e('Yes', 'wp-mobility'); ?>
	<p style="border:0;" class="submit">
		<input type="submit" class="submit" name="do" value="<?php _e('UNINSTALL WP-Mobility', 'wp-mobility'); ?>" class="button" onclick="return confirm('<?php _e('Are You Sure To Perform Deep and Clean Uninstalling WP-Mobility From WordPress.\nThis Action Is Not Reversible.\n\n Choose [Cancel] To Stop, [OK] To Uninstall.', 'wp-mobility'); ?>')" />
	</p>
 </form>
</div>

<div class=\"wrap\">
  <h3><?php _e('Mobile Development tools, guidelines &amp; resources', 'wp-mobility'); ?></h3>
  <p>
  <a href="http://pc.mtld.mobi" target="mtld"><img src="http://www.andymoore.info/wp-content/uploads/2007/02/dotmobi.jpg" width="86" height="38" border="0" alt="Dot Mobi" /></a>
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <a href="http://www.admob.com/" target="admob"><img src="http://www.admob.com/img/admob_logo_banner.gif" width="209" height="34" border="0" alt="Admob" /></a>
  </p>
  <ul>
  <li><a href="http://validator.w3.org/mobile?uri=$homeurl" target="validator">validator.w3.org/mobile</a> - check your markup validates
  <li><a href="http://ready.mobi/results2.jsp?uri=$homeurl" target="ready">ready.mobi</a> - check how mobile ready you are.
  <li><a href="http://emulator.mtld.mobi/emulator.php?emulator=&amp;webaddress=$homelink&amp;emulator=nokiaN70" target="emulator">emulator.mtld.mobi</a> - remember to test on several real devices.
  <li><a href="http://jigsaw.w3.org/css-validator/validator?uri=$homeurl?style=.css" target="stylevali">jigsaw.w3.org/css-validator</a> - check your style validates
  <li><a href="http://pc.dev.mobi/files/dotMobi%20Mobile%20Web%20Developers%20Guide.pdf" target="devguide">dotMobi Mobile Web Developers Guide</a> - recommended related reading
  <li><a href="http://www.w3.org/TR/mobileOK-basic10-tests/" target="mobileOK">W3C mobileOK Basic Tests 1.0</a> - detailed W3 working draft
  </ul>
  <p>Pre-source code plugin developed by <a href="http://www.andymoore.info" target="andy">Andy Moore</a> mobile internet developer.</p>
  <p>Modified and Refactored by <a href="http://mig.openkampus.com" target="echizen">Street.Walker</a> a WordPress Bloggerian.</p>
  </div>

  <?Php //";
$upgrade = apply_filters( 'update_footer', '' );
echo "WP-Mobility version $wp_mobility_version running under Wordpress $upgrade";
  }//end switch
}// ends the admin panel function
?>
