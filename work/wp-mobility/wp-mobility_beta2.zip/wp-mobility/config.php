<?php
// MobilePress path and table. No need to edit these options.
define('WPMOB_PATH', trailingslashit(dirname(__FILE__))); // System Path
define('WPMOB_ROOT_PATH', trailingslashit(dirname(dirname(__FILE__)))); // Root Path
define('WPMOB_SCRIPT_PATH', trailingslashit('/wp-content/plugins/' . basename(dirname(__FILE__)))); // Script friendly system path
define('WPMOB_TABLE', $wpdb->prefix . 'wp_mobility');

// For WP versions < 2.6
if ( ! defined( 'WP_CONTENT_DIR' ) )
      define( 'WP_CONTENT_DIR', ABSPATH . 'wp-content' );
?>