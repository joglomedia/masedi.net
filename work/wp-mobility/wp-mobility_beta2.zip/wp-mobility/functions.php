<?php
/* 
 * @package: functions.php
 * @contain another functions
 * and open the template in the editor.
 */


// this helps show friendly file sizes when items have been uploaded from a phone
// from www.php.net/filesize
function size_hum_read($size){
	$i=0;
	$iec = array("b", "Kb", "Mb");
	while (($size/1024)>1) {
		$size = $size/1024;
		$size = number_format($size,2);
		$i++;
	}
	return substr($size,0,strpos($size,'.')+4).' '.$iec[$i];
}

//tambahan craete categories drop down form.
function cat_drop(){
	global $wpdb;
 
	$moblogcatid=get_option("wp_mobility_plugin_moblogcat");
    //if(empty($moblogcat)) $moblogcat = '1';
    $selected = '';
	$cats_drop = '<select name="moblogcat" id="moblogcat">';
	$categories = @$wpdb->get_results("SELECT * FROM $wpdb->terms ORDER BY name");
	foreach ($categories as $category){
		if ($category->name!="Blogroll") {
            if($category->term_id == $moblogcatid){
                $cats_drop .= '<option value="'.$category->term_id.'" selected="selected">'.ucwords($category->name).'</option>';
            }else{
                $selected ="";
                $cats_drop .= '<option value="'.$category->term_id.'">'.ucwords($category->name).'</option>';
            }
            
		}
	}
	$cats_drop .= '</select>';
	return $cats_drop;
}


######
# TEXT MARKUP
######

// when we call post content we run a nl2br on it which creates markup we then need to clean
// sounds silly but it's easier to clean it this way than any other
// return clean will also trim a whole load of whitespace, newlines, tabs, returns etc so that the markup we show the device is as optimal as can be
function clean_return($return){
	$return = str_replace(array('\n', '\r', '\t', '<!--adsense--><br /><br />', '<br /><br /><!--donate-->', '<!--adsense#Sense--><br /><br />', '<!--adsense#FirefoxLarge--><br /><br />', ' align="center"', '[spoiler]', '[/spoiler]'), '', $return);
	$return = ereg_replace (' +', ' ', trim($return));
	$return = ereg_replace('<atitle>','<title>',$return);
	$return = ereg_replace('& ','&amp; ',$return);
	$return = ereg_replace('<br /><br /></p>','</p>',$return);
	$return = ereg_replace('<br /></p>','</p>',$return);
	$return = ereg_replace('</li><br />','</li>',$return);
	$return = ereg_replace('<ul><br />','<ul>',$return);
	$return = ereg_replace('</ul><br />','</ul>',$return);
	$return = ereg_replace('</p><br />','</p>',$return);
	$return = ereg_replace('</blockquote><br />','</blockquote>',$return);
	$return = ereg_replace('<blockquote><br />','<blockquote>',$return);
	$return = ereg_replace('<br /><br /><blockquote>','<blockquote>',$return);
	$return = ereg_replace('<br /></b><br /><br />','</b><br /><br />',$return);
	$return = ereg_replace('<br /></a></b><br /><br />','</a></b><br /><br />',$return);
	$return = ereg_replace('</blockquote><br />','</blockquote>',$return);
	
	return "$return";
}

// hack up version from wordpress link-template.php

function adjacent_post_link_mobility($format, $link, $in_same_cat = false, $excluded_categories = '', $previous = true) {
	if ( $previous && is_attachment() )
		$post = & get_post($GLOBALS['post']->post_parent);
	else
		$post = get_adjacent_post($in_same_cat, $excluded_categories, $previous);

	if ( !$post )
		return;

	$title = $post->post_title;

	if ( empty($post->post_title) )
		$title = $previous ? __('Previous Post') : __('Next Post');

	$title = apply_filters('the_title', $title, $post->ID);
	$date = mysql2date(get_option('date_format'), $post->post_date);
	$rel = $previous ? 'prev' : 'next';

	$string = '<a href="'.get_permalink($post).'" rel="'.$rel.'">';
	$link = str_replace('%title', $title, $link);
	$link = str_replace('%date', $date, $link);
	$link = $string . $link . '</a>';

	$format = str_replace('%link', $link, $format);

	$adjacent = $previous ? 'previous' : 'next';
	return apply_filters( "{$adjacent}_post_link", $format, $link );
}

function get_previous_post_link_mobility($format='%link', $link='%title', $in_same_cat = false, $excluded_categories = '') {
	return 'Previous Post: ' .adjacent_post_link_mobility($format, $link, $in_same_cat, $excluded_categories, true);
}

function get_next_post_link_mobility($format='%link', $link='%title', $in_same_cat = false, $excluded_categories = '') {
	return 'Next Post: ' .adjacent_post_link_mobility($format, $link, $in_same_cat, $excluded_categories, false);
}



//tambahan useful for echoing commen form
function print_comment_form($home, $post_id, $title){
	$commentform = '<p><b>Add your comment:</b><a name="submitcomment"></a></p>';
	$commentform .= '<form action="'.$home.'/wp-comments-post.php" method="post" id="commentform">
	 <p><b>[Note:] *</b> is Required field <br /> 
	<label for="author">*Name:</label>
	<br /><input type="text" name="author" id="author" value="" size="22" tabindex="1"  accesskey=""/>
	<br /><label for="email">*Email (kept private):</label>
	<br /><input type="text" name="email" id="email" value="" size="22" tabindex="2"  accesskey=""/>
	<br /><label for="url">Homepage:</label>
	<br /><input type="text" name="url" id="url" value="" size="22" tabindex="" />
	<br /><label for="url">*Comment:</label>
	<br /><textarea name="comment" id="comment" cols="20" rows="3" tabindex="4" accesskey=""></textarea>
	<br /><br />
	<label for="url"></label>
	<input name="submit" type="submit" id="submit" tabindex="5" accesskey="2" value="[2] Save My Comment" />
	<input type="hidden" name="comment_post_ID" value="'.$post_id.'" />
	</p></form>';
	
	return $commentform;
}


// function / sql originally from http://insomniacsyndicate.net/speak/?page_id=19 made 1.5 friendly
function updated_today(){
	global $wpdb;
    $updatedlabel = get_option('wp_mobility_plugin_updatedlabel');
    if($updatedlabel!=''){
      $today = date("Y-m-d");
    	$updated = $wpdb->get_var("select post_date, id FROM $wpdb->posts WHERE $wpdb->posts.post_date LIKE '".$today."%'");
    	if ($updated>0){; 
    	 return "<br />".$updatedlabel;
    	}
    }
}

// function originally from http://perishablepress.com/press/2006/08/28/blogstats-pcc-plugin/
function pages_count() {
	global $wpdb;
	global $numpages;
	$numpages = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_status = 'static'");
	if ($numpages>0){; 
	 return $numpages;
	}
}

/*
 * Limit the word length, example for limiting the excerpt
 * pdziok, http://php.net/manual/str_word_count
 */
function word_limiter($text, $limit=20, $dots='...'){
	$text = str_replace(array('\n', '\r', '\t'), ' ', $text);
    $explode = explode(' ', $text);
    $string  = '';
    //$dots = '...';
	
    if(count($explode) <= $limit){
        $dots = '';
    }
    for($i=0;$i<$limit;$i++){
        $string .= $explode[$i].' ';
    }
    if ($dots) {
		//$string = substr($string, 0, strlen($string));
    }

    return $string.$dots;
}
?>
