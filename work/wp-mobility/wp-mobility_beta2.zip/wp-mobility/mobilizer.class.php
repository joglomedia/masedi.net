<?Php
/*
 @name: mobileredirect.php
 @function: mobile detection and redirection
 @versi: 1.0
 @author: masedi
 @site: http://masedi.net/
 @Read further reference: http://wurfl.sourceforge.net, http://mobiforge.com/developing/story
 */

class mobileDetect {
	/* optional parameters */
	var $enableTouch = false; // "yes" = enable iPhone handled as mobile browser, else "no" handled as Desktop browser
	var $enableOpmin = false; // "yes" = enable Opera mini handled as mobile browser, else "no" handled as Desktop browser
	var $isMobile = false;
	var $_isOpmin = false;
	var $_isMobile = false;
	var $_isIphone = false;
	var $_isAndroid = false;

	function mobileDetect ($touch = false, $opmin = false) {
		$this->enableTouch = $touch;
		$this->enableOpmin = $opmin;
		
		return $this->mobileRedirect();
	}

	function mobileRedirect() {
		
		$op = strtolower($_SERVER['HTTP_X_OPERAMINI_PHONE']);
		$no = strtolower($_SERVER['HTTP_X_MOBILE_GATEWAY']);
		$ua = strtolower($_SERVER['HTTP_USER_AGENT']);
		//$ua = strtolower("LG V100 AU/4.10 Profile/MIDP-1.0 Configuration/CLDC-1.0 Opera Mini");
		$ac = strtolower($_SERVER['HTTP_ACCEPT']);
		$ip = $_SERVER['REMOTE_ADDR'];

		// mobile browser detection
		$this->isMobile = strpos($ac, 'application/vnd.wap.xhtml+xml') !== false
			|| $op != ''
			|| $no != '' 
			|| strpos($ua, 'alcatel') !== false 
			|| strpos($ua, 'audiovox') !== false 
			|| strpos($ua, 'au-mic') !== false 
			|| strpos($ua, 'avantgo') !== false 
			|| strpos($ua, 'benq') !== false //*
			|| strpos($ua, 'bolt') !== false 
			|| strpos($ua, 'blackberry') !== false 
			|| strpos($ua, 'blazer') !== false 
			|| strpos($ua, 'cellphone') !== false //*
			|| strpos($ua, 'cldc-') !== false 
			|| strpos($ua, 'danger') !== false
			|| strpos($ua, 'docomo') !== false //*
			|| strpos($ua, 'dopod') !== false 
			|| strpos($ua, 'epoc') !== false 
			|| strpos($ua, 'ericsson') !== false 
			|| strpos($ua, 'eudoraweb') !== false //*
			|| strpos($ua, 'Google Wireless Transcoder') !== false 
			|| strpos($ua, 'hiptop') !== false //*
			|| strpos($ua, 'htc') !== false 
			|| strpos($ua, 'huawei') !== false 
			|| strpos($ua, 'iemobile') !== false 
			|| strpos($ua, 'ipaq') !== false 
			|| strpos($ua, 'iphone') !== false 
			|| strpos($ua, 'ipod') !== false 
			|| strpos($ua, 'j2me') !== false 
			|| strpos($ua, 'kyocera') !== false // *
			|| strpos($ua, 'lg') !== false 
			|| strpos($ua, 'midp') !== false 
			|| strpos($ua, 'mobile') !== false 
			|| strpos($ua, 'mot') !== false 
			|| strpos($ua, 'moto') !== false 
			|| strpos($ua, 'motorola') !== false 
			|| strpos($ua, 'nec-') !== false 
			|| strpos($ua, 'netfront') !== false 
			|| strpos($ua, 'newt') !== false //*
			|| strpos($ua, 'nitro') !== false // nintendo DS
			|| strpos($ua, 'nintendo wii') !== false //*
			|| strpos($ua, 'nokia') !== false 
			|| strpos($ua, 'novarra-vision') !== false 
			|| strpos($ua, 'palm') !== false 
			|| strpos($ua, 'palmsource') !== false 
			|| strpos($ua, 'panasonic') !== false 
			|| strpos($ua, 'philips') !== false 
			|| strpos($ua, 'playstation portable') !== false //*
			|| strpos($ua, 'pocketpc') !== false 
			|| strpos($ua, 'portalmmm') !== false 
			|| strpos($ua, 'rover') !== false 
			|| strpos($ua, 'sagem') !== false 
			|| strpos($ua, 'samsung') !== false 
			|| strpos($ua, 'sanyo') !== false 
			|| strpos($ua, 'sch') !== false //*
			|| strpos($ua, 'sec') !== false 
			|| strpos($ua, 'series60') !== false 
			|| strpos($ua, 'sharp') !== false 
			|| strpos($ua, 'sie-') !== false 
			|| strpos($ua, 'small') !== false //*
			|| strpos($ua, 'smartphone') !== false 
			|| strpos($ua, 'sony') !== false 
			|| strpos($ua, 'symbian') !== false 
			|| strpos($ua, 't-mobile') !== false 
			|| strpos($ua, 'untrusted') !== false 
			|| strpos($ua, 'up.browser') !== false 
			|| strpos($ua, 'up.link') !== false 
			|| strpos($ua, 'vodafone/') !== false 
			|| strpos($ua, 'wap1.') !== false 
			|| strpos($ua, 'wap2.') !== false 
			|| strpos($ua, 'windows ce') !== false 
			|| strpos($ua, 'winwap') !== false; //*

		// non-mobile browser exclusion
		if(stripos($ua, 'Intel Mac OS X') !== false
			|| stripos($ua, 'PPC Mac OS X') !== false
			|| stripos($ua, 'Mac_powerPC') !== false
			|| stripos($ua, 'SunOS') !== false
			|| stripos($ua, 'Windows NT') !== false
			|| stripos($ua, 'Windows 98') !== false
			|| stripos($ua, 'WinNT') !== false)
				$this->isMobile = false;

		// checking opera mini browser as mobile or default browser
		if(strpos($ua, 'opera mini') !== false) { $this->_isOpmin = true; }
		
		// checking iPhone, iPod or Android phone
		if(strpos($ua, 'iphone') !== false || strpos($ua, 'ipod') !== false) { $this->_isIphone = true; }
		if(strpos($ua, 'android') !== false) { $this->_isAndroid = true; }
		
		if($this->isMobile === true) { $this->_isMobile = true; } else { $this->_isMobile = false; } // if mobile phone detected, enable _isMobile to redirect to mobile page.
		if($this->_isAndroid == true || $this->_isIphone == true) { $this->_isMobile = false; } // if iPhone or Android phone detected and need to redirect to special pages, then disable isMobile.

		/* 
		 * PHP Code to redirect to your appropriate mobile page or call a function to handle the mobile version page
		 * Exiting from the current script
		 */
		if($this->_isMobile === true || $this->_isAndroid === true || $this->_isIphone === true || $this->_isOpmin === true)
		{
			if($this->_isIphone===true && $this->enableTouch===true) {
				echo "is iPhone touch browser mode";
				// if iPhone is detected and enable touch, then redirect to your iPhone page
				//wp_redirect("http://youriPhonePage.domain");
				//header("Location: http://youriPhonePage.domain");
				//mobile_version_page();
				//exit();
			}elseif($this->_isAndroid===true && $this->enableTouch===true) {
				echo "is Android touch browser mode";
				// if Android Phone is detected and enable touch, then redirect to your Android page
				//wp_redirect("http://yourAndroidPage.domain");
				//header("Location: http://yourAndroidPage.domain");
				//mobile_version_page();
				//exit();
			}elseif($this->_isOpmin===true && $this->enableOpmin===true) {
				echo "is Opera mini browser mode";
				// if Android Phone is detected and enable touch, then redirect to your Android page
				//wp_redirect("http://yourAndroidPage.domain");
				//header("Location: http://yourAndroidPage.domain");
				//mobile_version_page();
				//exit();
			}else{
				echo "is mobile browser mode";
				// if another mobile-browser is detected then redirect to your general mobile page
				//wp_redirect("http://yourmobilepage.domain");
				//header("Location: http://yourmobilepage.domain");
				//mobile_version_page();
				//exit();
			}
			
			// debug
			
			//mobile_version_page();
			//exit();
		}else{
		// none mobile detected showing normal desktop page
		// we do not want the content on this site reformatted when this plugin does that job! http://wurfl.sourceforge.net/manifesto/
		@header('Pragma: Public');
		@header('Cache-Control: no-cache, must-revalidate, no-transform');
		@header('Vary: User-Agent, Accept');
		
		// debug
		echo "is non-mobile browser mode";
	  }
	} // End Mobile Detection
} // end mobile detect class

// debug
$mobilizer = new mobileDetect(true, true);

//mobilize wordpress standar desktop view
function mobility_theme_check() {

}
?>