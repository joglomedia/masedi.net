<?php
/*
Plugin Name: WP-mobility Beta 2
Plugin URI: http://www.masedi.net/wp-mobility/
Description: WP-Mobility let you perform WordPress Mobile-blogging from your mobile phone. It also enables mobile phone users to view your WordPress posts, archives, categories, comments and pages in a mobile friendly environment. Users can even reply comments via mobile. Optionally you even monetize your blog via mobile revenue from <a href="http://www.admob.com">admob.com</a> | <a href="http://buzzcity.com">BuzzCity</a>. Modified and Refactored from pre-source of <a href="http://www.andymoore.info/">Andy Moore</a>.
Author: MasEDI Networks
Version: 1.0.2
Author URI: http://www.masedi.net/
*/

/*
Copyright 2009 Street.Walker (email : me[at]masedi[dot]net)

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

/*
 * Including related file
 */

// if wp-mobility being located in admin panel section
//if(stristr($_SERVER['PHP_SELF'], "wp-admin")) { 
if( is_admin() ) {
    require_once(dirname(__FILE__) . '/admin-panel.php');
    require_once(dirname(__FILE__) . '/functions.php');
	require_once(dirname(__FILE__) . '/mobility.php');
	require_once(dirname(__FILE__) . '/ads-mobi.php');
}else{
    require_once(dirname(__FILE__) . '/functions.php');
    require_once(dirname(__FILE__) . '/mobility.php');
    require_once(dirname(__FILE__) . '/ads-mobi.php');
	require_once(dirname(__FILE__) . '/config.php');
}

// set the version so we can check if it's upto date on admin panel
$wp_mobility_version = '1.0.2';

// if get style is css we are only showing the css then quitting
if($_GET['style']=='.css'){
	// remember not all phones can support caching style but we can try if specified
	header("Expires: " . date("D, d M Y H:i:s", time() + 60 * 60 * 24 * 30) . " GMT");
	header("Cache-Control: Public");
	header("Content-type: text/css; charset=UTF-8");
	echo mobile_style();
	exit;
}else{
	// else we're not in css mode so we set some values wordpress needs
	// make this plugin execute first to bypass cache systems etc
	add_action('template_redirect', 'mobile_plugin_auto_detect','1');
	// if installing setup the values we need and ping my install counter
	add_action('activate_wp-mobility/wp-mobility.php', 'wp_mobility_plugin_activate');
	// if uninstalling ping my uninstall counter
	add_action('deactivate_wp-mobility/wp-mobility.php', 'wp_mobility_plugin_deactivate');
    // add setting link to the action panel
    add_action('plugin_action_links', 'wp_mobility_plugin_actions', 10, 2);
	// create the management admin panel
	add_action('admin_menu', 'wp_mobility_plugin_admin_menu');
}


/*
 * now we build the link in the admin menu
 * Initialize on the admin panel
 */
function wp_mobility_plugin_admin_menu(){
	add_options_page('WP-Mobility', 'WP-Mobility', 3, basename(__FILE__), 'wp_mobility_plugin_admin');
}

/*
 * add seting to action menu
 */
function wp_mobility_plugin_actions($links, $file){
	//Static so we don't call plugin_basename on every plugin row.
	$this_plugin;
	if (!$this_plugin) $this_plugin = plugin_basename(__FILE__);
        if ($file == $this_plugin){
            $settings_link = '<a href="options-general.php?page=wp-mobility.php">Settings</a>';
            array_unshift($links, $settings_link); // before other links
       }
	return $links;
}


/*
 * mobile_plugin_auto_detect and mobile_plugin_thematic_check pindah ke mobility.php
 */

/*
 * Function Mobile Plugin Activation and deactivation Cutted here
 * Pindah ke admin-panel.php
 */


//tambahan Another Ads-mobile-wap
	/*BuzzCity*/

	

/*
 * cat_drop dowwn function pindah ke functions.php
 */


/*
 * Admin menu and Admin Panel function cutted here
 * Pindah ke admin-panel.php
 */

/*
 * Mobile_redirect function pindah ke functions.php
 */

/*
 * size_hum_read pndah ke functions.php
 */


/*
 * Check_mobi function pindah ke functions.php
 */

/*
 * Clean_return functions pindah ke functions.php
 */

/*
 * Next_post_m and Previouse_post_m pindah ke functions.php
 */

/*
 * Print_commentForm function pindah ke functions.php
 */

/*
 * show_mobile_version and mobile_style pindah ke mobility.php
 */

/*
 * Updated_today and pages_count pindah ke functions.php
 */

// wow you mean you actually read my code?
// www.andymoore.info/
// www.andymoore.info/wordpress-mobile-plugin/

// thanks for using my software!

?>
