<?php
// maintenance script to clear the default WP rss widget cache
/*
 * Delete feed option table caused by STT2 RSS, RSS and Search engine bot EDANE script
 * 
 * Installation: install/upload this file bersihkan-rss-bot-edane-db.php on root of your wordpress installation
 * Usage: akses this file and automatically DELETE table row with option_name like this:
 * Table to delete like this!
 * %_transient_timeout_feed_mod_%
 * %_transient_timeout_feed_%
 * %_transient_feed_mod_%
 * %_transient_feed_%
 *
 * Created by: me[at]masedi[dot]net
*/

require( 'wp-config.php' );

global $wpdb;
$query = "DELETE FROM $wpdb->options WHERE option_name LIKE '%_transient_timeout_feed_%' OR option_name LIKE '%_transient_feed_%'";
$result = $wpdb->query($query);

if (!$result) {
	echo "This query: ' $query ' failed to execute <br />";
	$wpdb->print_error();
    exit();
}else{
	echo "This query: ' $query ' has been executed succesfully. <br />
	All value like %_transient_timeout_feed_% and %_transient_feed_% row in ".$wpdb->prefix."options has been deleted";
}
?>