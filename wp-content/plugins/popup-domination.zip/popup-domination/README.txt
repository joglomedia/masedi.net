== PopUP Domination V3 Wordpress ==
---------------------

Plugin Name: PopUp Domination 

Author: PopUp Domination Team

Version: 3.3.3

Author URI: http://www.popupdomination.com

Description: The Ultimate plugin to increase your list size. Make more money by using our beautiful themes and specific functionality to grow your subscriber list by over 500%. 

License: Commercial. For personal use only. Not to give away or resell. Copyright (c) 2012 popupdomination.com. All rights reserved.


INSTALL:
---------------------

Help Video - http://popdom.assistly.com/customer/portal/articles/257055-wordpress-install


Upload the "popup-domination.zip" file to your Wordpress plugins folder either by the Wordpress plugin Uploader or by FTP. 

After activation, you will be asked for an "Order Number", enter your receipt number or order number on your receipt to continue.

Use the theme uploader in the PopUp Domination plugin to install the extra themes later.


KNOWLEDGE BASE:
---------------------

To find all of our help articles for bugs and for using the plugin to it's fullest potential, please go to:

http://popdom.desk.com/


DO NOTS:
---------------------

1: Change the folder name "popup-domination" this will cause an error when using the plugin.

2: Change any code with exception of the themes files. 

3: Do no attempt to re-sell t



CONTACT:
---------------------

If you have any questions or problems please contact us at:

support@popupdomination.com

or visit our knowledge base:

http://popdom.assistly.com/