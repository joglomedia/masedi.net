<?php

/**
* ab_panel.php
*
* Template - This displays all the settings, details and stats for a/b campaign, this is also the template that is used for creating a new a/b split campaign. 
*/

?>

<?php if($success): ?>
	<div id="message" class="updated"><p>Your Settings have been <strong>Saved</strong></p></div>
<?php endif; ?>
	<div class="wrap with-sidebar" id="popup_domination">
			<div class="popup_domination_top_left">
				<img class="logo" src="<?php echo $this->plugin_url?>css/img/popup-domination3-logo.png" alt="Popup Domination 3.0" title="Popup Domination 3.0" width="200" height="62" />
				<div id="popup_domination_active">
					<span class="wording">
								<?php
									$text = '<img src="'.$this->plugin_url.'css/images/off.png" alt="off" width="6" height="6" />'; $class = 'inactive'; $text2 = '<img src="'.$this->plugin_url.'css/images/on.png" alt="on" width="6" height="6" />'; $class2 = 'turn-on';$text3 = 'Inactive';$text4 = 'Active';$text5 = 'TURN ON';$text6 = 'TURN OFF';
									if($this->is_enabled()){
										$text = '<img src="'.$this->plugin_url.'css/images/on.png" alt="on" width="6" height="6" />';
										$text2 = '<img src="'.$this->plugin_url.'css/images/off.png" alt="off" width="6" height="6" />';
										$text3 = 'Active';
										$text4 = 'Inactive';
										$text5 = 'TURN OFF';
										$text6 = 'TURN ON';
										$class = 'active';
										$class2 = 'turn-off';
									}
								?>
								<span class="<?php echo $class ?>">
							<?php echo $text; ?> PopUp Domination is</span>  <?php echo $text3 ?></span>
						</span>
					</span>
					<div class="popup_domination_activate_button">
						<div class="border">
							<?php echo $text2 ?>
							<a href="#activation" class="<?php echo $class2 ?>"><?php echo $text5; ?></a>
						</div> 
						<img class="waiting" style="display:none;" src="images/wpspin_light.gif" alt="" />
					</div>
				</div>
				<p><a href="#">&lt; Back to A/b Management</a></p>
				<div class="clear"></div>
			</div>
			<form action="<?php echo $this->opts_url?>" method="post" id="popup_domination_form">
			<div style="display:none" id="popup_domination_hdn_div"><?php echo $fields?></div>
			<div class="clear"></div>
			<div id="popup_domination_container" class="has-left-sidebar">
			<div style="display:none" id="popup_domination_hdn_div2"></div>
			<div id="popup_domination_tabs" class="campaign-details">
				<div class="campaign-name-box">
					<label for="campname">A/B Split Name: </label>
					<input id="campname" name="campname" type="text" value="<?php if(isset($name)){ echo $name;}else{ echo 'Campaign Name...';} ?>" />
					<a href="#" class="checkname">Check Name</a>
					<div class="clear"></div>
					<p class="microcopy">e.g. Service Page Popup &#35;1</p>
					<img class="waiting" src="<?php echo $this->plugin_url; ?>/css/loading.gif" alt="loading" width="15" height="15" />
					<div class="clear"></div>
				</div>
				<div class="campaign-description">
					<label for="campdesc">Popup Description: </label>
					<input name="campaigndesc" type="text" value="<?php if(isset($desc)){ echo $desc;}else{ echo 'Campaign Description...';} ?>" />
					<p class="microcopy">e.g. Testing incentive A to see how it converts.</p>
				</div>
				<div class="clear"></div>
			</div>
			<div id="popup_domination_tabs" class="tab-menu">
            	<a class="icon camps selected" href="#look_and_feel">Select Campaigns</a>
                <a class="icon setup" href="#page_list">Schedule Setup</a>
                <a class="icon results" href="#results">Results</a>
			</div>
			<div class="notices" style="display:none;">
				<p class="message"><?php if(!isset($this->update_msg)){$this->update_msg = ' ';}else{ echo $this->update_msg;} ?></p>
			</div>
			<div class="flotation-device">
			    <div class="mainbox" id="popup_domination_tab_look_and_feel">
	                <h3 class="title topbar icon feel"><span>Select Campaigns</span></h3>
	                <div class="inside">
	                    <table>
	                        <?php foreach ($campdata as $offset => $c): ?>
	                		<tr>
	                			<?php
	                				if($split['campaigns']){
		                				foreach ($split['campaigns'] as $s){
			                				if($s == $c->campaign){
			                					$tick[$s] = 'checked = "yes"';	 
			                				}else{
			                					$tick[$s] = '';
			                				}
		                				}
		                				if (array_key_exists($c->campaign, $tick)) {
											echo '';
										}else{
											$tick[$c->campaign] = '';
										}
									}
	                			?>
	                			<td><input <?php if(isset($tick)){ echo $tick[$c->campaign];} ?> type="checkbox" name="campaign[]" value="<?php echo $c->campaign; ?>" /><?php echo $c->campaign; ?></td>
	                		</tr>
	                		<?php endforeach; ?>
	                	</table>
	                </div>
	                <div class="clear"></div>
	            </div>
	                <div class="mainbox" id="popup_domination_tab_page_list">
	                	<div class="inside">
	                    	<h3>How often should we show popup A?</h3>
	                    	<span class="line">&nbsp;</span>
	                    	<span class="example">This is in percentage. For "50%" type in "50".</span>
	                    	<input type="text" value="<?php if(isset($visitsplit)){echo $visitsplit;}else{ echo '';} ?>" name="numbervisitsplit" class="visitsplit" />
	                    	<h3>Please specify the conversion page destination:</h3>
	                    	<span class="line">&nbsp;</span>
	                    	<span class="example">This has to be a webpage within the blog or website this version of PopUp Domination is installed on.</span>
	                    	<input type="text" value="<?php if(isset($page)){echo $page;}else{ echo '';} ?>" name="conversionpage" class="conversionpage" />
	                    </div>
	                    <div class="clear"></div>
	                    <div class="inside">
	                    	<label class="title">Where should we execute this A/B Test?</label>
	                    	<span class="line">&nbsp;</span>
		                     <p><?php $this->absplit_list($split['schedule']); ?></p>
	                    </div>
	                    <div class="clear"></div>
	                </div>
	                <div class="mainbox" id="popup_domination_tab_results">
	                	<?php if(!empty($split['results'])): ?>
		                <div class="holdall">
							<div id="graph-wrapper">
								<div class="line-chart chart-one">
									<h2>Analytic Data for Split Campaign : <?php echo $name; ?> (Conversions)</h2>
									<br/>
									<table id="data-table-two" style="display:none;" border="1" cellpadding="10" cellspacing="0" summary="Analytic Data for Split Campaign : ">
										<thead>
											<tr>
												<th></th>
												<?php $c = 0; ?>
												<?php foreach($split['results'] as $k => $rr): ?>
													<?php if(count($rr) > $c){
														$max = $k;
														$c = count($rr);
													}?>
												<?php endforeach; ?>
												<?php foreach($split['results'][$max] as $k => $rr): ?>
													<th scope="col"><?php echo $k; ?></th>
												<?php endforeach; ?>
											</tr>
										</thead>
										<tbody>
											<?php $campname[2][0]->campaign = 'test3'; ?>
											<?php $i= 0; foreach($split['results'] as $r): ?>
											<tr>
												<th scope="row"><?php echo $campname[$i][0]->campaign; ?></th>
												<?php foreach($r as $k=> $rr): ?>
													<td><?php echo intval($rr['optin']); ?></td>
												<?php endforeach; ?>
											</tr>
											<?php $i++; endforeach; ?>
										</tbody>
									</table>
								</div>
							</div>
						</div>
						<?php else: ?>
							<h2>There is No Analytic Data Yet.</h2>
						<?php endif; ?>
					</div>
				</div>
				<div class="clear"></div>
				<div id="popup_domination_form_submit">
					<div class="submit">
						<input type="text" name="campaignid" value="<?php echo $campaignid; ?>" style="display:none" />
						<?php wp_nonce_field('update-options'); ?>
						<?php if(isset($camp_id)){ $disabled = ''; }else{ $disabled = 'disabled="disabled" ';} ?>
						<span style="position: relative; height:55px;">
							<input class="savecamp save-btn" type="submit" name="update" <?php echo $disabled; ?> value="<?php _e('Save Changes', 'popup_domination'); ?>" />
							<?php if(!isset($camp_id)){?>
							<div class="removeme" style="position: absolute; top:-12px;left:0px;bottom:0px;right:0px;height:37px;background-color:transparent;"></div>
							<?php } ?>
						</span>												
					</div>
					<p><strong>Remember:</strong> You must check your Campaign Name before you can create a new campaign.</p>
					<div id="popup_domination_current_version">
						<p>You are currently running <strong>version <?php echo $this->version; ?></strong></p>
					</div>
				</div>
				<div class="clear"></div>
			</form>
		</div>
		<script type="text/javascript">
		var popup_domination_admin_ajax = '<?php echo admin_url('admin-ajax.php') ?>', popup_domination_theme_url = '<?php echo $this->theme_url ?>', popup_domination_form_url = '<?php echo $this->opts_url ?>', popup_domination_url = '<?php echo $this->plugin_url ?>', popup_domination_campaign_id=<?php echo (!isset($camp_id)) ? -1 : $camp_id; ?>;
		</script>