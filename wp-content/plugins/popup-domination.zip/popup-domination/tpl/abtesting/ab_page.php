<?php

/**
* ab_page.php
*
* Template - This displays all the settings, details and stats for a/b campaign, this is also the template that is used for creating a new a/b split campaign. 
*/

?>

<?php if($success): ?>
<div id="message" class="updated"><p>Your Settings have been <strong>Saved</strong></p></div>
<?php endif; ?>
<div class="wrap with-sidebar" id="popup_domination">
	<?php $header_link = '< Back to A/B Management', $header_url = $this->plugin_url.'tpl/ab_panel.php';
	include $this->plugin_path.'tpl/header.php'; ?>			
	<form action="<?php echo $this->opts_url?>" method="post" id="popup_domination_form">
	<div style="display:none" id="popup_domination_hdn_div"><?php echo $fields?></div>
	<div class="clear"></div>
	<div id="popup_domination_container" class="has-left-sidebar">
	<div style="display:none" id="popup_domination_hdn_div2"></div>
	<?php include $this->plugin_path.'tpl/abtesting/ab_header.php'; ?>
	<?php include $this->plugin_path.'tpl/abtesting/ab_tabs.php'; ?>
	<div class="notices" style="display:none;">
		<p class="message"><?php if(!isset($this->update_msg)){$this->update_msg = ' ';}else{ echo $this->update_msg;} ?></p>
	</div>
	<div class="flotation-device">
	    	<?php include $this->plugin_path.'tpl/abtesting/campaigns.php'; ?>
			<?php include $this->plugin_path.'tpl/abtesting/ab_schedule.php'; ?>
	    	<?php include $this->plugin_path.'tpl/abtesting/ab_results.php'; ?>
	</div>
		<div class="clear"></div>
		<?php include $this->plugin_path.'tpl/footer.php'; ?>
		<div class="clear"></div>
	</form>
</div>
<script type="text/javascript">
var popup_domination_admin_ajax = '<?php echo admin_url('admin-ajax.php') ?>', popup_domination_theme_url = '<?php echo $this->theme_url ?>', popup_domination_form_url = '<?php echo $this->opts_url ?>', popup_domination_url = '<?php echo $this->plugin_url ?>';
</script>