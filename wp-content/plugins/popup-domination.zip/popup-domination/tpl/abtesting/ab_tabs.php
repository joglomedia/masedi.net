<div id="popup_domination_tabs" class="tab-menu">
	<a class="icon camps selected" href="#look_and_feel">Select Campaigns</a>
	<a class="icon setup" href="#page_list">Schedule Setup</a>
	<a class="icon results" href="#results">Results</a>
</div>