<?php

/**
* analytics_panel.php
*
* Template - This template is used to display all the analytic data for the campaigns. 
*/

?>
<div class="wrap" id="popup_domination">
	<?php include $this->plugin_path.'tpl/header.php'; ?>
	<form action="<?php echo $this->opts_url?>" method="post" id="popup_domination_form">
	<div style="display:none" id="popup_domination_hdn_div"><?php echo $fields?></div>
	<div class="clear"></div>
	<div id="popup_domination_container" class="has-left-sidebar">
		<div style="display:none" id="popup_domination_hdn_div2"></div>
		<?php include $this->plugin_path.'tpl/analytics/campaign_list.php'; ?>
		<div class="clearfix"></div>
	</div>
	<div id="popup_domination_form_submit">
		<div id="popup_domination_current_version">
			<p>You are currently running <strong>version <?php echo $this->version; ?></strong></p>
		</div>
	   <?php wp_nonce_field('update-options'); ?>
   </div>
	</form>
</div>
<script type="text/javascript">
var popup_domination_admin_ajax = '<?php echo admin_url('admin-ajax.php') ?>', popup_domination_theme_url = '<?php echo $this->theme_url ?>', popup_domination_form_url = '<?php echo $this->opts_url ?>', popup_domination_url = '<?php echo $this->plugin_url ?>';
</script>