<?php

/**
* analytics_data.php
*
* Template - Layouts out a list of all the campaigns created and links to their analytic pages.
*/

?>
 	<div class="wrap wider" id="popup_domination">
			<div class="popup_domination_top_left">
				<img class="logo" src="<?php echo $this->plugin_url?>css/img/popup-domination3-logo.png" alt="Popup Domination 3.0" title="Popup Domination 3.0" width="200" height="62" />
				<div id="popup_domination_active">
					<span class="wording">
								<?php
									$text = '<img src="'.$this->plugin_url.'css/images/off.png" alt="off" width="6" height="6" />'; $class = 'inactive'; $text2 = '<img src="'.$this->plugin_url.'css/images/on.png" alt="on" width="6" height="6" />'; $class2 = 'turn-on';$text3 = 'Inactive';$text4 = 'Active';$text5 = 'TURN ON';$text6 = 'TURN OFF';
									if($this->is_enabled()){
										$text = '<img src="'.$this->plugin_url.'css/images/on.png" alt="on" width="6" height="6" />';
										$text2 = '<img src="'.$this->plugin_url.'css/images/off.png" alt="off" width="6" height="6" />';
										$text3 = 'Active';
										$text4 = 'Inactive';
										$text5 = 'TURN OFF';
										$text6 = 'TURN ON';
										$class = 'active';
										$class2 = 'turn-off';
									}
								?>
								<span class="<?php echo $class ?>">
							<?php echo $text; ?> PopUp Domination is</span>  <?php echo $text3 ?></span>
						</span>
					</span>
					<div class="popup_domination_activate_button">
						<div class="border">
							<?php echo $text2 ?>
							<a href="#activation" class="<?php echo $class2 ?>"><?php echo $text5; ?></a>
						</div> 
						<img class="waiting" style="display:none;" src="images/wpspin_light.gif" alt="" />
					</div>
				</div>
				<p><a href="#">&lt; Back to Analytics</a></p>
				<div class="clear"></div>
				</div>
			<form action="<?php echo $this->opts_url?>" method="post" id="popup_domination_form">
 			<div style="display:none" id="popup_domination_hdn_div"><?php echo $fields?></div>
			<div class="clear"></div>
			<div id="popup_domination_container" class="has-left-sidebar">
			<div style="display:none" id="popup_domination_hdn_div2"></div>
			<?php foreach($data as $d): ?>
				<?php $campname =  $d->campname; ?>
				<?php $views =  $d->views; ?>
				<?php $conversions = $d->conversions; ?>
				<?php $prevdata = $d->previousdata; ?>
			<?php endforeach; ?>
			<div id="graph-wrapper">
				<div class="chart">
				<br/><br/>
					<h2>Current Month's Analytic Data for Campaign : <?php echo $campname; ?></h2>
					<br/>
					<table style="display:none" id="data-table" border="1" cellpadding="10" cellspacing="0" summary="Current Month's Analytic Data for Campaign :">
						<tbody>
							<tr>
								<th scope="row">Views</th>
								<td><?php echo intval($views); ?></td>
							</tr>
							<tr>
								<th scope="row">Conversions</th>
								<td><?php echo intval($conversions); ?></td>
							</tr>
						</tbody>
					</table>
				</div>
				<?php if(!empty($prevdata)): ?>
					<?php $monthsviews = 0; $monthsconv = 0 ?>
					<div class="charttwo">
					<br/><br/>
						<h2>Last 5 Month's Analytic Data for Campaign : <?php echo $campname; ?></h2>
						<br/>
						<table id="data-table-two" style="display:none;" border="1" cellpadding="10" cellspacing="0" summary="Current Month's Analytic Data for Campaign :">
							<thead>
								<tr>
									<th></th>
								<?php $prevdata = unserialize($prevdata); foreach($prevdata as $k => $p): ?>
									<th scope="col"><?php echo $k; ?></th>
								<?php endforeach; ?>
								</tr>
							</thead>
							<tbody>
								<tr>
									<th scope="row">Views</th>
									<?php foreach($prevdata as $p): ?>
										<td><?php echo intval($p['views']); ?></td>
									<?php endforeach; ?>
								</tr>
								<tr>
									<th scope="row">Conversions</th>
									<?php $avg = 0; $c = 0; foreach($prevdata as $p): ?>
										<td><?php echo intval($p['conversions']); ?></td>
										<?php $monthsconv = $monthsconv + intval($p['conversions']);?>
										<?php $monthsviews = $monthsviews + intval($p['views']);?>
										<?php $lstavg = round((intval($monthsconv) / intval($monthsviews)) * 100); ?>
										<?php $avg = $avg + $lstavg; $c++;?>
									<?php endforeach; ?>
								</tr>
							</tbody>
						</table>
					</div>
				<?php endif; ?>
				<div class="averages">
					<div class="percent">
						<?php 
							if(intval($conversions) == 0 || intval($views) == 0){ $math = 0;}else{
								$math = round((intval($conversions) / intval($views)) * 100);
							}
						 ?>
						<h2>Conversion Percentage:</h2>
						<?php if($math <= 0){ ?>
							<h1 class="red"><?php echo $math.'%'; ?></h1>
						<?php }else{ ?>
							<h1 class="green"><?php echo $math.'%'; ?></h1>
						<?php } ?>
						
					</div>
					<?php if(isset($avg) && !empty($avg) && isset($c) && !empty($c)) :?>
						<div class="lst-average">
							<h2>Last Month's Conversion Percentage</h2>
							<center><h1><?php echo round($lstavg).'%';?></h1></center>
						</div>
						<div class="average-percent">
							<h2>Last 5 Months Average Conversion</h2>
							<center><h1><?php echo round($avg/$c).'%';?></h1></center>
						</div>
					<?php endif; ?>
				</div>
 			</div>
		<div class="clearfix"></div>
    <script type="text/javascript">
		var analytics_name = '<?php echo $campname; ?>', analytics_views = '<?php echo intval($views); ?>', analytics_convers = '<?php echo intval($conversions); ?>', analytics_prev = <?php echo json_encode($prevmonths);?>, graph = "createGraph('#data-table', '.chart');createGraph('#data-table-two', '.charttwo')", popup_domination_admin_ajax = '<?php echo admin_url('admin-ajax.php') ?>', popup_domination_theme_url = '<?php echo $this->theme_url ?>', popup_domination_form_url = '<?php echo $this->opts_url ?>', popup_domination_url = '<?php echo $this->plugin_url ?>';
	 </script>