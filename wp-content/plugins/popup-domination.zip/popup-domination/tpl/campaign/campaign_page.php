<?php

/**
* camps_details.php
*
* Template - This loads and displays all the fields and setup options for creating and editing campaigns. 
*/

?>
<?php if($this->success): ?>
	<div id="message" class="updated"><p>Your Settings have been <strong>Saved</strong></p></div>
<?php endif; ?>
	<div class="wrap with-sidebar" id="popup_domination">
			<?php
			$header_link = 'Back to Campaign Management';
			$header_url = 'admin.php?page=popup-domination/campaigns';
			include $this->plugin_path.'tpl/header.php';
			?>
			<form action="<?php echo $this->opts_url?>" method="post" id="popup_domination_form">
			<div style="display:none" id="popup_domination_hdn_div"><?php echo $fields?></div>
			<div class="clear"></div>
			<div id="popup_domination_container" class="has-left-sidebar">
			<div style="display:none" id="popup_domination_hdn_div2"></div>
			
			
			<?php include $this->plugin_path.'tpl/campaign/campaign_header.php'; ?>
			<?php include $this->plugin_path.'tpl/campaign/tab_menu.php'; ?>
			
			
			<div class="notices" style="display:none;">
				<p class="message"></p>
			</div>
			<div class="flotation-device">
					<?php include $this->plugin_path.'tpl/campaign/look_and_feel.php'; ?>
					<?php include $this->plugin_path.'tpl/campaign/content.php'; ?>
					<?php include $this->plugin_path.'tpl/campaign/bullet_list.php'; ?>
					<?php include $this->plugin_path.'tpl/campaign/display_settings.php'; ?>
					
			</div>
				<div class="clear"></div>
					<div id="popup_domination_form_submit">
						<div class="submit">
							<input type="text" class="extra_fields" name="extra_fields" value="0" style="display:none" />
							<input type="text" class="campaigncookieid" name="campaignid" value="<?php echo $campaignid; ?>" style="display:none" />
							<?php wp_nonce_field('update-options'); ?>
							<?php if(isset($camp_id)){ $disabled = ''; }else{ $disabled = 'disabled="disabled" ';} ?>
							<span style="position: relative; height:55px;">
								<input class="savecamp save-btn" type="submit" name="update" <?php echo $disabled; ?> value="<?php _e('Save Changes', 'popup_domination'); ?>" />
								<?php if(!isset($camp_id)){?>
								<div class="removeme" style="position: absolute; top:-12px;left:0px;bottom:0px;right:0px;height:37px;background-color:transparent;"></div>
								<?php } ?>
							</span>												
						</div>						
						<p><strong>Remember:</strong> You must check your Campaign Name before you can create a new campaign.</p>
						<div id="popup_domination_current_version">
							<p>You are currently running <strong>version <?php echo $this->version; ?></strong></p>
						</div>
					</div>
					<div class="clear"></div>
			</form>
		</div>
	        <script type="text/javascript">
		var popup_domination_tpl_info = <?php echo $js?>, popup_domination_admin_ajax = '<?php echo admin_url('admin-ajax.php') ?>', popup_domination_theme_url = '<?php echo $this->theme_url ?>', popup_domination_form_url = '<?php echo $this->opts_url ?>', popup_domination_url = '<?php echo $this->plugin_url ?>' <?php if(isset($camp_id)){ echo ', popup_domination_campaign_id = "'.$camp_id.'"';}else{echo ',  popup_domination_campaign_id = "0";';} ?>;
		</script>