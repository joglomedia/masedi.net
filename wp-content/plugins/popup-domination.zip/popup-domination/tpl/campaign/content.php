<div class="mainbox" id="popup_domination_tab_template_fields">
	<div class="inside twomaindivs">
		<div class="popdom_contentbox the_content_box">
			<div class="popdom_contentbox_inside">
				<div class="elements template_fields">
					<?php echo $field_str ?>
				</div>
			</div>
			<div class="clear"></div>
		</div>
		<div class="clear"></div>
	</div>
</div>