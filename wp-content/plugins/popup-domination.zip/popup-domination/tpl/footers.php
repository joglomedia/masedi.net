<!-- CAMPAIGN DETAILS -->
<div class="clear"></div>
<div id="popup_domination_form_submit">
	<div class="submit">
		<input type="text" class="extra_fields" name="extra_fields" value="0" style="display:none" />
		<input type="text" class="campaigncookieid" name="campaignid" value="<?php echo $campaignid; ?>" style="display:none" />
		<?php wp_nonce_field('update-options'); ?>
		<?php if(isset($camp_id)){ $disabled = ''; }else{ $disabled = 'disabled="disabled" ';} ?>
			<span style="position: relative; height:55px;">
			<input class="savecamp save-btn" type="submit" name="update" <?php echo $disabled; ?> value="<?php _e('Save Changes', 'popup_domination'); ?>" />
			<?php if(!isset($camp_id)){?>
				<div class="removeme" style="position: absolute; top:-12px;left:0px;bottom:0px;right:0px;height:37px;background-color:transparent;"></div>
			<?php } ?>
			</span>												
		</div>						
		<p><strong>Remember:</strong> You must check your Campaign Name before you can create a new campaign.</p>
		<div id="popup_domination_current_version">
			<p>You are currently running <strong>version <?php echo $this->version; ?></strong></p>
		</div>
	</div>
	<div class="clear"></div>
	</form>
</div>
<script type="text/javascript">
	var popup_domination_tpl_info = <?php echo $js?>, popup_domination_admin_ajax = '<?php echo admin_url('admin-ajax.php') ?>', popup_domination_theme_url = '<?php echo $this->theme_url ?>', popup_domination_form_url = '<?php echo $this->opts_url ?>', popup_domination_url = '<?php echo $this->plugin_url ?>' <?php 		if(isset($camp_id)){ echo ', popup_domination_campaign_id = "'.$camp_id.'"';}else{echo ',  popup_domination_campaign_id = "0";';} ?>;
</script>





<!-- LIST CAMPS -->
<div id="popup_domination_form_submit">
	<div id="popup_domination_current_version">
		<p>You are currently running <strong>version <?php echo $this->version; ?></strong></p>
	</div>
    <?php wp_nonce_field('update-options'); ?>
	</form>
</div>
<script type="text/javascript">
	var popup_domination_admin_ajax = '<?php echo admin_url('admin-ajax.php') ?>', popup_domination_theme_url = '<?php echo $this->theme_url ?>', popup_domination_form_url = '<?php echo $this->opts_url ?>', popup_domination_url = '<?php echo $this->plugin_url ?>', popup_domination_delete_table = 'campaigns', popup_domination_delete_stats = 'analytics';
</script>


<!-- ANALYTICS PANEL -->
<div id="popup_domination_form_submit">
	<div id="popup_domination_current_version">
		<p>You are currently running <strong>version <?php echo $this->version; ?></strong></p>
	</div>
	   <?php wp_nonce_field('update-options'); ?>
	</form>
</div>
 <script type="text/javascript">
var popup_domination_admin_ajax = '<?php echo admin_url('admin-ajax.php') ?>', popup_domination_theme_url = '<?php echo $this->theme_url ?>', popup_domination_form_url = '<?php echo $this->opts_url ?>', popup_domination_url = '<?php echo $this->plugin_url ?>';
</script>

<!-- ANALYTICS DATA -->
<!-- NO FOOTER INCLUDED MUST ADD -->
<script type="text/javascript">
	var analytics_name = '<?php echo $campname; ?>', analytics_views = '<?php echo intval($views); ?>', analytics_convers = '<?php echo intval($conversions); ?>', analytics_prev = <?php echo json_encode($prevmonths);?>, graph = "createGraph('#data-table', '.chart');createGraph('#data-table-two', '.charttwo')", popup_domination_admin_ajax = '<?php echo admin_url('admin-ajax.php') ?>', popup_domination_theme_url = '<?php echo $this->theme_url ?>', popup_domination_form_url = '<?php echo $this->opts_url ?>', popup_domination_url = '<?php echo $this->plugin_url ?>';
 </script>

<!-- MAILING PANEL -->
<div id="popup_domination_form_submit">
	<p class="submit">
		<input type="text" name="campaignid" value="<?php echo $campaignid; ?>" style="display:none" />
		<?php wp_nonce_field('update-options'); ?>
		<input class="savecamp save-btn apisubmit" type="submit" name="update" value="<?php _e('Save Changes', 'popup_domination'); ?>" />												
	</p>
	</form>				
	<p><strong>Note:</strong> Only click "Save Changes" if you have changed your mailing list.</p>
	<div id="popup_domination_current_version">
		<p>You are currently running <strong>version <?php echo $this->version; ?></strong></p>
	</div>
</div>
<div class="clear"></div>
			
			
			
		
<!-- PROMOTE PANEL -->
<div id="popup_domination_form_submit">
	<p class="submit">
		<?php wp_nonce_field('update-options'); ?>
		<input class="savecamp save-btn" type="submit" name="update" value="<?php _e('Save Changes', 'popup_domination'); ?>" />												
	</p>						
	<p><strong>Remember:</strong> You must check your Campaign Name before you can create a new campaign.</p>
	
	<div id="popup_domination_current_version">
		<p>You are currently running <strong>version <?php echo $this->version; ?></strong></p>
	</div>
</div>
<div class="clear"></div>


<!-- THEME UPLOADER -->
<div id="popup_domination_form_submit">
	<p class="submit">											
	</p>						
	<p><strong>Remember:</strong> You must check your Campaign Name before you can create a new campaign.</p>
	<div id="popup_domination_current_version">
		<p>You are currently running <strong>version <?php echo $this->version; ?></strong></p>
	</div>
</div>
<div class="clear"></div>
 <script type="text/javascript">
var popup_domination_admin_ajax = '<?php echo admin_url('admin-ajax.php') ?>', popup_domination_theme_url = '<?php echo $this->theme_url ?>', popup_domination_form_url = '<?php echo $this->opts_url ?>', popup_domination_url = '<?php echo $this->plugin_url ?>';
</script>



<script type="text/javascript">
	var popup_domination_admin_ajax = '<?php echo admin_url('admin-ajax.php') ?>', popup_domination_theme_url = '<?php echo $this->theme_url ?>', popup_domination_form_url = '<?php echo $this->opts_url ?>', popup_domination_url = '<?php echo $this->plugin_url ?>';
</script>


















			
<script type="text/javascript">
	var popup_domination_admin_ajax = '<?php echo admin_url('admin-ajax.php') ?>', popup_domination_theme_url = '<?php echo $this->theme_url ?>', popup_domination_form_url = '<?php echo $this->opts_url ?>', popup_domination_url = '<?php echo $this->plugin_url ?>', <?php if(isset($apidata['provider']) && !empty($apidata['provider'])) { echo 'provider = "'.$apidata['provider'].'",';}else{ echo 'provider = "other",';} ?> website_url = '<?php echo site_url(); ?>', numfields = '<?php echo $number; ?>';
</script>