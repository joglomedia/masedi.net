		<div class="wrap" id="popup_domination">
			<div class="popup_domination_top_left">
				<img class="logo" src="<?php echo $this->plugin_url?>css/img/popup-domination3-logo.png" alt="Popup Domination 3.0" title="Popup Domination 3.0" width="200" height="62" /><div>
			<div id="popup_domination_active">
					<span class="wording">
								<?php
									$text = '<img src="'.$this->plugin_url.'css/images/off.png" alt="off" width="6" height="6" />'; $class = 'inactive'; $text2 = '<img src="'.$this->plugin_url.'css/images/on.png" alt="on" width="6" height="6" />'; $class2 = 'turn-on';$text3 = 'Inactive';$text4 = 'Active';$text5 = 'TURN ON';$text6 = 'TURN OFF';
									if($this->is_enabled()){
										$text = '<img src="'.$this->plugin_url.'css/images/on.png" alt="on" width="6" height="6" />';
										$text2 = '<img src="'.$this->plugin_url.'css/images/off.png" alt="off" width="6" height="6" />';
										$text3 = 'Active';
										$text4 = 'Inactive';
										$text5 = 'TURN OFF';
										$text6 = 'TURN ON';
										$class = 'active';
										$class2 = 'turn-off';
									}
								?>
								<span class="<?php echo $class ?>">
							<?php echo $text; ?> PopUp Domination is</span>  <?php echo $text3 ?></span>
						</span>
					</span>
					<div class="popup_domination_activate_button">
						<div class="border">
							<?php echo $text2 ?>
							<a href="#activation" class="<?php echo $class2 ?>"><?php echo $text5; ?></a>
						</div> 
						<img class="waiting" style="display:none;" src="<?php echo $this->plugin_url ?>images/wpspin_light.gif" alt="" />
					</div>
				</div>
				<p><a href="#">Campaign Management</a></p>
				<div class="clear"></div>
			</div>
			</div>
			<form action="<?php echo $this->opts_url?>" method="post" id="popup_domination_form">
			<div style="display:none" id="popup_domination_hdn_div"><?php echo $fields?></div>
			<div class="clear"></div>
			<div id="popup_domination_container" class="has-left-sidebar">
			<div style="display:none" id="popup_domination_hdn_div2"></div>
			<div class="mainbox" id="popup_domination_campaign_list">				
				<div class="newcampaign">
					<a class="green-btn" href="<?php echo 'admin.php?page='.$this->menu_url.'a-btesting&action=create'; ?>"><span>Create A/B Campaign</span></a>
					<div class="clear"></div>
				</div>
				<div class="clear"></div>
				<?php foreach($this->abcamp as $c): ?>
					<div class="camprow" id="camprow_<?php echo $c->id; ?>">
						<div class="tmppreview">
							<div class="preview_crop">
								<div class="spacing">
									<?php $name =''; foreach($tempname[$c->id] as $t){
	                					$tmpname[] = $t;
	                					$name .= $t.' ';
	                				} ?>
									<div class="slider"><h2><?php echo $name; ?></h2></div>
									<?php
                						foreach($previewurl[$c->id] as $p){
                							$img[] = '<img class="img" id="test" src="'.$p.'">';
                						}
                						$output = array_rand($img, 1);
                						echo $img[$output];
                					?>
								</div>
							</div>
						</div>
						<div class="namedesc">
							<a href="<?php echo 'admin.php?page='.$this->menu_url.'a-btesting&action=edit&id='.$c->id; ?>"><?php echo $c->name; ?></a><br/>
							<p class="description"><?php echo $c->description; ?></p>
						</div>
						<div class="actions">
							<a id="<?php echo $c->id; ?>" class="deletecamp thedeletebutton" href="#deletecamp">Delete</a>
						</div>
						<?php if(!empty($stats) || !empty($stats[0])): ?>
 						<?php $stats = unserialize($c->astats); 
                			$arr = 20;
                			$div = 100/5;
                			$percent = array();
	                		foreach($stats as $k => $s){
	                			if($s[date('m')]['optin'] == 0 || $s[date('m')]['show'] == 0){
                					$percent[$k]['percent'] = '0%';
                				}else{
	                				$percent[$k]['percent'] = round((intval($s[date('m')]['optin']) / intval($s[date('m')]['show'])) * 100).'%';
	                			}
                			}
                		?>
                		<div class="percentages">
                			<p class="sectitle">Template Conversion Percentage</p>                			
                			<?php $i = 0; foreach($percent as $k => $p): ?>
                				<div class="percent"><?php echo $tmpname[$i].' - <span class="numberper">'.$p['percent'].'</span>'; ?></div>
                			<?php $i++; endforeach; ?>
                		</div>
                		<?php endif; ?>
						<div class="clear"></div>
					</div>
				<?php endforeach; ?>
				</div>
		<div class="clearfix"></div>
		</div>
		<div id="popup_domination_form_submit">
			<div id="popup_domination_current_version">
				<p>You are currently running <strong>version <?php echo $this->version; ?></strong></p>
			</div>
                <?php wp_nonce_field('update-options'); ?>
			</form>
		</div>
         <script type="text/javascript">
		var popup_domination_admin_ajax = '<?php echo admin_url('admin-ajax.php') ?>', popup_domination_theme_url = '<?php echo $this->theme_url ?>', popup_domination_form_url = '<?php echo $this->opts_url ?>', popup_domination_url = '<?php echo $this->plugin_url ?>', popup_domination_delete_table = 'ab';
		</script>