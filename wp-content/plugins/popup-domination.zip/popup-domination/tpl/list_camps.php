		<div class="wrap" id="popup_domination">
			<div class="popup_domination_top_left">
				<img class="logo" src="<?php echo $this->plugin_url?>css/img/popup-domination3-logo.png" alt="Popup Domination 3.0" title="Popup Domination 3.0" width="200" height="62" /><div>
			<div id="popup_domination_active">
					<span class="wording">
								<?php
									$text = '<img src="'.$this->plugin_url.'css/images/off.png" alt="off" width="6" height="6" />'; $class = 'inactive'; $text2 = '<img src="'.$this->plugin_url.'css/images/on.png" alt="on" width="6" height="6" />'; $class2 = 'turn-on';$text3 = 'Inactive';$text4 = 'Active';$text5 = 'TURN ON';$text6 = 'TURN OFF';
									if($this->is_enabled()){
										$text = '<img src="'.$this->plugin_url.'css/images/on.png" alt="on" width="6" height="6" />';
										$text2 = '<img src="'.$this->plugin_url.'css/images/off.png" alt="off" width="6" height="6" />';
										$text3 = 'Active';
										$text4 = 'Inactive';
										$text5 = 'TURN OFF';
										$text6 = 'TURN ON';
										$class = 'active';
										$class2 = 'turn-off';
									}
								?>
								<span class="<?php echo $class ?>">
							<?php echo $text; ?> PopUp Domination is</span>  <?php echo $text3 ?></span>
						</span>
					</span>
					<div class="popup_domination_activate_button">
						<div class="border">
							<?php echo $text2 ?>
							<a href="#activation" class="<?php echo $class2 ?>"><?php echo $text5; ?></a>
						</div> 
						<img class="waiting" style="display:none;" src="<?php echo $this->plugin_url ?>images/wpspin_light.gif" alt="" />
					</div>
				</div>
				<p>Campaign Management</p>
				<div class="clear"></div>
			</div>
			</div>
			<form action="<?php echo $this->opts_url?>" method="post" id="popup_domination_form">
			<div style="display:none" id="popup_domination_hdn_div"><?php echo $fields?></div>
			<div class="clear"></div>
			<div id="popup_domination_container" class="has-left-sidebar">
			<div style="display:none" id="popup_domination_hdn_div2"></div>
			<div class="mainbox" id="popup_domination_campaign_list">
				<div class="newcampaign">
					<a class="green-btn" href="<?php echo 'admin.php?page='.$this->menu_url.'campaigns&action=create'; ?>"><span>Create New Popup</span></a>
					<p class="campaign-notice">You have <?php echo $count; ?> Popups.</p>
					<div class="clear"></div>
				</div>
				<div class="clear"></div>
				<?php foreach ($this->campaigns as $c): ?>
					<div class="camprow" id="camprow_<?php echo $c->id; ?>" title="<?php echo $name[$c->id]; ?>">
						<div class="tmppreview">
							<div class="preview_crop">
								<div class="spacing">
									<div class="slider"><h2><?php echo $tempname[$c->id]; ?></h2></div>
									<img class="img" id="test" src="<?php echo $previewurl[$c->id]; ?>" height="<?php echo $height[$c->id]; ?>" width="<?php echo $width[$c->id]; ?>" />
								</div>
							</div>
						</div>
						<div class="namedesc">
							<a href="<?php echo 'admin.php?page='.$this->menu_url.'campaigns&action=edit&id='.$c->id; ?>"><?php echo $c->campaign; ?></a><br/>
							<p class="description"><?php echo $c->desc; ?></p>
						</div>
						<div class="actions">
							<a id="<?php echo $c->id; ?>" title="<?php echo $name[$c->id]; ?>" class="deletecamp thedeletebutton" href="#deletecamp">Delete</a>
						</div>
						<div class="clear"></div>
					</div>
				<?php endforeach; ?>
				</div>
		<div class="clearfix"></div>
		</div>
		<div id="popup_domination_form_submit">
			<div id="popup_domination_current_version">
				<p>You are currently running <strong>version <?php echo $this->version; ?></strong></p>
			</div>
			<?php wp_nonce_field('update-options'); ?>
			</form>
		</div>
         <script type="text/javascript">
		var popup_domination_admin_ajax = '<?php echo admin_url('admin-ajax.php') ?>', popup_domination_theme_url = '<?php echo $this->theme_url ?>', popup_domination_form_url = '<?php echo $this->opts_url ?>', popup_domination_url = '<?php echo $this->plugin_url ?>', popup_domination_delete_table = 'campaigns', popup_domination_delete_stats = 'analytics';
		</script>