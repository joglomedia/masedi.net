<div id="popup_domination_tabs" class="tab-menu">
	<a class="icon mailchimp selected" alt="mc" href="#mailchimp">Mailchimp</a>
	<a class="icon aweber" alt="aw" href="#aweber">Aweber</a>
	<a class="icon icontact" alt="ic" href="#icontact">iContact</a>
	<a class="icon constantc" alt="cc" href="#constantcontact">Constant Contact</a>
	<a class="icon campmon" alt="cm" href="#campaignmonitor">Campaign Monitor</a>
	<a class="icon getresp" alt="gr" href="#getresponce">Get Response</a>
	<a class="icon email" alt="nm" href="#email">Opt-ins to Email</a>
	<a class="icon htmlform" alt="other" href="#htmlform">HTML Form Code</a>
</div>